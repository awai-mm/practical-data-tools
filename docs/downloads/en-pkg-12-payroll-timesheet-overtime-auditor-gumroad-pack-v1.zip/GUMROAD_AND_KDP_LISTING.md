# Payroll Timesheet, Overtime Tier & Shift Differential Auditor

**HR/Ops Offline Verification Tool, Python CLI & Payroll Accuracy Guide**

- **Suggested Price**: USD 18
- **Focus**: Detecting overlapping shifts, overtime multiplier miscalculations, unpaid break deductions, and gross pay variances before payroll run.
- **Included**:
  1. `en-pkg-12-payroll-timesheet-overtime-auditor_workbench.html` — 100% Offline Browser Workbench (zero external requests)
  2. `en_pkg_12_payroll_timesheet_overtime_auditor_cli.py` — Zero-Dependency Python 3 CLI Auditor
  3. `en-pkg-12-payroll-timesheet-overtime-auditor-kdp-en-v1.epub` — Full Practical Engineering Handbook (EPUB3)
  4. `samples/` & `test_en_package.py` — Sample datasets and automated verification suite
