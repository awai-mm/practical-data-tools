# Chapter 1: Why Spreadsheets Fail in Production & The Pre-Flight Audit Pattern

Payroll errors rarely begin as obvious arithmetic failures. They begin as ambiguous inputs: an overnight shift assigned to the wrong day, an overtime column interpreted differently by two systems, or a break deducted twice.

A spreadsheet can produce a plausible total while hiding all three.

The purpose of a pre-flight payroll audit is to identify these failures before payroll submission. It independently checks the proposed payroll against a documented calculation contract, preserves evidence, and prevents unresolved exceptions from disappearing into a grand total.

## Why spreadsheets become unreliable

Spreadsheets are useful for investigation. They become fragile production controls when their behavior depends on implicit assumptions:

- Formulas stop before newly appended rows.
- Employee identifiers lose leading zeros.
- Filtered views conceal duplicate shifts.
- Rates are copied from an earlier pay period.
- Rounded display values differ from calculation values.
- Manual overrides replace formulas without an explanation.
- Separate worksheets apply conflicting overtime assumptions.

The central problem is not the spreadsheet format. It is the absence of explicit contracts, reproducible calculations, and controlled approval.

Consider two shifts with a reported gross pay of $240 each. One is correct. The other should pay $280 but contains an excessive break deduction. A compensating $40 overpayment elsewhere leaves the payroll total unchanged. Aggregate reconciliation passes while two employees receive incorrect pay.

A useful auditor therefore reconciles both individual records and payroll totals.

## Establish the calculation contract

Begin with the required CSV schema:

```csv
shift_id,employee_id,work_date,regular_hours,overtime_hours,hourly_rate,gross_pay
S-1001,E-0042,2026-10-12,8.00,2.00,20.00,220.00
```

The primary key is `shift_id`. Treat identifiers as strings, preserve leading zeros, and reject empty or duplicate keys.

Before calculating anything, document:

- The currency and monetary precision.
- The meaning of regular and overtime hours.
- Whether those hour categories are mutually exclusive.
- The approved overtime multiplier or tier schedule.
- The rounding stage and rounding mode.
- Which earnings components `gross_pay` includes.
- The authoritative time zone and work-date convention.
- Whether negative adjustments belong in this file.

The example pays eight hours at $20 and two hours at $30. That calculation assumes overtime hours receive the full 1.5-times rate. A premium-only earnings export requires a different reconciliation.

Payroll policy must come from an approved, effective-dated policy source. The auditor verifies that configuration; it does not establish employment entitlements.

## Separate checks from evidence gaps

The seven required columns support structural checks and limited arithmetic reconciliation. They do **not** establish:

- Whether shifts overlap.
- Whether recorded hours match actual attendance.
- Whether a break was taken or deductible.
- Whether overtime hours were classified correctly.
- Whether a shift differential applies.

Those checks need supporting data. An auditor that silently treats unavailable evidence as a passing result creates false assurance.

Every run should distinguish four outcomes: **pass**, **exception**, **not evaluated**, and **execution failure**.

## Place the audit before release

Use a repeatable sequence:

1. Freeze the candidate payroll export.
2. Record its file hash, export timestamp, and pay period.
3. Validate structure and identifiers.
4. Reconcile supported earnings calculations.
5. Evaluate attendance and policy rules using companion records.
6. Resolve exceptions through a controlled correction process.
7. Audit the corrected export again.
8. Approve the exact file that will be submitted.

The auditor should produce findings, not silently repair payroll. Corrections belong in the source system or a documented adjustment process.

# Chapter 2: Core Validation & Reconciliation Rules for shift_id

## Validate the record before calculating pay

Require each mandatory column exactly once. Reject malformed CSV records, missing values, duplicate headers, and unexpected row widths.

For each record:

- Require nonempty `shift_id` and `employee_id`.
- Validate `work_date` as an actual calendar date in `YYYY-MM-DD` format.
- Parse numeric fields using decimal arithmetic.
- Reject nonfinite values such as `NaN` and `Infinity`.
- Apply documented limits for hours, rates, and precision.
- Reject negative values unless a separate adjustment contract explicitly permits them.

Do not normalize identifiers silently. Trimming a trailing space may merge two records that the source system considers distinct. Report the defect and require correction.

Zero-hour or zero-rate records deserve explicit treatment. They may represent legitimate administrative entries, but they should not pass merely because multiplication produces zero.

Duplicate `shift_id` values are blocking exceptions, even when their contents match. Two identical rows can still cause duplicate payment.

## Calculate expected gross pay explicitly

For a single overtime tier:

```text
expected_regular = regular_hours × hourly_rate

expected_overtime =
    overtime_hours × hourly_rate × overtime_multiplier

expected_gross =
    round_currency(expected_regular + expected_overtime)

variance = reported_gross − expected_gross
```

A positive variance means reported pay exceeds the calculated amount. A negative variance means it falls below it.

Use this formula only when the export contains mutually exclusive regular and overtime hours, overtime receives its full multiplied rate, and no other earnings belong in gross pay.

Never disguise an unexplained variance as a rounding difference. Define the tolerance in advance, and report both the signed variance and its absolute value.

If the export is already rounded to cents under the same calculation contract, an exact cent comparison is usually the appropriate engineering control. A broader tolerance needs a documented reason and an aggregate exposure check.

## Handle overtime tiers with sufficient detail

A single `overtime_hours` field cannot reconstruct multiple overtime tiers.

For example, three overtime hours might mean:

```text
2 hours × base rate × 1.5
1 hour  × base rate × 2.0
```

It might also mean three hours at 1.5. The required CSV cannot distinguish those cases.

Add companion earnings records keyed to `shift_id`, with fields such as:

```text
earning_code, hours, rate_basis, multiplier, amount
```

To verify hour classification, also obtain the employee’s applicable policy, workweek boundary, and complete hours for the relevant calculation window. A pay period boundary may divide a workweek; auditing only the current export can miss the hours needed to determine eligibility.

Daily and weekly overtime rules can interact. Implement the approved precedence and anti-double-counting rules explicitly.

## Detect overlaps from attendance intervals

Obtain shift start and end timestamps with time-zone offsets, plus the employee identifier. Sort intervals by employee and start time.

Treat intervals as half-open: `[start, end)`. A shift ending at 14:00 and another starting at 14:00 do not overlap.

During the scan, compare each start against the greatest prior end time. Comparing only against the immediately preceding shift misses some overlaps involving a long enclosing shift.

An overlap is an investigation trigger. It may represent duplicate attendance, concurrent assignments, or legitimate allocation of one attendance interval across cost centers.

## Reconcile breaks and differentials separately

For breaks, compare elapsed attendance with paid time:

```text
expected_paid_duration =
    elapsed_attendance − approved_unpaid_break_duration
```

Validate that break intervals fall within attendance and do not overlap each other. Distinguish a recorded break from a policy-driven automatic deduction.

For shift differentials, establish eligibility windows, qualifying hours, and whether the differential changes the overtime rate basis. Keep these components visible rather than embedding unexplained amounts in an adjusted hourly rate.

Finally, reconcile employee totals and payroll totals. Report net variance, total absolute variance, and exception count so offsetting errors remain visible.

# Chapter 3: Real-World Edge Cases, Rounding Traps & Incident Postmortems

## Use a deliberate edge-case inventory

| Scenario | Common failure | Required control |
|---|---|---|
| Overnight shift | Hours assigned entirely to the wrong date | Apply the approved work-date and boundary-splitting rules |
| Daylight-saving transition | Wall-clock subtraction misstates elapsed time | Calculate elapsed time from offset-aware timestamps |
| Adjacent shifts | Shared endpoint flagged as an overlap | Use half-open intervals |
| Nested attendance intervals | Comparison with only the previous row misses a conflict | Track the greatest prior end |
| Multiple overtime tiers | All overtime paid at one multiplier | Reconcile tier-level earnings |
| Automatic meal deduction | Deduction remains after a missed-break correction | Reconcile break evidence and adjustment records |
| Rate change during a shift | Entire shift uses one rate | Split earnings at the effective boundary |
| Re-exported correction | Original and replacement are both paid | Apply documented version and replacement semantics |

A shift identifier must remain unique within the candidate payment population. If a source reuses identifiers across exports, archive export version metadata separately. Do not combine snapshots into a payment file without a replacement rule.

## Rounding is part of the specification

Binary floating-point arithmetic is unsuitable for exact payroll comparisons. Use decimal inputs and an explicit rounding mode.

The calculation stage matters as much as the rounding mode. Rounding each earnings line can differ from rounding their combined total.

| Calculation | Unrounded amount | Rounded separately |
|---|---:|---:|
| Line A: 0.25 hours × $10.02 | $2.505 | $2.51 |
| Line B: 0.25 hours × $10.02 | $2.505 | $2.51 |
| Sum of rounded lines | — | $5.02 |
| Round the combined $5.010 | $5.010 | $5.01 |

These results use decimal half-up rounding. Neither sequence should be selected accidentally. Match the approved payroll calculation contract.

Keep duration precision separate from monetary precision. If attendance is recorded in minutes, 20 minutes is not exactly 0.33 hours. Converting early can change compensation across many records. Preserve the authoritative duration unit until the specified calculation stage.

## Postmortem: duplicated overnight attendance

**Incident:** An employee’s 22:00–06:00 attendance appeared twice, once under each calendar date. Both records had unique shift identifiers.

**Why it escaped:** The spreadsheet checked duplicate keys and daily hour limits. Neither rule identified two distinct records describing the same attendance interval.

**Detection:** Employee-level interval comparison found a complete overlap.

**Correction:** Operations confirmed one attendance event, removed the duplicate through the source workflow, and regenerated payroll.

**Preventive control:** Retain attendance event identifiers alongside payroll shift identifiers. Unique keys prevent duplicate records under one identity; they do not prevent duplicate business events under different identities.

## Postmortem: double meal deduction

**Incident:** An export already contained net paid hours. A downstream calculation subtracted another 30-minute unpaid break.

**Why it escaped:** Both systems used a field labelled “hours” without documenting whether breaks had already been deducted.

**Detection:** Paid hours were consistently 0.5 below attendance-derived net duration for affected shifts.

**Correction:** Remove the second deduction and reconcile every affected employee.

**Preventive control:** Define gross attendance duration, paid duration, and unpaid break duration as separate concepts. Record which system applies the deduction.

## Postmortem: a balanced payroll with wrong employees

**Incident:** A stale hourly rate underpaid one employee by $75. A manual override overpaid another employee by $75.

**Why it escaped:** Finance compared only the payroll grand total.

**Detection:** Shift-level reconciliation reported a zero net variance but $150 in total absolute variance.

**Preventive control:** Approval requires employee-level reconciliation and unresolved exception counts, not merely matching control totals.

The operational lesson is consistent: a plausible aggregate is not evidence that individual payments are correct.

# Chapter 4: Offline Browser Workbench Architecture & Zero-Upload Security

An offline browser workbench gives HR and operations staff a review interface without requiring payroll files to be uploaded.

Its security claim must be specific: input files are processed locally by the delivered application, and the application contains no intentional network transmission path.

## Keep the application self-contained

Package the interface, parser, calculation engine, and styles together. Avoid remote fonts, analytics, external scripts, content delivery networks, and runtime dependency downloads.

A practical design has five components:

1. **Import controller:** Reads files selected explicitly by the operator.
2. **Schema validator:** Checks headers, records, types, and identifiers.
3. **Calculation engine:** Applies versioned rules deterministically.
4. **Review interface:** Filters findings by employee, rule, and severity.
5. **Export controller:** Downloads reports and an audit manifest locally.

Use a worker for large calculations so the interface remains responsive. Set documented file-size and record-count limits, and reject oversized input gracefully.

Show the selected file name, record count, policy version, and coverage before presenting a passing status.

## Preserve decimal behavior

JavaScript’s default numeric type uses binary floating point. A browser implementation must not undermine the decimal calculations used by the command-line auditor.

Use scaled integers with `BigInt`, or a vetted decimal implementation bundled into the application. Specify supported input precision and rounding behavior.

Maintain shared reference cases for the browser and CLI. Given identical inputs and policy, both must produce identical expected amounts, variances, and rule identifiers.

## Make network isolation verifiable

Apply a restrictive Content Security Policy, including `connect-src 'none'`, and explicitly constrain scripts, forms, frames, images, and other resource sources. Avoid inline execution unless the package uses appropriate fixed hashes.

Test the complete application with network access disabled. Inspect browser network activity during import, calculation, review, and export.

Zero-upload behavior does not protect against every endpoint risk. Browser extensions, local malware, synchronized download folders, and shared workstation accounts remain part of the operating environment.

Use an approved browser profile and controlled report destination.

## Minimize persistence and unsafe rendering

Keep payroll records in memory by default. Do not write them to local storage, IndexedDB, service-worker caches, or diagnostic logs.

A clear-session control should remove application references and reset the interface. It should not claim guaranteed forensic erasure from browser memory.

Render imported content as text. Never interpret employee identifiers or CSV cells as HTML.

When exporting findings for spreadsheets, neutralize formula-triggering text in textual fields. Preserve the original value in a separate evidence artifact so protective display encoding does not alter the audit record.

## Export reproducible evidence

Include the following in the audit manifest:

- Input file hashes and byte lengths.
- Tool and policy versions.
- Calculation settings and currency.
- Record and employee counts.
- Evaluated and unevaluated checks.
- Exception counts by severity.
- Net and total absolute variance.
- Run timestamp and completion status.

A file hash establishes identity, not authorization or authenticity. Retain the manifest and reports within the organization’s normal access-controlled approval process.

# Chapter 5: Automating Audits with Zero-Dependency Python 3 CLI & CI/CD Exit Codes

The following CLI is a deliberately narrow arithmetic gate. It validates the required schema and reconciles a single overtime tier using Python’s standard library.

It assumes nonnegative ordinary earnings, mutually exclusive hour buckets, no additional gross-pay components, and rounding once per shift using decimal half-up. It does not validate attendance, break eligibility, rate authority, or overtime classification.

Save it as `payroll_audit.py`:

```python
import argparse
import csv
import re
import sys
from datetime import date
from decimal import (
    Decimal, InvalidOperation, ROUND_HALF_UP, localcontext
)

REQUIRED = (
    "shift_id", "employee_id", "work_date",
    "regular_hours", "overtime_hours",
    "hourly_rate", "gross_pay",
)
CENT = Decimal("0.01")
NUMBER = re.compile(r"[0-9]{1,12}(?:\.[0-9]{1,6})?")
ISO_DATE = re.compile(r"[0-9]{4}-[0-9]{2}-[0-9]{2}")


def decimal_value(raw):
    if not isinstance(raw, str) or not NUMBER.fuテキスト処理系atch(raw):
        raise ValueError("expected nonnegative plain decimal")
    value = Decimal(raw)
    if not value.is_finite():
        raise ValueError("nonfinite number")
    return value


def audit(path, multiplier):
    seen = set()
    count = 0
    findings = 0
    net = Decimal("0")
    absolute = Decimal("0")

    with open(path, encoding="utf-8-sig", newline="") as source:
        reader = csv.DictReader(source, strict=True)
        headers = reader.fieldnames
        if (
            not headers
            or len(headers) != len(set(headers))
            or not set(REQUIRED).issubset(headers)
        ):
            raise ValueError("missing or duplicate headers")

        for record, row in enumerate(reader, start=1):
            count += 1
            try:
                if None in row or any(v is None for v in row.values()):
                    raise ValueError("incorrect field count")

                for field in ("shift_id", "employee_id"):
                    value = row[field]
                    if not value or value != value.strip():
                        raise ValueError(f"invalid {field}")

                shift_id = row["shift_id"]
                if shift_id in seen:
                    raise ValueError("duplicate shift_id")
                seen.add(shift_id)

                if not ISO_DATE.fuテキスト処理系atch(row["work_date"]):
                    raise ValueError("invalid work_date format")
                date.fromisoformat(row["work_date"])

                regular, overtime, rate, gross = (
                    decimal_value(row[field])
                    for field in REQUIRED[3:]
                )
                if gross != gross.quantize(CENT):
                    raise ValueError("gross_pay has sub-cent value")

                expected = (
                    regular * rate + overtime * rate * multiplier
                ).quantize(CENT, rounding=ROUND_HALF_UP)
                variance = gross - expected
                net += variance
                absolute += abs(variance)

                if variance:
                    findings += 1
                    print(
                        f"record={record} rule=GROSS_VARIANCE "
                        f"expected={expected} variance={variance}"
                    )
            except (ValueError, InvalidOperation) as exc:
                findings += 1
                print(f"record={record} rule=INVALID_RECORD detail={exc}")

    if count == 0:
        raise ValueError("empty payroll file")

    print(
        f"records={count} findings={findings} "
        f"reconciled_net={net:.2f} "
        f"reconciled_absolute={absolute:.2f}"
    )
    print(
        "coverage=single-tier-arithmetic "
        "unevaluated=overlaps,breaks,tier-eligibility,"
        "rate-authority,differentials"
    )
    return 1 if findings else 0


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("csv_path")
    parser.add_argument("--overtime-multiplier", required=True)
    args = parser.parse_args()

    try:
        multiplier = decimal_value(args.overtime_multiplier)
        if multiplier < 1:
            raise ValueError("multiplier must be at least 1")
        with localcontext() as context:
            context.prec = 80
            return audit(args.csv_path, multiplier)
    except (OSError, UnicodeError, csv.Error,
            ValueError, InvalidOperation) as exc:
        print(f"audit_failed: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
```

Run it with an explicitly selected multiplier:

```text
python3 payroll_audit.py candidate.csv --overtime-multiplier 1.5
```

The numeric parser accepts bounded plain decimal values and rejects signs, exponent notation, commas, and surrounding whitespace. These are interface constraints, not payroll policy limits. Add approved limits for hours, rates, dates, and employee eligibility before operational deployment.

The summary totals cover successfully reconciled records only. Invalid records prevent a passing result and must not be interpreted as zero-value earnings.

## Define exit codes as an interface

| Exit code | Meaning | Pipeline action |
|---|---|---|
| `0` | All implemented checks passed | Continue to remaining controls |
| `1` | Record defects or pay variances found | Hold payroll and investigate |
| `2` | Invalid invocation, file failure, or incomplete audit | Stop and repair the audit run |

A zero exit code from this example is not complete payroll approval. The release pipeline must separately require evidence for every mandatory control.

Do not suppress failure with shell constructs that always return success. Protect payroll reports as restricted artifacts, and avoid printing employee names or full payroll records to general build logs.

Verify the CLI with known cases covering duplicate keys, malformed records, empty input, rounding boundaries, incorrect multipliers, and offsetting variances. Test the exit code as well as the calculation.

For a fuller engine, add deterministic attendance and policy modules while preserving this distinction: a failed check and a check that never ran are different operational events.

# Chapter 6: Standard Operating Checklist & Executive Sign-Off Template

## Before each audit

- Confirm the pay period, currency, employee population, and source systems.
- Freeze the candidate export and record its hash.
- Select the approved, effective-dated policy configuration.
- Obtain complete attendance and earnings evidence for required checks.
- Include earlier workweek hours when the payroll boundary splits a week.
- Confirm tool version and access-controlled report storage.

An operator should be able to explain exactly what the export contains before running calculations.

## Review and resolve

Triage findings by payment impact and evidence quality.

Duplicate keys, malformed money values, unresolved overlaps affecting payable hours, and unexplained gross-pay differences should block release under the organization’s control policy.

For each finding, record the responsible owner, supporting evidence, disposition, and affected records. An accepted exception needs a reason and an authorized approver. “Small amount” is not a sufficient explanation for a recurring defect.

Correct the source, regenerate the export, and rerun the complete audit. Do not edit the report to make the exception disappear.

If required evidence is unavailable, record the missing control explicitly. A reviewer must not convert “not evaluated” into “passed.”

## Release and retain

The final approval must reference the exact candidate file, final audit report, and policy version. Confirm that the payroll submission uses that same file.

After submission, reconcile the payroll processor’s accepted earnings output against the approved candidate. Pre-flight success does not prove that a later import, mapping, or processor calculation preserved the amounts.

Retain evidence according to the organization’s records schedule and access policy.

## Executive sign-off template

**Payroll scope**

- Pay period:
- Legal entity and currency:
- Employee count:
- Shift count:
- Candidate file name and hash:

**Audit evidence**

- Tool version:
- Policy version and effective date:
- Final run timestamp:
- Audit manifest and report location:
- Required controls evaluated:
- Controls not evaluated and reason:

**Reconciliation**

- Reported gross:
- Expected gross within evaluated scope:
- Net variance:
- Total absolute variance:
- Blocking findings remaining:
- Approved exceptions and evidence references:

**Operational confirmation**

- Source corrections completed:
- Corrected candidate fully re-audited:
- Submission file identity verified:
- Post-submission reconciliation owner:

**Approval statement**

> I approve the identified payroll candidate for release within the documented audit scope. Required controls have been completed, or any permitted exceptions have been explicitly documented and approved. This approval applies only to the file hash and policy version recorded above.

- Prepared by / timestamp:
- Payroll reviewer / timestamp:
- Finance approver / timestamp:
- Release authorization reference:

Release authority should depend on traceable evidence, explicit coverage, and resolved findings. A green screen or a matching grand total is insufficient.
