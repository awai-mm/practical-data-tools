# Chapter 1: Why Spreadsheets Fail in Production & The Pre-Flight Audit Pattern

A CSV file is a transport format, not a database contract. It carries text without enforceable types, relationships, uniqueness constraints, or timezone semantics. A spreadsheet can display a plausible account balance while silently converting an identifier, hiding a duplicate email, or interpreting a timestamp in the operator’s local timezone.

The dangerous failures are often internally consistent. An imported payment can have a valid amount and a valid customer identifier while pointing to the wrong customer. A timestamp can parse successfully while representing the wrong instant. A rounded identifier can remain unique and still destroy its relationship to upstream records.

The pre-flight audit pattern makes these failures visible before production receives any rows.

## Establish the contract before inspecting the file

Every input must contain these columns:

| Column | Contract |
|---|---|
| `row_pk` | Required, unique primary key; treated as text |
| `parent_fk` | Required reference to an authoritative parent key |
| `email` | Required address under an explicit uniqueness policy |
| `created_at_iso` | Timestamp containing an explicit UTC offset |
| `amount_cents` | Signed integer minor units; never a floating-point amount |
| `status_enum` | Exact member of an approved enumeration |
| `is_active` | Boolean represented by an approved token |

For this handbook, the example contract uses statuses `pending`, `posted`, and `void`; booleans `true` and `false`; case-insensitive ASCII email uniqueness; and identifiers restricted to ASCII letters, digits, underscores, and hyphens.

These are example business rules, not universal standards. Approve replacements before processing data. Record whether negative amounts are allowed, which currency applies, and whether parent references may be null. The example assumes one currency and non-null parent references.

## Use a staged audit

A practical sequence is:

1. Preserve the original bytes and compute a SHA-256 digest.
2. Validate UTF-8 decoding and CSV structure.
3. Validate fields against the contract.
4. Check uniqueness and foreign-key membership.
5. Reconcile counts, key sets, and monetary totals.
6. Produce a candidate normalized file.
7. Revalidate that candidate and approve its digest.
8. Load into staging, reconcile again, then promote.

Do not repair the only copy of an export. Keep the original, validation report, normalized candidate, parent snapshot, contract version, and approval record together.

A clean audit report is evidence about a particular artifact and a particular reference snapshot. It is not permission to import a later file with the same filename.

## Separate mechanical changes from business decisions

Converting an explicitly offset timestamp to UTC is mechanical. Assigning a timezone to an offset-free timestamp is a business decision.

Likewise, removing a UTF-8 byte-order mark from the beginning of a file is mechanical. Replacing unreadable characters in a customer identifier is destructive.

The audit must distinguish accepted canonicalization from rejected ambiguity. Avoid “best effort” imports that turn broken values into nulls or defaults. A rejected file is usually cheaper than a successful import with incorrect relationships.

# Chapter 2: Core Validation & Reconciliation Rules for row_pk

The primary key is the backbone of reconciliation. Every source row must remain traceable through normalization, staging, insertion, and rollback.

## Preserve identifier identity

Treat `row_pk` and `parent_fk` as strings throughout the pipeline. Never infer numeric types.

`000123` and `123` are different identifiers unless the approved contract explicitly declares otherwise. Spreadsheet applications can remove leading zeros or round long numeric identifiers. Once an export contains the rounded value, formatting cannot recover the original.

Reject empty keys, surrounding whitespace, unsupported characters, and duplicate primary keys. Do not silently trim identifiers: trimming can merge distinct source values.

If Unicode identifiers are required, specify normalization and database comparison behavior explicitly. Otherwise, visually similar characters and different Unicode representations can make application equality disagree with database equality.

## Check foreign keys against authoritative data

An orphan exists when a non-null `parent_fk` has no corresponding parent key in the approved destination scope.

That scope matters. A key can exist in the database but belong to another tenant, an archived partition, or an account excluded from the migration.

Export parent keys from the target environment using the intended visibility rules. Record the snapshot time, query definition, environment, tenant scope, and digest. If parents are being migrated simultaneously, validate against the union of approved existing parents and approved incoming parents.

A snapshot does not eliminate races. Keep the database foreign-key constraint enabled. Prevent relevant parent deletion during promotion, or use transaction and locking behavior appropriate to the database.

## Define email uniqueness precisely

Email syntax validation and email uniqueness are separate checks.

A practical internal-account policy may reject non-ASCII addresses, trim surrounding whitespace, lowercase the entire address, and enforce uniqueness on that canonical value. Lowercasing the local part is a product policy; it is not universally correct for all mail systems.

Never remove dots or plus-address suffixes globally. Provider-specific delivery behavior is not a safe general identity rule.

Check collisions both within the incoming file and against destination accounts. If an address matches an existing record, the migration must specify whether that is an update, a rejection, or an identity-resolution case.

The validator and destination unique index must use compatible comparison rules. An application check cannot compensate for an incompatible database collation.

## Require explicit timestamp offsets

Accept a deliberately narrow timestamp profile:

```text
2026-10-28T09:30:00Z
2026-10-28T18:30:00+09:00
2026-10-28T09:30:00.123456+00:00
```

Reject offset-free timestamps and unknown-offset notation such as `-00:00`. Require a valid calendar date and an offset within the contract’s supported range.

Normalize accepted timestamps to UTC while preserving the represented instant. Do not simply replace an offset suffix with `Z`.

Decide fractional-second precision before migration. If the destination stores milliseconds and the source contains microseconds, either reject excess precision or approve a documented rounding rule. Silent truncation can change ordering and deduplication behavior.

## Reconcile beyond row counts

At minimum, compare:

- Source record count, accepted count, and rejected count.
- Distinct `row_pk` count and exact primary-key sets.
- Signed amount totals and totals by status.
- Positive and negative amount totals separately.
- Minimum and maximum timestamps.
- Incoming foreign keys against approved parent membership.

Equal row counts do not prove equal records. Equal net totals can hide an omitted debit and an omitted credit.

For an insert-only migration, reject incoming primary keys already present in the destination. For updates, record expected existing keys and compare before-and-after values. Make conflict handling explicit; a silent “ignore duplicate” option destroys reconciliation.

# Chapter 3: Real-World Edge Cases, Rounding Traps & Incident Postmortems

The following illustrative postmortems show why syntactic validity is only the first gate.

## Encoding can be valid and still be wrong

Strict UTF-8 decoding catches malformed byte sequences. It cannot establish that text was decoded correctly earlier in the export chain.

| Observation | Possible cause | Required response |
|---|---|---|
| Decoder rejects a byte sequence | Legacy encoding or truncated export | Identify encoding and re-export |
| `JosÃ©` appears instead of `José` | Earlier decoding and re-encoding error | Compare against authoritative source |
| Replacement character `�` appears | Earlier lossy decoding | Reject and recover original text |
| UTF-8 BOM precedes the header | Spreadsheet export convention | Strip only the initial BOM |
| Key contains an invisible character | Copy/paste contamination | Reject under the identifier contract |

Do not use `errors="ignore"` or `errors="replace"` when decoding migration data. Both convert evidence of damage into apparently usable text.

Suspicious text patterns can support review, but they are not proof of corruption. A general-purpose “mojibake repair” operation can alter legitimate names. Re-exporting from the authoritative system is preferable.

## Integer cents eliminate only one class of rounding error

Once values are valid integer cents, summation is exact. The conversion into cents can still be wrong.

| Input or operation | Failure | Control |
|---|---|---|
| `int(float("19.99") * 100)` | Binary approximation may truncate incorrectly | Parse decimal text directly |
| `12.345` currency units | Requires a rounding decision | Reject or apply approved rule |
| `(1,250.00)` | Locale-specific negative notation | Use a declared source format |
| Very large cents value in a browser | JavaScript `Number` loses integer precision | Use `BigInt` |
| Mixed currencies in one total | Numerically valid, economically meaningless | Separate currencies before reconciliation |

If a source provides major units, use decimal arithmetic:

```python
from decimal import Decimal, ROUND_HALF_EVEN

major = Decimal("12.345")
minor = major.quantize(
    Decimal("0.01"), rounding=ROUND_HALF_EVEN
) * 100
amount_cents = int(minor)
```

This demonstrates a chosen rounding rule; it does not establish the correct accounting policy. When the required input column is already `amount_cents`, reject decimal points, grouping separators, and exponent notation.

Also define the rounding boundary. Rounding each line and then summing can differ from summing precise values and rounding once.

## Postmortem: rounded account identifiers

**Trigger:** An operator opened an export in a spreadsheet and saved it again.

**Failure:** Long numeric identifiers were rounded. Several child records still matched existing parent keys, but those keys identified different accounts.

**Why the first audit missed it:** It checked only orphan membership and total row count.

**Permanent control:** Preserve identifiers as text from extraction onward, compare key mappings against the source, and prohibit spreadsheet round-tripping of migration artifacts.

A foreign key proves existence, not semantic correctness.

## Postmortem: daylight-saving ambiguity

**Trigger:** A source exported `2026-11-01T01:30:00` without an offset.

**Failure:** The migration assigned a default timezone. In a region with a repeated clock hour, two different instants could correspond to that local timestamp.

**Why the first audit missed it:** The timestamp parser accepted a valid date and time.

**Permanent control:** Require explicit offsets at extraction. If historical recovery is necessary, use the named source timezone plus evidence that resolves the repeated hour. Do not guess.

## Postmortem: email collision during normalization

**Trigger:** The source contained both `Alex@example.com` and `alex@example.com`.

**Failure:** Both rows passed raw-string uniqueness checks, then collided after lowercasing.

**Why the first audit missed it:** Validation ran before the identity transformation.

**Permanent control:** Enforce uniqueness on the approved canonical representation and revalidate every normalized candidate.

# Chapter 4: Offline Browser Workbench Architecture & Zero-Upload Security

An offline workbench gives operators immediate feedback without sending customer data to a service. Its architecture should make the absence of uploads observable.

## Package all resources locally

Ship a versioned static bundle containing HTML, CSS, JavaScript, and the validation contract. Include no remote fonts, analytics, external scripts, telemetry, or network-dependent libraries.

Use a restrictive content security policy that blocks network connections, frames, objects, and form submissions. Permit scripts and styles only from the packaged resources required by the workbench.

Document the supported launch method. Browser security behavior differs between local files and a loopback origin. If a local server is used, bind it to loopback only.

Zero-upload describes application behavior. It does not eliminate risks from browser extensions, endpoint software, screenshots, or downloads stored in synchronized directories. Use an approved browser profile and storage location.

## Process files without persistent storage

Read explicitly selected files through browser file APIs. Keep source content in memory and avoid local storage, IndexedDB, caches, and service-worker persistence.

Run parsing and validation in a worker so large files do not freeze the interface. For large inputs, process chunks using a streaming decoder with fatal UTF-8 error handling. Decoder state must survive chunk boundaries.

CSV parsing also requires state across chunks. Quoted fields can contain commas and newlines; escaped quotes can cross a chunk boundary. Splitting text on newline characters is not a CSV parser.

Use `BigInt` for cents and identifiers as strings. Validate timestamp syntax before constructing date objects. JavaScript dates preserve only milliseconds, so retain fractional text or use integer microseconds when the contract requires finer precision.

## Make findings reviewable

Display:

- File digest, contract version, and parent snapshot digest.
- Record counts and monetary reconciliations.
- Error counts grouped by rule.
- Record ordinal, column, and reason for each finding.
- A preview of every permitted transformation.

Use text-only rendering for uploaded values. Never insert file contents into HTML markup.

Reports should minimize personal data. A record ordinal and error code usually suffice for investigation against the retained source. If exporting a spreadsheet-readable report, handle formula injection separately; quoting a CSV cell does not prevent spreadsheet formula interpretation.

Enable candidate download only after blocking findings are resolved. Revoke download object URLs afterward and clear references on reset. Do not promise secure memory erasure from a browser runtime.

# Chapter 5: Automating Audits with Zero-Dependency Python 3 CLI & CI/CD Exit Codes

The command-line implementation should apply the same contract as the workbench. Use shared test fixtures to compare acceptance, rejection, normalized values, and reconciliation totals.

The example below uses only the Python 3.11 standard library. It validates a bounded-size batch, checks parent membership, normalizes approved fields, and prints a machine-readable report. It assumes the parent CSV has a `row_pk` column.

```python
#!/usr/bin/env python3
import argparse
import csv
import hashlib
import io
import json
import re
import sys
from datetime import datetime, timezone

COLUMNS = [
    "row_pk", "parent_fk", "email", "created_at_iso",
    "amount_cents", "status_enum", "is_active",
]
KEY = re.compile(r"[A-Za-z0-9_-]+\Z")
CENTS = re.compile(r"(?:0|-?[1-9][0-9]*)\Z")
STAMP = re.compile(
    r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}"
    r"(?:\.\d{1,6})?(?:Z|[+-]\d{2}:\d{2})\Z"
)
STATUSES = {"pending", "posted", "void"}
LIMIT = 2**63

class InvalidData(Exception):
    pass

def read_csv(path, exact_columns=None):
    with open(path, "rb") as stream:
        raw = stream.read()
    digest = hashlib.sha256(raw).hexdigest()
    text = raw.decode("utf-8-sig", errors="strict")
    if "\ufffd" in text or "\x00" in text:
        raise InvalidData("replacement character or NUL")

    reader = csv.reader(io.StringIO(text, newline=""), strict=True)
    header = next(reader, None)
    if not header or len(header) != len(set(header)):
        raise InvalidData("missing or duplicate headers")
    if exact_columns is not None and header != exact_columns:
        raise InvalidData("unexpected header names or order")
    if "row_pk" not in header:
        raise InvalidData("missing row_pk")

    rows = []
    for ordinal, fields in enumerate(reader, 1):
        if len(fields) != len(header):
            raise InvalidData(f"record {ordinal}: wrong field count")
        rows.append(dict(zip(header, fields)))
    return rows, digest

def canonical_time(value):
    if not STAMP.fuテキスト処理系atch(value) or value.endswith("-00:00"):
        raise InvalidData("timestamp requires a known explicit offset")
    if not value.endswith("Z"):
        hours = int(value[-5:-3])
        minutes = int(value[-2:])
        if minutes > 59 or hours > 14 or (hours == 14 and minutes):
            raise InvalidData("unsupported timestamp offset")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        utc = parsed.astimezone(timezone.utc)
    except (ValueError, OverflowError) as exc:
        raise InvalidData("invalid timestamp") from exc
    return utc.isoformat(timespec="microseconds").replace("+00:00", "Z")

def audit(rows, parents):
    keys, emails, normalized, errors = set(), set(), [], []
    totals = {status: 0 for status in STATUSES}

    for ordinal, row in enumerate(rows, 1):
        issues = []
        pk = row["row_pk"]
        if not KEY.fuテキスト処理系atch(pk):
            issues.append("invalid primary key")
        if pk in keys:
            issues.append("duplicate primary key")
        keys.add(pk)

        parent = row["parent_fk"]
        if not KEY.fuテキスト処理系atch(parent):
            issues.append("invalid parent key")
        elif parent not in parents:
            issues.append("orphan parent key")

        email = row["email"].strip().lower()
        if (
            not email.isascii()
            or not re.fuテキスト処理系atch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email)
            or any(ord(char) < 33 or ord(char) == 127 for char in email)
        ):
            issues.append("invalid email under contract")
        if email in emails:
            issues.append("duplicate canonical email")
        emails.add(email)

        try:
            timestamp = canonical_time(row["created_at_iso"])
        except InvalidData as exc:
            issues.append(str(exc))
            timestamp = None

        amount = row["amount_cents"]
        if len(amount) > 20 or not CENTS.fuテキスト処理系atch(amount):
            issues.append("invalid integer cents")
            cents = None
        else:
            cents = int(amount)
            if not -LIMIT <= cents < LIMIT:
                issues.append("cents outside signed 64-bit range")

        status = row["status_enum"]
        if status not in STATUSES:
            issues.append("unknown status")
        if row["is_active"] not in {"true", "false"}:
            issues.append("invalid boolean")

        if issues:
            errors.append({"record": ordinal, "errors": issues})
        else:
            normalized.append({
                **row, "email": email, "created_at_iso": timestamp
            })
            totals[status] += cents

    return normalized, errors, totals

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("--parents", required=True)
    parser.add_argument("--output")
    args = parser.parse_args()

    try:
        rows, source_hash = read_csv(args.input, COLUMNS)
        parent_rows, parent_hash = read_csv(args.parents)
        parent_keys = [row["row_pk"] for row in parent_rows]
        if (
            any(not KEY.fuテキスト処理系atch(key) for key in parent_keys)
            or len(set(parent_keys)) != len(parent_keys)
        ):
            raise InvalidData("invalid or duplicate parent keys")

        candidate, errors, totals = audit(rows, set(parent_keys))
        report = {
            "source_sha256": source_hash,
            "parents_sha256": parent_hash,
            "records": len(rows),
            "accepted": len(candidate),
            "rejected": len(errors),
            "accepted_cents_by_status": totals,
            "errors": errors,
        }
        print(json.dumps(report, sort_keys=True))
        if errors:
            return 1

        # Exclusive creation prevents overwriting an existing artifact.
        if args.output:
            with open(
                args.output, "x", encoding="utf-8", newline=""
            ) as stream:
                writer = csv.DictWriter(
                    stream, fieldnames=COLUMNS, lineterminator="\n"
                )
                writer.writeheader()
                writer.writerows(candidate)
        return 0
    except (InvalidData, UnicodeError, csv.Error) as exc:
        print(json.dumps({"error": str(exc)}), file=sys.stderr)
        return 1
    except OSError as exc:
        print(json.dumps({"error": str(exc)}), file=sys.stderr)
        return 2
    except Exception as exc:
        print(
            json.dumps({"internal_error": type(exc).__name__}),
            file=sys.stderr,
        )
        return 3

if __name__ == "__main__":
    sys.exit(main())
```

The email check is deliberately a restricted application policy, not a complete implementation of every permitted email-address form.

The code retains rows and error details in memory. Set a documented input-size ceiling. Larger datasets need streaming validation and disk-backed uniqueness indexes; Python’s standard-library `sqlite3` module can provide those without third-party packages.

## Define exit codes as a deployment contract

| Exit code | Meaning | Pipeline behavior |
|---|---|---|
| `0` | Checks passed; requested output completed | Continue to candidate verification |
| `1` | Invalid data or contract violation | Block import |
| `2` | Invocation, filesystem, or environment failure | Block and investigate |
| `3` | Unexpected internal failure | Block and investigate implementation |

Never convert an audit failure into pipeline success with `|| true`.

Example invocation:

```sh
python3 preflight.py incoming.csv \
  --parents parent_snapshot.csv \
  --output candidate.csv > audit.json

python3 preflight.py candidate.csv \
  --parents parent_snapshot.csv > candidate-audit.json
```

Configure the pipeline to stop immediately on any nonzero exit. Publish the candidate only after the second audit succeeds and its digest is recorded.

The example does not provide atomic output publication: a write failure may leave a partial file. Production wrappers should write to a temporary artifact and publish it atomically after successful validation. A file’s existence alone must never authorize import.

Before promotion, add destination primary-key and email collision checks, expected-count assertions, business reconciliation, and normalized field comparisons. The example’s totals cover accepted rows only; they are not substitutes for independent source control totals.

# Chapter 6: Standard Operating Checklist & Executive Sign-Off Template

Migration approval should describe evidence, ownership, and recovery. “The CSV looks correct” is not an acceptance criterion.

## Before extraction

- [ ] Approve schema, enum values, boolean tokens, currency, and null rules.
- [ ] Define identifier and email comparison policies.
- [ ] Define timestamp offsets and supported precision.
- [ ] Declare insert-only, update, or mixed behavior.
- [ ] Identify data owner, operator, reviewer, and rollback owner.
- [ ] Agree on expected counts, totals, and import scope.

## Before loading

- [ ] Preserve original bytes and record their digest.
- [ ] Verify strict UTF-8 decoding and CSV structure.
- [ ] Resolve duplicate keys and canonical-email collisions.
- [ ] Verify parent membership using the approved snapshot.
- [ ] Compare incoming keys and emails against the destination.
- [ ] Revalidate the normalized candidate.
- [ ] Reconcile key sets, status totals, and signed amounts.
- [ ] Record the exact candidate digest approved for import.
- [ ] Rehearse loading and rollback in a representative environment.

## During and after promotion

Load into staging with explicit column mappings and types. Keep destination uniqueness and foreign-key constraints active. Inspect database errors rather than suppressing them.

Record the migration batch identifier and affected primary keys. For updates, retain the prior values needed for reversal. Rollback must account for triggers, notifications, and downstream processing; deleting inserted rows may not reverse those effects.

After loading, compare expected and actual key sets, canonical fields, timestamps, and monetary totals. Reconcile inserted, updated, unchanged, and rejected records separately.

A successful database command is not the end of the migration. Completion requires verified destination state and an accountable acceptance decision.

## Executive sign-off template

**Migration:**  
**Business purpose:**  
**Source and destination environments:**  
**Tenant or account scope:**  
**Change window:**  
**Contract and validator versions:**  

**Approved artifacts**

- Original file SHA-256:
- Candidate file SHA-256:
- Parent snapshot SHA-256 and capture time:
- Audit report location:
- Independent reconciliation evidence:

**Acceptance evidence**

- Expected and verified record counts:
- Exact primary-key reconciliation:
- Orphan foreign keys: zero
- Unresolved canonical-email collisions: zero
- Timestamp ambiguity or unexplained drift: zero
- Amount totals and status breakdown reconciled:
- Destination constraints verified:

**Exceptions**

List each approved exception, its affected records, business justification, owner, and resolution date. Do not bury exceptions in a general approval statement.

**Recovery**

- Rollback trigger:
- Rollback procedure and owner:
- Rehearsal result:
- Recovery-time estimate:
- Downstream effects requiring separate reversal:

**Authorization**

> We approve import of the candidate identified by the digest above. The stated scope, reconciliations, exceptions, and recovery procedure have been reviewed. Any change to the candidate bytes, transformation rules, destination scope, or reference data requires renewed validation and assessment.

**Data owner / date:**  
**Engineering reviewer / date:**  
**Finance reviewer / date, when applicable:**  
**Production operator / date:**
