# Database CSV Migration Pre-Flight & Foreign-Key Integrity Kit

**Zero-Dependency Data Validator, Normalizer CLI & Schema Migration Handbook**

- **Suggested Price**: USD 18
- **Focus**: Catching orphan foreign keys, UTF-8 encoding corruption, duplicate emails, and timestamp timezone drift before production imports.
- **Included**:
  1. `en-pkg-07-sql-migration-preflight-kit_workbench.html` — 100% Offline Browser Workbench (zero external requests)
  2. `en_pkg_07_sql_migration_preflight_kit_cli.py` — Zero-Dependency Python 3 CLI Auditor
  3. `en-pkg-07-sql-migration-preflight-kit-kdp-en-v1.epub` — Full Practical Engineering Handbook (EPUB3)
  4. `samples/` & `test_en_package.py` — Sample datasets and automated verification suite
