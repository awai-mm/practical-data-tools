#!/usr/bin/env python3
import subprocess, sys, unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CLI = ROOT / "en_pkg_04_log_latency_burst_analyzer_cli.py"

class TestEnPackage(unittest.TestCase):
    def test_clean_csv_passes(self):
        r = subprocess.run([sys.executable, str(CLI), str(ROOT / "samples/clean.csv")], capture_output=True, text=True)
        self.assertEqual(r.returncode, 0)

    def test_problem_csv_detected(self):
        r = subprocess.run([sys.executable, str(CLI), str(ROOT / "samples/problem.csv")], capture_output=True, text=True)
        self.assertEqual(r.returncode, 1)

if __name__ == "__main__":
    unittest.main()
