# Chapter 1: Why Spreadsheets Fail in Production & The Pre-Flight Audit Pattern

An incident rarely starts with a useful question. It starts with “the API is slow,” a revenue dashboard falling behind, or a burst of customer complaints. The first task is to turn raw access logs into a trustworthy population of requests. Only then should anyone calculate P95, compare upstream timing, or count failures.

Spreadsheets are useful for reviewing small summaries. They are a poor foundation for production log triage because they silently change identifiers, infer timestamps, truncate imports, and encourage averaging values that must remain separate. A request identifier resembling a number can lose leading zeros. A local timestamp can acquire the analyst’s timezone. A filtered worksheet can hide the denominator behind an apparently precise failure rate.

The dangerous output is not an obvious error. It is a plausible number computed from the wrong population.

## Establish the event contract

The kit accepts CSV, TSV, and JSONL with these required fields:

| Field | Contract |
|---|---|
| `request_id` | Nonempty string; primary key within the audit scope |
| `timestamp` | RFC 3339 event time with explicit UTC offset |
| `service` | Nonempty, case-sensitive service identifier |
| `route` | Nonempty route identifier; preferably a normalized template |
| `status_code` | Integer HTTP status from 100 through 599 |
| `latency_ms` | Finite, nonnegative total request duration |
| `upstream_ms` | Finite, nonnegative upstream duration with documented semantics |

Document whether `timestamp` means request arrival or completion. During a timeout wave, those conventions place requests in different incident windows.

Define the capture boundary too: edge proxy, application server, or service mesh. Mixing observations from several boundaries can count one request several times and produce incompatible latency distributions.

The primary key contract assumes one terminal access record per observed request. If a source records intermediate events, normalize those events before importing them.

## Audit before analysis

Use a fixed pre-flight sequence:

1. Record file names, byte counts, SHA-256 hashes, export time, and capture boundary.
2. Validate encoding, format, headers, and record structure.
3. Validate fields without silently repairing identifiers or timestamps.
4. Detect duplicate identifiers and conflicting records.
5. Reconcile input counts against accepted and rejected populations.
6. Establish time coverage, gaps, and analysis cohorts.
7. Calculate incident metrics only from the explicitly selected population.

Keep original files immutable. Store normalized records separately with source file and record ordinal. For CSV, a record ordinal is not necessarily a physical line number because quoted fields can contain newlines.

Do not confuse valid data with complete data. A syntactically perfect export may omit a proxy shard, exclude timed-out requests, or end halfway through a minute.

## Define the measurement before reporting it

For sorted observations \(x_1,\ldots,x_n\), use the nearest-rank convention:

\[
P_q = x_{\lceil qn\rceil}
\]

Declare this convention in every report. Other interpolation methods can produce different answers on the same sample.

Compute latency percentiles from individual requests. Never average per-minute or per-instance percentiles into a daily percentile.

Use half-open windows, such as `[10:00:00Z, 10:01:00Z)`, and group by service and normalized route before examining fleet aggregates. Always display sample count beside P95 and P99. With 20 observations, nearest-rank P99 is simply the maximum.

Report all-request latency and successful-request latency separately. Fast failures can make overall latency look better while customer experience deteriorates.

# Chapter 2: Core Validation & Reconciliation Rules for request_id

`request_id` is the audit’s identity anchor. Treat it as an opaque string, not a numeric value or a field that can be casually cleaned.

## Preserve identity exactly

The identifiers `000123`, `123`, and `ABC123` are distinct. Preserve case and leading zeros. Reject leading or trailing whitespace under a strict contract rather than trimming it invisibly.

For JSONL, require identifiers to be JSON strings. A numeric identifier may already have lost precision in an upstream system; converting it back to a string does not recover the original value.

Establish identifier uniqueness across the complete audit scope. If identifiers are unique only within individual services, the source does not satisfy the declared primary key. Either introduce a documented canonical identifier before ingestion or change the source contract. Do not quietly substitute `(service, request_id)` while still claiming `request_id` is unique.

## Separate duplicates from conflicts

An exact duplicate has the same identifier and the same normalized required values. It often results from overlapping exports or repeated delivery.

A conflicting duplicate has the same identifier but different required values. Different status codes, timestamps, or durations may indicate identifier reuse, inconsistent capture boundaries, or partial updates.

Handle them differently:

- Retain one exact copy and count the suppressed copies.
- Quarantine every record associated with a conflicting identifier.
- Preserve provenance for all copies.
- Prevent final sign-off until conflicts are explained.

“Last record wins” is unsuitable for incident evidence. File ordering is not a reliable authority rule.

Normalize only declared equivalences. UTC conversion can make two offset timestamps equivalent. Numeric values `10` and `10.0` can represent the same duration. Service names and routes should remain exact unless a versioned mapping explicitly says otherwise.

## Reconcile the population

Maintain mutually exclusive counters:

\[
N_{\text{parsed}} =
N_{\text{invalid}} +
N_{\text{conflict records}} +
N_{\text{exact copies suppressed}} +
N_{\text{accepted}}
\]

Count conflicting groups separately from conflicting records. Three records sharing one conflicting identifier represent one conflicting group and three quarantined records.

If parsing fails halfway through a file, the parsed count is only a partial count. Mark the run incomplete; do not present the equation as reconciliation of the entire file.

Compare accepted records with independent source totals where available. Include exporter counts, proxy request counters, shard inventories, and expected time coverage. Differences need explanations, not rounding allowances.

## Validate timing semantics

Both duration fields must be finite and nonnegative. Reject `NaN`, infinity, booleans, blank strings, and unit-bearing values such as `120ms`.

Treat `upstream_ms > latency_ms` according to the instrumentation contract. It is invalid when upstream time measures a single interval contained within total elapsed time. It can be legitimate when the field sums overlapping parallel calls.

Likewise, `latency_ms - upstream_ms` is not automatically application processing time. It may include queueing, connection setup, response transfer, and instrumentation differences.

## Separate request failures from business failures

Calculate:

\[
\text{5xx rate} =
\frac{\text{accepted requests with status 500–599}}
{\text{all accepted requests in the same cohort}}
\]

Label this as a request-attempt metric. It is not necessarily a failed-order or failed-payment rate.

The required schema cannot prove retry chains. Rising volume, repeated failures, and synchronized latency peaks can suggest retries, but confirmation requires optional fields such as logical operation ID, attempt number, upstream target, or trace ID.

Never join requests by similar timestamps and call the result a confirmed retry sequence.

# Chapter 3: Real-World Edge Cases, Rounding Traps & Incident Postmortems

Tail metrics are sensitive to small changes in population, precision, and window placement. Preserve raw precision through validation and calculation. Round only for display.

## Common traps

| Condition | Misleading conclusion | Required treatment |
|---|---|---|
| Durations rounded before ranking | Requests near a threshold appear identical | Rank original values; round the result |
| P99 shown without sample size | One outlier appears statistically stable | Show count and the percentile method |
| Successful requests only | A timeout wave disappears | Publish all-request and success-only distributions |
| Duplicate export segments | Traffic and error counts appear inflated | Deduplicate by the declared identity contract |
| Query strings embedded in routes | One endpoint becomes thousands of groups | Apply a versioned route mapping |
| Mixed seconds and milliseconds | One producer appears exceptionally fast | Reject incompatible units; fix the export |
| Completion-time timestamps | Long requests shift into later buckets | State the timestamp convention |
| Missing terminal records | Latency appears better during overload | Check source completeness independently |

A displayed P99 of `100 ms` may represent `99.6 ms` or `100.4 ms`. For a strict threshold of greater than 100 milliseconds, those observations have different outcomes. Evaluate thresholds using unrounded values.

An average of route P99 values is not a fleet P99. A traffic-weighted average of those values is not a fleet P99 either. Recompute from observations or a documented mergeable distribution representation.

## Hypothetical postmortem: retry amplification

A checkout route experiences a brief upstream timeout. Clients immediately retry; the application also retries. Attempt volume rises faster than logical checkout volume.

| Measure | Baseline five minutes | Incident five minutes |
|---|---:|---:|
| Accepted request attempts | 12,000 | 31,000 |
| 5xx attempts | 120 | 6,200 |
| 5xx rate | 1.0% | 20.0% |
| P99 latency | 420 ms | 2,900 ms |
| Logical operations, from separate telemetry | 11,500 | 11,800 |

The access logs establish higher attempt volume and worse outcomes. The separate logical-operation counter supports an amplification diagnosis.

The corrective action is bounded retry budgets, jittered backoff, and coordination between retrying layers. Increasing timeouts alone can increase concurrent work and deepen the overload.

Finance should not multiply 6,200 failed attempts by average order value. Several attempts can belong to one purchase, and some purchases eventually succeed. Estimate business impact from deduplicated business outcomes, with an explicit attribution window.

## Hypothetical postmortem: upstream bottleneck

An inventory route’s total latency rises alongside upstream duration. Within requests exceeding the latency threshold, upstream time accounts for most elapsed time.

This supports investigation of the dependency, but it does not establish whether the cause is dependency execution, connection acquisition, network delay, or client-side waiting. Instrumentation semantics determine what the field includes.

Compare per-request upstream shares and distributions across the same cohort. Do not subtract upstream P99 from total P99: those percentile values may represent different requests.

## Hypothetical postmortem: hidden error burst

A five-minute report shows a 2% 5xx rate. A ten-second interval inside that window experienced a 60% failure rate.

Use aligned minute buckets for routine reporting and shorter buckets for diagnosis. Add a rolling window to expose bursts split across bucket boundaries.

Apply a minimum request count and a minimum error count before escalating on a rate. One failure among two requests warrants different treatment from 600 failures among 1,000 requests.

Record both absolute and relative changes. “Errors tripled” can describe an increase from one to three; “600 additional failures in ten seconds” describes a materially different incident.

# Chapter 4: Offline Browser Workbench Architecture & Zero-Upload Security

A zero-upload workbench processes selected files entirely on the operator’s device. That claim must be enforced by architecture and tested behavior.

## Keep the application self-contained

Distribute a versioned static bundle containing all scripts, styles, and parser code. Remove external fonts, analytics, remote dependencies, crash reporting, and update checks.

Read files through an explicit file picker or drag-and-drop action. Parse and aggregate in a worker so large inputs do not freeze the interface.

Use a restrictive Content Security Policy. Set `connect-src 'none'`, disallow objects, and restrict scripts and workers to the bundled application’s requirements. A worker created from a blob requires an explicitly permitted blob worker source.

Content policy is defense in depth, not proof of zero upload. Test the release with network inspection and with networking disabled. Record the application version and artifact hash in exported reports.

## Parse incrementally and expose limits

Streaming reduces input-buffer memory, but exact deduplication and exact percentiles still consume memory proportional to retained state.

Track bytes processed, parsed records, invalid records, duplicates, and estimated retained memory. Stop cleanly when a documented limit is reached. Offer the local CLI as the path for larger files.

If approximate quantiles are available, make them an explicit mode with a documented algorithm and error characteristics. Never switch from exact to approximate results silently.

CSV parsing must support quoted delimiters, escaped quotes, and embedded newlines. Splitting text on commas or newline characters is not a CSV parser. Carry incomplete characters and partial records between streaming chunks.

## Design the workbench around evidence

Provide four views:

1. **Pre-flight:** schema, validation errors, duplicate conflicts, and coverage.
2. **Timeline:** request counts, 5xx counts, rates, P95, and P99.
3. **Cohorts:** service and route comparisons with sample counts.
4. **Evidence:** contributing records and source ordinals.

Every chart should expose its filter, time window, timestamp convention, and denominator. Clicking a burst should reveal the records used to calculate it.

Compare an incident interval with a suitable baseline, accounting for route mix and time-of-day effects. A fleet percentile can move simply because traffic shifts toward a slower endpoint.

## Treat logs as sensitive input

Routes and identifiers can contain personal data, credentials, or customer references. Render every value as text. Never insert log fields as HTML.

Keep data in memory by default. Avoid local storage, IndexedDB, and service-worker caches for uploaded logs. Clear application references on reset, while acknowledging that browser memory cannot provide guaranteed forensic erasure.

Protect spreadsheet exports against formula interpretation. For fields beginning with spreadsheet formula triggers, produce a clearly labeled sanitized export; preserve the original evidence separately.

Zero upload describes application behavior. It does not prevent browser extensions, endpoint monitoring, screenshots, or an operator’s deliberate export. State that boundary precisely.

# Chapter 5: Automating Audits with Zero-Dependency Python 3 CLI & CI/CD Exit Codes

The CLI should produce reproducible results using only Python’s standard library. Separate validation failures from incident thresholds: corrupted evidence and degraded service require different responses.

The following core functions provide strict field validation and exact nearest-rank percentiles. They are building blocks for a CLI, not a complete ingestion program.

```python
import math
import re
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation

FIELDS = (
    "request_id", "timestamp", "service", "route",
    "status_code", "latency_ms", "upstream_ms",
)

STAMP = re.compile(
    r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}"
    r"(?:\.\d{1,6})?(?:Z|[+-]\d{2}:\d{2})"
)

NUMBER = re.compile(
    r"[+-]?(?:\d+(?:\.\d*)?|\.\d+)"
    r"(?:[eE][+-]?\d+)?"
)

def text_field(value, name):
    if not isinstance(value, str):
        raise ValueError(f"{name}: expected string")
    if not value or value != value.strip():
        raise ValueError(f"{name}: empty or outer whitespace")
    return value

def duration(value, name):
    if isinstance(value, bool):
        raise ValueError(f"{name}: boolean is invalid")
    raw = str(value)
    if not NUMBER.fuテキスト処理系atch(raw):
        raise ValueError(f"{name}: invalid decimal")
    try:
        result = Decimal(raw)
    except InvalidOperation as exc:
        raise ValueError(f"{name}: invalid number") from exc
    if not result.is_finite() or result < 0:
        raise ValueError(f"{name}: must be finite and nonnegative")
    return result

def validate(row):
    missing = set(FIELDS) - row.keys()
    if missing:
        raise ValueError(f"missing fields: {sorted(missing)}")

    request_id = text_field(row["request_id"], "request_id")
    service = text_field(row["service"], "service")
    route = text_field(row["route"], "route")
    stamp = text_field(row["timestamp"], "timestamp")

    if not STAMP.fuテキスト処理系atch(stamp) or stamp.endswith("-00:00"):
        raise ValueError("timestamp: unsupported or unknown offset")
    timestamp = datetime.fromisoformat(
        stamp.replace("Z", "+00:00")
    ).astimezone(timezone.utc)

    status_text = str(row["status_code"])
    if not re.fuテキスト処理系atch(r"[1-5][0-9]{2}", status_text):
        raise ValueError("status_code: expected integer 100–599")

    return (
        request_id, timestamp, service, route, int(status_text),
        duration(row["latency_ms"], "latency_ms"),
        duration(row["upstream_ms"], "upstream_ms"),
    )

def percentile(values, q):
    if not 0 < q <= 1:
        raise ValueError("q must be in (0, 1]")
    ordered = sorted(values)
    if not ordered:
        return None
    return ordered[math.ceil(q * len(ordered)) - 1]
```

This timestamp profile deliberately accepts at most microsecond precision and rejects leap-second notation. Declare those limits; never truncate higher precision silently.

## Implement ingestion defensively

Use `csv.reader` with `newline=""`, explicit delimiters, strict parsing, and UTF-8 decoding. Permit a leading byte-order mark with `utf-8-sig`. Validate header uniqueness before mapping fields, then require every record to have the header’s field count.

For JSONL, parse one object per nonblank line. Decide explicitly whether blank lines are errors. Reject duplicate object keys and nonstandard numeric constants:

```python
import json
from decimal import Decimal

def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate JSON key: {key}")
        result[key] = value
    return result

def reject_constant(value):
    raise ValueError(f"nonstandard JSON number: {value}")

def parse_jsonl_record(line):
    value = json.loads(
        line,
        parse_float=Decimal,
        parse_constant=reject_constant,
        object_pairs_hook=unique_object,
    )
    if not isinstance(value, dict):
        raise ValueError("expected JSON object")
    return value
```

Set configurable record-size and field-size limits. Reject oversized inputs with a clear diagnostic.

Group validated records by identifier before final aggregation. Once a conflict appears, quarantine the entire group, including earlier copies. A streaming implementation must retract earlier contributions or delay aggregation.

For large datasets, use the standard-library `sqlite3` module for indexed staging and external sorting. Protect temporary files because they contain log data, and delete them through a documented cleanup path.

## Make exit codes operational

| Code | Meaning | Pipeline response |
|---|---|---|
| `0` | Audit complete; configured checks pass | Publish report |
| `1` | Valid population breaches incident thresholds | Route to incident handling |
| `2` | Schema, validation, identity, or required coverage failure | Block trusted sign-off |
| `3` | Usage, input/output, or execution failure | Repair invocation or environment |

Give incomplete execution precedence over data-quality failure, and data-quality failure precedence over threshold breaches. Preserve all findings in the report even when only one exit code can be returned.

Write machine-readable JSON to standard output and diagnostics to standard error. Include schema version, file hashes, configuration, counters, coverage, cohort sizes, quantile method, and unrounded threshold outcomes. Represent decimal results as documented strings when exact serialization matters.

CI should exercise quoted CSV fields, duplicate headers, conflicting identifiers, timestamp boundaries, invalid numeric values, empty cohorts, and known percentile fixtures. Thresholds require minimum sample sizes; insufficient samples should produce an explicit inconclusive result, not a passing latency claim.

# Chapter 6: Standard Operating Checklist & Executive Sign-Off Template

The operating procedure should make evidence quality visible before anyone interprets customer impact.

## Incident operating checklist

**Acquire and preserve**

- Select the capture boundary, services, routes, and UTC interval.
- Export a baseline and an incident interval with surrounding context.
- Record hashes, exporter settings, source totals, and known gaps.
- Keep originals immutable and restrict access.

**Validate and reconcile**

- Confirm field semantics, units, timezone offsets, and identifier scope.
- Resolve malformed records and conflicting identifiers.
- Reconcile every parsed record to a disposition.
- Verify coverage against independent counters or export manifests.
- Mark provisional results clearly when completeness remains uncertain.

**Locate the failure**

- Inspect volume, error counts, error rates, and tail latency together.
- Break down by service, route, status class, and time bucket.
- Inspect shorter and rolling windows around bursts.
- Compare upstream timing within the same requests.
- Distinguish observed retry symptoms from confirmed retry chains.

**Mitigate and verify**

- Record the mitigation, owner, deployment time, and expected effect.
- Observe a predefined recovery interval under representative traffic.
- Check success rate, throughput, and tail latency together.
- Verify that recovery is not merely fast rejection or missing logs.
- Reconcile business outcomes separately from request attempts.

## Executive sign-off template

**Incident:**  
**Accountable owner:**  
**Technical reviewer:**  
**Analysis version and evidence hashes:**  
**Incident interval and timestamp convention:**  
**Baseline interval:**  

**Evidence status:** Complete / Provisional / Incomplete

State accepted requests, invalid records, suppressed duplicates, conflicting records, missing sources, and coverage gaps. Explain whether those limitations could change the conclusion.

**Customer impact**

Describe affected journeys, services, routes, regions where available, and duration. Separate confirmed failed business operations from failed request attempts.

**Technical findings**

Record baseline and incident P95/P99, sample counts, 5xx counts and rates, the strongest supporting evidence, and unresolved causal questions.

**Financial assessment**

State confirmed lost transactions, recovered transactions, refunds or credits, and incremental infrastructure costs where supported. Separate realized loss from delayed or at-risk revenue. Provide assumptions and a range when attribution is uncertain.

**Mitigation and recovery**

Identify the action, owner, execution time, recovery window, and measured result. Include residual risks and rollback conditions.

**Follow-up commitments**

Assign each corrective action an owner, due date, and acceptance criterion. Include source-instrumentation fixes when the investigation exposed evidence gaps.

**Decision:** Closed / Monitoring / Further investigation required  
**Technical approval:**  
**Business approval:**  
**Approval timestamp:**  

Sign-off should certify the scope and quality of the evidence, the observed recovery, and ownership of remaining work. Where causality remains uncertain, say so explicitly and identify the measurement that will resolve it.
