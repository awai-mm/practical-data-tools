# Production Log P95/P99 Latency & Error Burst Triage Kit

**Zero-Upload Browser Log Analyzer, Stdlib CLI & Incident Response Handbook**

- **Suggested Price**: USD 17
- **Focus**: Pinpointing tail-latency spikes, retry storms, upstream bottlenecks, and 5xx error clusters from raw CSV/TSV/JSONL access logs.
- **Included**:
  1. `en-pkg-04-log-latency-burst-analyzer_workbench.html` — 100% Offline Browser Workbench (zero external requests)
  2. `en_pkg_04_log_latency_burst_analyzer_cli.py` — Zero-Dependency Python 3 CLI Auditor
  3. `en-pkg-04-log-latency-burst-analyzer-kdp-en-v1.epub` — Full Practical Engineering Handbook (EPUB3)
  4. `samples/` & `test_en_package.py` — Sample datasets and automated verification suite
