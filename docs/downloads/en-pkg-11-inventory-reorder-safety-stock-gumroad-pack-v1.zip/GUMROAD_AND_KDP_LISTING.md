# Inventory Reorder Point, Lead-Time Variance & Safety Stock Kit

**Supply Chain Browser Calculator, CLI Planner & Operations Handbook**

- **Suggested Price**: USD 19
- **Focus**: Preventing stockouts and dead-stock cash traps with statistical safety stock, reorder point (ROP), and EOQ formulas.
- **Included**:
  1. `en-pkg-11-inventory-reorder-safety-stock_workbench.html` — 100% Offline Browser Workbench (zero external requests)
  2. `en_pkg_11_inventory_reorder_safety_stock_cli.py` — Zero-Dependency Python 3 CLI Auditor
  3. `en-pkg-11-inventory-reorder-safety-stock-kdp-en-v1.epub` — Full Practical Engineering Handbook (EPUB3)
  4. `samples/` & `test_en_package.py` — Sample datasets and automated verification suite
