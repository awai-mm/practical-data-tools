# Chapter 1: Why Spreadsheets Fail in Production & The Pre-Flight Audit Pattern

Inventory policy converts uncertain demand into commitments of cash, storage, and customer service. A reorder point that is too low creates stockouts, expedites, and missed sales. An order quantity that is too high converts working capital into aging stock.

The arithmetic is straightforward. The difficult work is preserving consistent definitions, detecting broken inputs, and separating a calculated recommendation from an authorized purchase.

Spreadsheets become unreliable when those controls remain implicit. Typical failures include:

- A formula references yesterday’s lead time but today’s demand.
- A pasted value overwrites a safety-stock formula.
- Demand is measured in cases while inventory is measured in units.
- Duplicate SKUs cause the same item to be purchased twice.
- Hidden rows exclude discontinued products from reconciliation.
- Rounded intermediate values change an order decision.
- A service percentage is entered where a normal-distribution z-score is expected.

The remedy is a pre-flight audit: a mandatory validation and reconciliation stage before any purchasing recommendation becomes actionable.

## Establish the input contract

Every CSV must contain these columns:

```csv
item_sku,daily_demand_avg,demand_std_dev,lead_time_days,service_level_z,current_on_hand,unit_cost
WIDGET-001,40,9,12,1.645,390,18.50
```

The primary key is `item_sku`. Demand and inventory quantities must use one base stocking unit per SKU. Demand averages, demand standard deviations, and lead times must share the same time basis.

For example, a daily demand estimate based on operating days cannot be combined directly with calendar-day lead time. Either convert demand to a calendar-day basis or calculate lead time using the corresponding operating calendar.

Record currency, inventory snapshot time, demand measurement window, and calendar convention in a companion manifest. The required columns do not express these assumptions.

## Calculate the baseline policy

Let:

- \(d\): average daily demand.
- \(\sigma_d\): standard deviation of daily demand.
- \(L\): replenishment lead time in days.
- \(z\): selected service-level z-score.

For fixed lead time and independent, identically distributed daily demand:

\[
\sigma_{LT}=\sigma_d\sqrt{L}
\]

\[
SS=z\sigma_{LT}
\]

\[
ROP=dL+SS
\]

Safety stock covers uncertainty. Expected lead-time demand covers normal consumption. Neither component should be silently substituted for the other.

For the sample item:

\[
SS=1.645(9)\sqrt{12}\approx51.29
\]

\[
ROP=40(12)+51.29\approx531.29
\]

For whole-unit stock, the operational reorder point is 532 units. Retain the unrounded value in the audit output.

A z-score of approximately 1.645 corresponds to a 95% one-sided normal cycle-service target under the model assumptions. It does not mean that 95% of units demanded will be supplied immediately. That second measure is fill rate and requires a different calculation.

## Apply the pre-flight sequence

Run four gates in order:

1. **Structure:** Parse the file, confirm required headers, and reject malformed records.
2. **Validity:** Check identity, numeric values, units, and permitted ranges.
3. **Reconciliation:** Compare counts, inventory value, and material changes with the source system.
4. **Policy suitability:** Confirm that the statistical model fits the item’s demand and supply behavior.

A failed gate blocks purchase-ready output. Diagnostic reports can still be produced, but they must clearly identify the blocking conditions.

# Chapter 2: Core Validation & Reconciliation Rules for item_sku

## Treat identifiers as business keys

Read `item_sku` as text. Never convert it to a number. `000472` and `472` may represent different products.

Reject empty identifiers, leading or trailing whitespace, embedded control characters, and duplicate keys. Preserve case unless the authoritative item master explicitly defines a case-insensitive identity rule.

Do not silently trim or uppercase identifiers during an audit. Such transformations can merge distinct records or conceal an upstream integration defect. Offer a separate correction workflow that records both the original and proposed identifier.

SKU uniqueness applies to the dataset’s declared scope. If inventory is managed by warehouse, the required schema must represent one warehouse per file or an explicitly approved pooled inventory position. Adding a location column without changing the key does not resolve the ambiguity.

## Validate every numeric field

Use the following baseline rules:

- `daily_demand_avg`: finite and greater than or equal to zero.
- `demand_std_dev`: finite and greater than or equal to zero.
- `lead_time_days`: finite and greater than or equal to zero.
- `service_level_z`: finite and greater than or equal to zero.
- `current_on_hand`: finite and greater than or equal to zero.
- `unit_cost`: finite and greater than or equal to zero.

Reject blanks, infinity, and not-a-number values. Do not interpret missing values as zero.

Negative on-hand balances sometimes occur in operational systems. They should trigger reconciliation rather than silently enter this baseline model. If backorders are legitimate, model them explicitly in an extended inventory-position calculation.

Zero values require contextual review. Zero lead time can eliminate calculated safety stock while ignoring receiving and inspection delays. Zero cost can be legitimate for consigned stock but misleading for cash exposure. A zero demand average with positive demand variability is inconsistent with a history of nonnegative demand and warrants investigation.

Set additional warning thresholds through policy, not universal constants. A large z-score or unusually long lead time may be correct, but should require supporting evidence.

## Reconcile quantities and money separately

Check the input against the source snapshot:

- Number of item records.
- Number of unique SKUs.
- Inventory value by currency and ownership category.
- Missing, new, and discontinued items.
- Material changes in demand, lead time, and stock.

Calculate inventory value as:

\[
V=\sum_i on\_hand_i\times unit\_cost_i
\]

Use decimal arithmetic for financial reconciliation. State whether cost represents standard cost, average cost, replacement cost, or landed cost. These bases are not interchangeable.

A grand total of physical quantities across unrelated items has limited meaning. It can detect transfer defects, but it is not a useful business measure when it combines bolts, drums, and meters.

## Distinguish on-hand from inventory position

The required schema contains physical stock, not inventory position.

A common purchasing definition is:

\[
IP=on\_hand+eligible\_open\_orders-backorders
\]

Reservations may also reduce the position when they represent obligations not already included elsewhere. Document the convention to prevent double subtraction.

A continuous-review reorder signal normally occurs when:

\[
IP\le ROP
\]

With only `current_on_hand`, the calculator can report **on-hand below ROP; purchasing review required**. It cannot safely conclude that a new purchase order is necessary.

Open orders arriving too late may also fail to protect service, even when aggregate inventory position looks sufficient. Time-phased supply and demand review remains necessary for urgent exceptions.

# Chapter 3: Real-World Edge Cases, Rounding Traps & Incident Postmortems

## Lead-time variance changes the buffer

If lead time varies independently of daily demand, and daily demand observations are independent with stable mean and variance:

\[
Var(D_{LT})=\bar L\sigma_d^2+d^2\sigma_L^2
\]

\[
SS=z\sqrt{\bar L\sigma_d^2+d^2\sigma_L^2}
\]

Here, \(\sigma_L\) is the standard deviation of replenishment lead time. Measure lead time from the approved replenishment trigger to stock becoming usable, including applicable approval, transit, receiving, and inspection delays.

The required CSV has no lead-time standard deviation. Therefore, its default calculation assumes fixed lead time. Display that limitation prominently. Enable the variable-lead-time model only when an explicit supplemental field or keyed dataset supplies \(\sigma_L\).

Using the sample item with \(\sigma_L=3\) days:

| Model | Lead-time demand variance | Safety stock | Whole-unit ROP |
|---|---:|---:|---:|
| Fixed lead time | 972 | 51.29 | 532 |
| Variable lead time | 15,372 | 203.96 | 684 |

The difference is operationally significant. Ignoring supplier variability understates the buffer by approximately 153 units.

If demand surges coincide with supplier delays, the independence assumption fails. Use historical joint scenarios or a suitable simulation to estimate protection requirements.

## EOQ controls quantity, not timing

Economic order quantity balances ordering cost against holding cost:

\[
EOQ=\sqrt{\frac{2DS}{H}}
\]

Where:

- \(D\): annual demand in base units.
- \(S\): incremental cost per order.
- \(H\): annual holding cost per unit.

When a carrying-rate model is appropriate:

\[
H=unit\_cost\times annual\_carrying\_rate
\]

The required CSV cannot calculate EOQ by itself. Annualization days, ordering cost, and holding cost or carrying rate must be supplied as explicit configuration.

Suppose demand is 40 units per day over 365 days, ordering cost is 60 currency units, and annual holding cost is 4.625 per unit:

\[
EOQ\approx615.48
\]

For a pack size of 24, compare feasible quantities such as 600 and 624 using:

\[
AnnualRelevantCost(Q)=\frac{DS}{Q}+\frac{HQ}{2}
\]

Do not automatically round EOQ upward. Compare feasible choices, then apply minimum-order quantities, shelf life, storage capacity, and cash limits.

EOQ assumes stable demand, fixed ordering cost, no quantity discounts, and the classical replenishment conditions. It is a planning reference, not an unconditional buying instruction.

## Handle edge cases explicitly

| Condition | Failure risk | Required treatment |
|---|---|---|
| Intermittent demand | Normal approximation misstates tail demand | Evaluate empirical lead-time demand or an intermittent-demand method |
| Stockout-censored sales | Observed sales understate true demand | Incorporate lost-sales estimates or mark demand as censored |
| Promotion or season change | Historical average becomes stale | Use a dated forecast and relevant forecast-error distribution |
| Perishable stock | Safety stock expires before use | Apply shelf-life and aging constraints |
| Weekly ordering | Lead-time-only buffer misses review delay | Use a periodic-review policy covering lead time plus review interval |
| Fractional stocking units | Integer rounding overstates requirements | Round to the approved measurement increment |

For forecast-driven planning, variability should reflect uncertainty around the forecast over the protection period. Raw daily sales variation can confuse predictable seasonality with uncertainty.

## Keep rounding at the boundary

Retain full precision through calculation. Round the final ROP upward to the permitted stock increment. For example, an increment of 0.25 requires:

\[
ROP_{operational}=0.25\left\lceil ROP/0.25\right\rceil
\]

Round cash displays separately from quantity decisions. Do not round safety stock and expected demand independently before adding them.

## Illustrative incident postmortems

**Duplicate replenishment:** A report flagged 390 units on hand against a 532-unit ROP. A buyer ordered despite 400 units already inbound. The corrective action was to label the report as an on-hand review and require an open-order check before release.

**Dead stock after launch:** A temporary launch surge became the permanent demand average. Large orders continued after sales normalized. The corrective action was to date promotional overrides, expire them automatically, and review aging exposure before renewal.

**False confidence from a service label:** A dashboard displayed “95% service” beside a cycle-service calculation. Management interpreted it as fill rate. The corrective action was to name the exact metric and measure realized customer outcomes separately.

# Chapter 4: Offline Browser Workbench Architecture & Zero-Upload Security

An offline workbench should process inventory files entirely on the user’s device. Its security claim must describe observable behavior, not merely the absence of an upload button.

## Separate the processing stages

Use five components:

1. **File reader:** Accept a local CSV through a browser file picker.
2. **Parser:** Handle quoting, escaped quotes, line endings, and encoding.
3. **Validator:** Produce field-level and file-level diagnostics.
4. **Calculation engine:** Apply versioned formulas and explicit assumptions.
5. **Exporter:** Generate results and an audit manifest locally.

Never parse CSV by splitting lines on commas. Quoted fields can legally contain commas and line breaks.

Keep calculation functions deterministic. The same validated inputs and configuration should produce the same outputs in the browser and CLI, subject to documented numeric tolerances.

For large files, move parsing and calculation into a worker so the interface remains responsive. Set file-size and record-count limits and explain any rejected file.

## Make model limitations visible

Display the inventory snapshot time, calendar basis, quantity increment, and chosen variance model beside the results.

Show separate indicators for:

- Input validity.
- Model suitability.
- On-hand position relative to ROP.
- Purchasing review status.

An item can pass numeric validation while remaining unsuitable for the normal approximation. A green validation badge must not imply purchase authorization.

Present expected lead-time demand, safety stock, and final ROP as separate values. This makes unusually large buffers explainable.

## Enforce zero-upload operation

Package scripts, styles, fonts, and documentation locally. Exclude analytics, external error reporting, remote fonts, and third-party runtime resources.

Apply a restrictive Content Security Policy, including `connect-src 'none'`, and restrict script, frame, object, and form behavior to the minimum required. Verify the complete application’s network behavior; a single directive is not proof of zero transmission.

Avoid persistent browser storage by default. If local recovery is offered, make it opt-in and provide a clear delete action. Explain that exported files and browser-managed memory have their own retention characteristics.

Render imported text with safe text APIs. Never insert SKU values as executable markup.

Spreadsheet exports need another control: identifiers beginning with formula-sensitive characters can be interpreted as formulas when opened in spreadsheet software. Offer a clearly labeled spreadsheet-safe export with documented escaping, alongside a lossless machine-readable export.

## Produce a reproducible audit package

Export:

- Original input hash.
- Calculation and schema versions.
- Configuration and model assumptions.
- Validation findings.
- Computed recommendations.
- UTC execution time.

A hash supports file identification and integrity checks; it does not anonymize the underlying dataset. Keep exported packages under the same access controls as inventory and cost records.

# Chapter 5: Automating Audits with Zero-Dependency Python 3 CLI & CI/CD Exit Codes

A CLI makes pre-flight checks repeatable at ingestion, scheduled refresh, and release boundaries. Python’s standard library provides CSV parsing, decimal arithmetic, hashing, and structured output without external packages.

Define stable exit semantics:

| Exit code | Meaning | Pipeline action |
|---|---|---|
| 0 | Audit passed; findings may include stock review flags | Continue to reconciliation and approval |
| 2 | Input structure or validation failed | Block publication |
| 3 | Configuration invalid | Correct configuration |
| 4 | I/O or unexpected execution failure | Investigate infrastructure or implementation |

A low-stock signal is a valid business result, not a failed execution. Keep business findings separate from technical status.

The following baseline implementation validates the required schema and computes fixed-lead-time ROP. It assumes whole-unit stocking and does not calculate EOQ or authorize orders.

```python
#!/usr/bin/env python3
import csv
import hashlib
import io
import json
import math
import sys
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation

FIELDS = (
    "item_sku", "daily_demand_avg", "demand_std_dev",
    "lead_time_days", "service_level_z",
    "current_on_hand", "unit_cost",
)

def audit(path):
    with open(path, "rb") as stream:
        raw = stream.read()

    text = raw.decode("utf-8-sig")
    reader = csv.DictReader(io.StringIO(text, newline=""), strict=True)
    headers = reader.fieldnames

    if not headers or len(headers) != len(set(headers)):
        raise ValueError("Missing or duplicate headers")
    missing = set(FIELDS) - set(headers)
    if missing:
        raise ValueError("Missing columns: " + ", ".join(sorted(missing)))

    seen, results, errors = set(), [], []
    for record, row in enumerate(reader, start=1):
        try:
            if None in row or any(v is None for v in row.values()):
                raise ValueError("Wrong field count")

            sku = row["item_sku"]
            if not sku or sku != sku.strip():
                raise ValueError("Empty or padded item_sku")
            if any(ord(c) < 32 or 127 <= ord(c) <= 159 for c in sku):
                raise ValueError("Control character in item_sku")
            if sku in seen:
                raise ValueError("Duplicate item_sku")
            seen.add(sku)

            values = {}
            for field in FIELDS[1:]:
                try:
                    value = Decimal(row[field])
                except InvalidOperation:
                    raise ValueError(f"{field}: invalid number")
                if not value.is_finite() or value < 0:
                    raise ValueError(f"{field}: finite nonnegative required")
                values[field] = value

            def numeric(field):
                number = float(values[field])
                if not math.isfinite(number):
                    raise ValueError(f"{field}: outside calculation range")
                return number

            demand = numeric("daily_demand_avg")
            deviation = numeric("demand_std_dev")
            lead = numeric("lead_time_days")
            z_score = numeric("service_level_z")
            expected = demand * lead
            safety = z_score * deviation * math.sqrt(lead)
            raw_rop = expected + safety
            if not math.isfinite(raw_rop):
                raise ValueError("Calculated ROP outside numeric range")
            rop = math.ceil(raw_rop)

            results.append({
                "item_sku": sku,
                "expected_lead_time_demand": expected,
                "safety_stock": safety,
                "rop_unrounded": raw_rop,
                "rop_units": rop,
                "on_hand_review":
                    values["current_on_hand"] <= Decimal(rop),
            })
        except (ValueError, OverflowError) as exc:
            errors.append({"record": record, "error": str(exc)})

    if not seen:
        errors.append({"record": None, "error": "No item records"})

    return {
        "schema_version": "1",
        "calculation_version": "1",
        "model": "fixed_lead_time",
        "quantity_increment": 1,
        "purchase_authorized": False,
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "input_sha256": hashlib.sha256(raw).hexdigest(),
        "errors": errors,
        "results": [] if errors else results,
    }

def main():
    if len(sys.argv) != 2:
        print("Usage: planner.py inventory.csv", file=sys.stderr)
        return 3
    try:
        report = audit(sys.argv[1])
    except (ValueError, UnicodeError, csv.Error) as exc:
        print(str(exc), file=sys.stderr)
        return 2
    except Exception as exc:
        print(f"Execution failed: {type(exc).__name__}", file=sys.stderr)
        return 4

    print(json.dumps(report, indent=2, allow_nan=False))
    return 2 if report["errors"] else 0

if __name__ == "__main__":
    sys.exit(main())
```

Run it as:

```text
python3 planner.py inventory.csv > audit.json
```

A production wrapper should write to a temporary artifact and publish it atomically only after the process succeeds and reconciliation passes. Output redirection alone does not provide that guarantee.

Extend the baseline with configurable quantity increments, decimal inventory valuation, manifest validation, lead-time variability, and policy warnings. Validate EOQ parameters separately: positive ordering and holding costs are required for the standard positive-demand formula.

Test meaningful boundaries: duplicate keys, quoted CSV fields, missing values, nonfinite numbers, zero demand, overflow, and ROP values near a stocking increment. Compare browser and CLI results using shared fixtures. Check final rounding separately from floating-point tolerances.

# Chapter 6: Standard Operating Checklist & Executive Sign-Off Template

Inventory policy needs named owners and a review cadence. Assign responsibility for demand estimates, supplier lead times, inventory balances, cost data, and purchasing release.

## Before every planning run

- Confirm the source system, snapshot time, currency, and warehouse scope.
- Verify that quantities use the correct stocking units.
- Check demand and lead-time calendar alignment.
- Confirm that the file passes structural and numeric validation.
- Reconcile item counts and inventory value.
- Investigate material changes from the previous approved run.
- Review stockout-censored history, promotions, and discontinued items.
- Confirm whether fixed or variable lead time is justified.

## Before releasing purchases

Check open orders, backorders, reservations, and expected receipt dates. Resolve conflicting inventory records before treating a recommendation as executable.

Apply pack sizes, supplier minimums, shelf life, and storage constraints. Evaluate order quantities against the approved cash budget. Record any override with an owner, reason, and expiration date.

Estimate incremental buffer investment as:

\[
\Delta BufferCash=\sum_i(SS_{new,i}-SS_{old,i})\times cost_i
\]

This is an inventory-policy estimate, not an immediate cash-flow forecast. Existing balances, order timing, payment terms, and consumption determine actual cash movement.

For stable classical replenishment, average inventory is approximately:

\[
AverageInventory\approx SS+\frac{Q}{2}
\]

Use that relationship to explain why increasing both service targets and order quantities can create a substantial cash commitment.

## After implementation

Track stockout events, realized fill rate, expedites, inventory turns, aging inventory, and write-offs. Compare predicted uncertainty with observed lead-time demand.

Review exceptions frequently and refresh parameters on an approved schedule. Trigger an earlier review after supplier changes, demand regime changes, or persistent service misses.

Do not respond to every stockout by raising the z-score. First establish whether the cause was estimation error, delayed purchasing, inaccurate balances, late supply, or a model mismatch.

## Executive sign-off template

**Planning period:**  
**Business unit and inventory scope:**  
**Input snapshot and hash:**  
**Calculation version:**  
**Accountable planning owner:**  

**Service policy:** State the target metric, target level, covered item classes, and approved exceptions.

**Statistical basis:** State the demand window, calendar convention, lead-time model, and treatment of censored or intermittent demand.

**Financial effect:** Record current inventory value, proposed buffer investment, expected order commitments, and budget headroom.

**Unresolved exceptions:** List affected SKUs, exposure, responsible owners, mitigation, and resolution dates.

**Release controls:** Confirm that open orders, receipt timing, pack sizes, shelf life, and purchasing authority have been checked.

**Decision:** Approve, approve with documented conditions, or return for correction.

**Operations approver and date:**  
**Finance approver and date:**  
**Next review date:**  

Approval applies to the stated dataset, assumptions, and period. Material changes require a new review. Keep the signed decision with the audit package so that every purchasing action can be traced to its evidence and accountable owner.
