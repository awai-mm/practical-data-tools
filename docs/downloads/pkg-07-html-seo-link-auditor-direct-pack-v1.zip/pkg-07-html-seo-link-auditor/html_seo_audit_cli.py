#!/usr/bin/env python3
# coding: utf-8
"""
Web公開前の事故を防ぐHTML構造・OGP・メタタグ・表記揺れ検品ハンドブック — 実務データ検品・クレンジング・集計 CLIツール
Python標準ライブラリのみで動作（外部パッケージ不要）
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import io
import json
from pathlib import Path
import re
import sys
from typing import Any
import unicodedata

DEFAULT_KEY_COLUMN = "page_id"
REQUIRED_COLUMNS = ["page_id", "url_path", "title_length", "meta_desc_length", "h1_count", "missing_alt_count", "dummy_link_count", "ogp_complete"]

NUMERIC_CANDIDATE_KEYWORDS = (
    "quantity", "unit_price", "amount", "stock", "subtotal", "tax",
    "withholding", "total", "paid", "price", "cost", "fee", "units",
    "minutes", "wage", "sales", "demand", "stddev", "lead_time", "moq",
    "users", "arpu", "margin", "churn", "cac", "length", "count",
    "requests", "latency", "hours", "multiplier", "rate", "cash",
    "inflow", "outflow",
)


def is_numeric_column(col_name: str) -> bool:
    c = col_name.strip().lower()
    if c in ("record_id", "invoice_id", "sku_id", "shift_id", "sku_code", "plan_id", "page_id", "endpoint_id", "task_id", "month_id", "sku", "staff_id"):
        return False
    return any(k in c for k in NUMERIC_CANDIDATE_KEYWORDS)


def is_date_column(col_name: str) -> bool:
    c = col_name.strip().lower()
    return "date" in c


def normalize_cell_text(raw: str) -> tuple[str, list[str]]:
    """
    Trim whitespace and normalize fullwidth alphanumeric characters.
    Returns (normalized_str, applied_warning_codes).
    """
    warnings: list[str] = []
    if raw != raw.strip() or "\u3000" in raw:
        warnings.append("W04_WHITESPACE_PADDING")
    trimmed = raw.replace("\u3000", " ").strip()

    # Check fullwidth digits or ASCII
    has_fullwidth = any("\uff01" <= ch <= "\uff5e" for ch in trimmed)
    if has_fullwidth:
        warnings.append("W05_FULLWIDTH_NUMERIC")
        trimmed = unicodedata.normalize("NFKC", trimmed)
    return trimmed, warnings


def normalize_date_str(val: str) -> tuple[str | None, list[str]]:
    """
    Normalize date string to YYYY-MM-DD and validate calendar existence.
    """
    warnings: list[str] = []
    v = val.strip()
    if not v:
        return None, []
    if "/" in v or "." in v:
        warnings.append("W07_DATE_FORMAT_VARIATION")
    m = re.match(r"^(\d{4})[\-/\.](\d{1,2})[\-/\.](\d{1,2})$", v)
    if not m:
        return None, warnings
    year, month, day = int(m.group(1)), int(m.group(2)), int(m.group(3))
    try:
        d = dt.date(year, month, day)
        iso = d.strftime("%Y-%m-%d")
        if iso != v and "W07_DATE_FORMAT_VARIATION" not in warnings:
            warnings.append("W07_DATE_FORMAT_VARIATION")
        return iso, warnings
    except ValueError:
        return None, warnings


def clean_numeric_str(val: str) -> tuple[float | None, str, list[str]]:
    """
    Remove currency symbols and thousand separators, returning (float_val, cleaned_str, warnings).
    """
    warnings: list[str] = []
    v = val.strip()
    if not v:
        return None, "", warnings
    if any(sym in v for sym in (",", "¥", "￥", "$", "円", "%")):
        warnings.append("W06_CURRENCY_OR_COMMA")
    cleaned = re.sub(r"[¥￥$円,\s%]", "", v)
    try:
        num = float(cleaned)
        if num.is_integer():
            return num, str(int(num)), warnings
        return num, str(num), warnings
    except ValueError:
        return None, cleaned, warnings


def inspect_and_clean(
    csv_text: str,
    key_column: str = DEFAULT_KEY_COLUMN,
    fix_mode: bool = False,
    delimiter: str | None = None,
) -> dict[str, Any]:
    if not delimiter:
        first_line = csv_text.splitlines()[0] if csv_text.splitlines() else ""
        delimiter = "\t" if ("\t" in first_line and "," not in first_line) else ","

    reader = csv.reader(io.StringIO(csv_text), delimiter=delimiter)
    all_rows = list(reader)
    if not all_rows:
        return {
            "ok": False,
            "total_rows": 0,
            "valid_rows": 0,
            "error_count": 1,
            "warning_count": 0,
            "issues": [{"row_number": 1, "record_id": "", "severity": "ERROR", "code": "E00_EMPTY_FILE", "column": "", "message": "ファイルが空です"}],
            "cleaned_csv": "",
            "summary_metrics": {},
        }

    headers = [h.strip() for h in all_rows[0]]
    data_rows = all_rows[1:]
    issues: list[dict[str, Any]] = []

    missing_cols = [c.strip() for c in REQUIRED_COLUMNS if c.strip() not in headers]
    if missing_cols:
        issues.append({
            "row_number": 1,
            "record_id": "HEADER",
            "severity": "ERROR",
            "code": "E01_MISSING_REQUIRED_COLUMN",
            "column": ",".join(missing_cols),
            "message": f"必須カラムが不足しています: {', '.join(missing_cols)}",
        })

    seen_keys: set[str] = set()
    cleaned_rows_out: list[list[str]] = []
    valid_row_count = 0

    total_quantity = 0.0
    total_amount = 0.0
    by_category: dict[str, dict[str, float]] = {}

    for idx, raw_row in enumerate(data_rows, start=2):
        if not any(cell.strip() for cell in raw_row):
            continue
        padded = list(raw_row) + [""] * max(0, len(headers) - len(raw_row))
        row_dict = {headers[i]: padded[i] for i in range(len(headers))}
        clean_dict = dict(row_dict)
        row_has_error = False

        # Step 1: Cell text normalization
        for col in headers:
            norm_val, w_codes = normalize_cell_text(row_dict[col])
            clean_dict[col] = norm_val
            for wc in w_codes:
                issues.append({
                    "row_number": idx,
                    "record_id": clean_dict.get(key_column, ""),
                    "severity": "WARNING",
                    "code": wc,
                    "column": col,
                    "message": f"文字正規化対象 ({wc}): '{row_dict[col]}' -> '{norm_val}'",
                })

        rec_id = clean_dict.get(key_column, "").strip()
        if not rec_id:
            row_has_error = True
            issues.append({
                "row_number": idx,
                "record_id": "(空欄)",
                "severity": "ERROR",
                "code": "E02_EMPTY_PRIMARY_KEY",
                "column": key_column,
                "message": f"主キー '{key_column}' が空欄です",
            })
        elif rec_id in seen_keys:
            row_has_error = True
            issues.append({
                "row_number": idx,
                "record_id": rec_id,
                "severity": "ERROR",
                "code": "E03_DUPLICATE_PRIMARY_KEY",
                "column": key_column,
                "message": f"主キー '{rec_id}' が重複しています",
            })
        else:
            seen_keys.add(rec_id)

        # Step 2: Date columns
        for col in headers:
            if is_date_column(col):
                iso_date, d_warns = normalize_date_str(clean_dict[col])
                for dw in d_warns:
                    issues.append({
                        "row_number": idx,
                        "record_id": rec_id,
                        "severity": "WARNING",
                        "code": dw,
                        "column": col,
                        "message": f"日付表記揺れを検出: '{clean_dict[col]}'",
                    })
                if iso_date is None:
                    row_has_error = True
                    issues.append({
                        "row_number": idx,
                        "record_id": rec_id,
                        "severity": "ERROR",
                        "code": "E08_INVALID_DATE_VALUE",
                        "column": col,
                        "message": f"不正な日付値です: '{clean_dict[col]}'",
                    })
                else:
                    clean_dict[col] = iso_date

        # Step 3: Numeric columns
        numeric_vals: dict[str, float] = {}
        for col in headers:
            if is_numeric_column(col):
                num_val, num_str, n_warns = clean_numeric_str(clean_dict[col])
                for nw in n_warns:
                    issues.append({
                        "row_number": idx,
                        "record_id": rec_id,
                        "severity": "WARNING",
                        "code": nw,
                        "column": col,
                        "message": f"数値書式記号を検出: '{clean_dict[col]}' -> '{num_str}'",
                    })
                if num_val is None:
                    row_has_error = True
                    issues.append({
                        "row_number": idx,
                        "record_id": rec_id,
                        "severity": "ERROR",
                        "code": "E09_NON_NUMERIC_VALUE",
                        "column": col,
                        "message": f"数値として解釈できません: '{clean_dict[col]}'",
                    })
                else:
                    clean_dict[col] = num_str
                    numeric_vals[col] = num_val
                    if num_val < 0:
                        row_has_error = True
                        issues.append({
                            "row_number": idx,
                            "record_id": rec_id,
                            "severity": "ERROR",
                            "code": "E11_NEGATIVE_VALUE",
                            "column": col,
                            "message": f"マイナス値が検出されました ({col}={num_str})",
                        })
                        if fix_mode:
                            clean_dict[col] = str(abs(int(num_val)) if num_val.is_integer() else abs(num_val))
                            numeric_vals[col] = abs(num_val)

        # Step 4: Cross-column business arithmetic check (quantity * unit_price == amount)
        if all(c in numeric_vals for c in ("quantity", "unit_price", "amount")):
            q = numeric_vals["quantity"]
            up = numeric_vals["unit_price"]
            amt = numeric_vals["amount"]
            expected_amt = q * up
            if q <= 0:
                issues.append({
                    "row_number": idx,
                    "record_id": rec_id,
                    "severity": "WARNING",
                    "code": "W12_NON_POSITIVE_QUANTITY",
                    "column": "quantity",
                    "message": f"数量が0以下です: {q}",
                })
            if abs(expected_amt - amt) > 1e-6:
                row_has_error = True
                exp_str = str(int(expected_amt)) if expected_amt.is_integer() else str(expected_amt)
                issues.append({
                    "row_number": idx,
                    "record_id": rec_id,
                    "severity": "ERROR",
                    "code": "E10_AMOUNT_MISMATCH",
                    "column": "amount",
                    "message": f"金額不一致: quantity({int(q)}) * unit_price({int(up)}) = {exp_str} != amount({int(amt)})",
                })
                if fix_mode:
                    clean_dict["amount"] = exp_str
                    numeric_vals["amount"] = expected_amt

        if not row_has_error:
            valid_row_count += 1

        # Decide whether row goes into cleaned output
        if fix_mode:
            # Skip rows with unrecoverable key/date errors (empty key, duplicate key, invalid date)
            unrecoverable = any(
                iss["row_number"] == idx and iss["code"] in ("E02_EMPTY_PRIMARY_KEY", "E03_DUPLICATE_PRIMARY_KEY", "E08_INVALID_DATE_VALUE", "E09_NON_NUMERIC_VALUE")
                for iss in issues
            )
            if not unrecoverable:
                cleaned_rows_out.append([clean_dict[h] for h in headers])
                q_v = numeric_vals.get("quantity", 1.0)
                a_v = numeric_vals.get("amount", 0.0)
                total_quantity += q_v
                total_amount += a_v
                cat = clean_dict.get("category") or "標準"
                bucket = by_category.setdefault(cat, {"rows": 0, "quantity": 0.0, "amount": 0.0})
                bucket["rows"] += 1
                bucket["quantity"] += q_v
                bucket["amount"] += a_v
        else:
            cleaned_rows_out.append([clean_dict[h] for h in headers])
            if not row_has_error:
                q_v = numeric_vals.get("quantity", 1.0)
                a_v = numeric_vals.get("amount", 0.0)
                total_quantity += q_v
                total_amount += a_v
                cat = clean_dict.get("category") or "標準"
                bucket = by_category.setdefault(cat, {"rows": 0, "quantity": 0.0, "amount": 0.0})
                bucket["rows"] += 1
                bucket["quantity"] += q_v
                bucket["amount"] += a_v

    err_count = sum(1 for i in issues if i["severity"] == "ERROR")
    warn_count = sum(1 for i in issues if i["severity"] == "WARNING")

    out_buf = io.StringIO()
    writer = csv.writer(out_buf, lineterminator="\n")
    writer.writerow(headers)
    for r in cleaned_rows_out:
        writer.writerow(r)

    return {
        "ok": err_count == 0,
        "total_rows": len(data_rows),
        "valid_rows": valid_row_count,
        "output_rows": len(cleaned_rows_out),
        "error_count": err_count,
        "warning_count": warn_count,
        "summary_metrics": {
            "total_quantity": int(total_quantity) if total_quantity.is_integer() else total_quantity,
            "total_amount": int(total_amount) if total_amount.is_integer() else total_amount,
            "by_category": by_category,
        },
        "issues": issues,
        "cleaned_csv": out_buf.getvalue(),
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Web公開前の事故を防ぐHTML構造・OGP・メタタグ・表記揺れ検品ハンドブック CLI検品・クレンジングツール")
    parser.add_argument("input_file", help="検査対象のCSVまたはTSVファイルパス")
    parser.add_argument("--key", default=DEFAULT_KEY_COLUMN, help=f"主キーカラム名 (既定: {DEFAULT_KEY_COLUMN})")
    parser.add_argument("--fix", action="store_true", help="自動クレンジング・金額再計算・不正行除外を適用する")
    parser.add_argument("--output-csv", help="クレンジング後のクリーンCSV出力先パス")
    parser.add_argument("--output-json", help="検品レポートJSONの出力先パス")
    parser.add_argument("--delimiter", help="区切り文字の明示指定 (省略時は自動判定)")
    args = parser.parse_args(argv)

    in_path = Path(args.input_file)
    if not in_path.is_file():
        sys.stderr.write(f"エラー: 入力ファイルが見つかりません: {in_path}\n")
        return 2

    raw_text = in_path.read_text(encoding="utf-8-sig")
    result = inspect_and_clean(
        csv_text=raw_text,
        key_column=args.key,
        fix_mode=args.fix,
        delimiter=args.delimiter,
    )

    if args.output_csv:
        out_csv_path = Path(args.output_csv)
        out_csv_path.parent.mkdir(parents=True, exist_ok=True)
        out_csv_path.write_text(result["cleaned_csv"], encoding="utf-8")

    report_payload = {k: v for k, v in result.items() if k != "cleaned_csv"}
    report_payload["input_file"] = str(in_path)
    report_payload["fix_mode"] = args.fix

    if args.output_json:
        out_json_path = Path(args.output_json)
        out_json_path.parent.mkdir(parents=True, exist_ok=True)
        out_json_path.write_text(json.dumps(report_payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    print(json.dumps(report_payload, ensure_ascii=False, indent=2))
    if args.fix and args.output_csv:
        return 0
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
