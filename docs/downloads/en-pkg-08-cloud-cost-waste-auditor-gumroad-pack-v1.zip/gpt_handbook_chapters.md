# Chapter 1: Why Spreadsheets Fail in Production & The Pre-Flight Audit Pattern

Cloud cost optimization starts with evidence that the billing data is complete, internally consistent, and suitable for the decision being proposed. A workbook can produce an impressive savings total while silently dropping resources, mixing currencies, or comparing incompatible prices.

Spreadsheets become unreliable production controls when:

- Imports convert resource identifiers into numbers or dates.
- Formulas omit newly appended rows.
- Filters conceal exceptions.
- Multiple people edit assumptions without recording changes.
- Display formatting hides fractions that materially affect totals.
- Cached results outlive the source export.
- Monthly averages are mistaken for continuous workload demand.

The answer is a repeatable pre-flight audit: validate the export, reconcile its totals, identify investigation candidates, and separate those candidates from approved operational changes.

## Establish the contract before calculating savings

The required CSV columns are:

```text
resource_id,service_name,region,avg_cpu_pct,hours_billed,on_demand_cost,reserved_rate
```

The primary key is `resource_id`. Each file represents one declared reporting window, and each resource appears exactly once.

That constraint makes this an audit-ready resource summary, not a universal raw billing format. Native billing exports often contain several rows per resource: usage types, discounts, credits, and daily charges. Transform those exports into the required grain before running the auditor.

Record the following alongside the CSV:

- Reporting start and end timestamps, with timezone.
- Export creation time and source.
- Account or subscription scope.
- Currency and tax treatment.
- Treatment of credits, refunds, and negotiated discounts.
- Meaning and unit of every monetary field.
- Transformation version and source-file checksum.

For this handbook, `on_demand_cost` means the undiscounted reference cost for the row’s billed usage, expressed in one currency. It is not necessarily the invoice amount.

`reserved_rate` means a comparable effective commitment price per resource-hour, including amortized upfront charges where applicable. It must cover the same configuration and charge components as the reference cost. A discount percentage or monthly reservation price does not satisfy this definition.

## Separate observation from permission

Use four stages:

1. **Validate:** Reject malformed or ambiguous inputs.
2. **Reconcile:** Confirm row counts, scope, and monetary totals.
3. **Classify:** Produce candidates with evidence and limitations.
4. **Approve:** Obtain workload-owner and financial authorization.

A low-CPU resource is a candidate for investigation. It is not automatically a zombie. A billing row for storage does not prove that a volume is unattached. A discounted rate does not prove that a commitment will be consumed.

The required columns support screening. Inventory, performance telemetry, ownership records, and contractual details support decisions.

Keep three savings figures separate: theoretical opportunity, validated opportunity, and approved forecast. Combining them creates a headline that cannot survive review.

# Chapter 2: Core Validation & Reconciliation Rules for resource_id

## Enforce identity without guessing

Treat `resource_id` as an opaque string. Preserve leading zeros, case, separators, and internal punctuation. Reject empty identifiers and surrounding whitespace rather than silently rewriting them.

Require exact uniqueness within the file. Never retain the first duplicate and discard the rest: this can erase spend while leaving a plausible report.

A duplicate may indicate:

- An export assembled twice.
- Multiple billing periods concatenated together.
- Several legitimate charge components for one resource.
- Identifiers that are only unique inside an account.
- A resource that changed configuration during the window.

Resolve the cause upstream. If identifiers are not globally unique, define a documented namespaced identifier before export. Do not invent a new namespace during the audit.

Where a resource changed tier or commitment eligibility, a single summary row may no longer support a meaningful rate comparison. Mark that resource ineligible for commitment analysis until the transformation can represent it correctly.

## Validate structure and values

Require the seven named columns and reject duplicate header names. Explicitly decide whether extra columns are permitted. A strict production interface can reject them to expose upstream schema changes.

Apply these rules:

- `service_name` and `region` must be nonempty.
- `avg_cpu_pct` must be finite and between 0 and 100 when applicable.
- `hours_billed`, `on_demand_cost`, and `reserved_rate` must be finite and nonnegative.
- Monetary values must use a period as the decimal separator.
- Scientific notation, currency symbols, and thousands separators should be rejected unless explicitly supported.
- Missing values must remain distinct from zero.

For storage and other services without CPU measurements, allow a blank `avg_cpu_pct` under a documented service policy. Never convert it to zero: that would make missing telemetry look like confirmed inactivity.

A missing commitment rate is also different from a zero rate. In a strict extract, provide a populated rate only for comparable products and maintain an eligibility mapping. If unavailable rates are allowed to be blank, suppress commitment calculations for those rows.

## Reconcile at two levels

First, reconcile the audit-ready CSV to the transformation output. Row count, resource count, total hours, and reference cost should match exactly at the retained source precision.

Second, reconcile the transformation to the billing source through a documented bridge:

```text
Reference usage cost
− applicable discounts
− credits
+ excluded fees
+ taxes, where applicable
= invoice comparison amount
```

The actual bridge depends on the source’s accounting definitions. Do not force reference cost to equal an invoice that includes different charges.

Reconcile by service and region as well as globally. Equal and opposite omissions can cancel in the grand total.

## Use dimensions, not convenient arithmetic

For a comparable row with positive billed hours:

```text
observed_on_demand_hourly_rate = on_demand_cost / hours_billed

historical_full_coverage_difference =
    on_demand_cost − hours_billed × reserved_rate
```

The second expression is a historical price comparison. It excludes unused committed hours and does not establish future savings.

Flag positive cost with zero hours for investigation. It may represent storage, licensing, requests, or another legitimate non-hourly charge. Such rows must not enter hourly commitment calculations.

# Chapter 3: Real-World Edge Cases, Rounding Traps & Incident Postmortems

## Screen candidates with explicit evidence requirements

Thresholds should initiate review, not trigger deletion.

| Candidate | Billing signal | Evidence required before action |
|---|---|---|
| Zombie instance | Sustained billed hours with very low average CPU | Owner, traffic, job schedule, memory, dependencies, recovery role |
| Unattached volume | Storage spend without an obvious active workload | Inventory attachment state, last attachment, retention policy |
| Oversized compute | Low average CPU and substantial reference cost | Peak CPU, memory, I/O, latency, throttling, load tests |
| Commitment opportunity | Repeatable eligible usage with a favorable comparable rate | Hourly demand history, contract scope, future workload plan |

Use configurable thresholds. For example, average CPU below 2% over a complete observation window might prioritize investigation. It does not establish inactivity.

A server running a short daily batch can have low average CPU while remaining essential. A memory-bound cache can show low CPU while being correctly sized. A disaster-recovery node can be deliberately idle.

## Hours are not interchangeable

A calendar month has a different number of hours depending on its length. Reporting windows can also be partial. Always derive the duration from explicit timestamps, preferably in UTC.

`hours_billed` may represent elapsed resource-hours, aggregate instance-hours, or a provider-specific usage unit. Commitment arithmetic requires resource-hours comparable to `reserved_rate`.

An average CPU value also needs a defined denominator. A mean calculated only while an instance was running differs from one calculated across the full reporting window. Missing samples should not silently enter either calculation as zero.

## Preserve precision until presentation

Use decimal arithmetic for monetary values. Sum retained source amounts before rounding for display.

| Situation | Unsafe treatment | Correct treatment |
|---|---|---|
| Three rows each costing 0.004 | Round each to 0.00, then sum | Sum to 0.012, then apply reporting precision |
| Rate contains six decimal places | Truncate rate to cents | Preserve rate precision through multiplication |
| Credit represented as a negative charge | Take absolute value | Handle through the reconciliation bridge |
| CPU field is blank | Substitute 0% | Preserve unknown or inapplicable status |
| Commitment price is monthly | Multiply directly by billed hours | Convert under documented contract assumptions |

Specify the rounding mode. For example, a report might use decimal half-up rounding to two places for a currency presented in hundredths. Keep machine-readable intermediate values unrounded.

Use a reconciliation tolerance only when justified by source rounding. A tolerance is not a budget for unexplained discrepancies.

## Illustrative incident: the “idle” settlement worker

An operations team identified an instance averaging 0.6% CPU and proposed termination. The owner review found that it executed a short, business-critical overnight settlement job.

The failure was using an aggregate utilization statistic as proof of abandonment.

The corrective control required job-scheduler checks, owner acknowledgment, and a reversible stop-and-observe period where operationally appropriate. The candidate remained valid; the proposed action changed.

## Illustrative incident: unattached storage with a retention obligation

A storage cleanup report treated every volume without a matching compute row as unattached. Several volumes belonged to an account omitted from the compute export. Others were retained after decommissioning under an approved policy.

The failure was confusing an incomplete join with an inventory state.

The corrective control required authoritative attachment metadata, account coverage checks, and a documented retention disposition.

## Illustrative incident: a discounted commitment that increased spend

Assume a fixed resource-hour commitment costs 0.06 per hour and comparable on-demand usage costs 0.10. The workload runs for 200 hours during a 720-hour period.

On demand, the workload costs 20.00. Buying one unit of capacity for the entire period costs 43.20, despite the attractive hourly discount.

The break-even utilization is:

```text
reserved_rate / on_demand_rate = 0.06 / 0.10 = 60%
```

This simplified result assumes a fixed capacity commitment, equivalent coverage, and no other costs. It illustrates why historical billed hours cannot establish commitment value.

Spend-based savings plans require their own eligible-spend and benefit-allocation model.

# Chapter 4: Offline Browser Workbench Architecture & Zero-Upload Security

An offline browser workbench should make the audit inspectable without transmitting billing data. Its security claim must follow from implementation and testing.

## Keep the processing boundary local

Use a static application with bundled assets. The user selects a CSV through a file input or drag-and-drop control. Parsing, validation, classification, and report creation happen in the browser.

The application should include:

- A streaming CSV parser for large exports.
- A worker thread for parsing and expensive calculations.
- A fixed-point or decimal arithmetic implementation.
- A versioned validation ruleset.
- A findings view with filters and evidence links.
- Local download of audit results and an execution manifest.

Never parse CSV by splitting on commas. Quoted delimiters, embedded newlines, and escaped quotes are valid CSV features.

Keep file contents in memory by default. Do not persist billing rows in local storage, IndexedDB, or caches without an explicit retention feature and visible controls.

## Make zero-upload verifiable

Bundle scripts, styles, fonts, and help content. Exclude analytics, remote error reporting, external fonts, telemetry, and runtime dependencies fetched from content delivery networks.

Apply a restrictive Content Security Policy. Set `connect-src 'none'` and constrain scripts, workers, images, forms, frames, and other resource types to the minimum required.

`connect-src` alone does not prevent every route for data transmission. Resource loading, navigation, form submission, and application code also need review.

Test the built application with network monitoring:

1. Load the application.
2. Import representative and malformed files.
3. Run every audit view.
4. Export reports.
5. Confirm that no billing content leaves the browser.
6. Repeat with network access disabled.

State the boundary accurately. Browser extensions, endpoint compromise, operating-system swap, and user-directed exports are outside the application’s zero-upload guarantee.

## Treat imported content as hostile

Resource names and service fields can contain markup or spreadsheet formulas. Render imported strings as text, never executable HTML.

CSV exports opened in spreadsheet software need formula-injection protection for values beginning with characters such as `=`, `+`, `-`, or `@`. Preserve original identifiers in a structured JSON report and document any spreadsheet-safe transformation.

Enforce file-size and row-count limits. Reject excessive field lengths. Support cancellation and release references to imported data when the session is cleared.

## Make results reproducible

Export a manifest containing the source checksum, ruleset version, reporting window, currency, thresholds, record counts, reconciliation status, and findings.

Show excluded rows and suppressed calculations. A clean-looking dashboard must never conceal the fact that half the input lacked usable telemetry.

# Chapter 5: Automating Audits with Zero-Dependency Python 3 CLI & CI/CD Exit Codes

A Python CLI provides repeatable validation in scheduled jobs and delivery pipelines. The standard library supplies CSV parsing, decimal arithmetic, hashing, argument handling, and JSON output.

The following example implements a strict compute-summary contract: all numerical fields must be populated, and all rates must already be comparable. Storage exports with inapplicable CPU values require a service-aware extension. It deliberately performs validation only; it does not authorize optimization.

```python
#!/usr/bin/env python3
import argparse
import csv
import hashlib
import io
import json
import re
import sys
from decimal import Decimal

FIELDS = [
    "resource_id", "service_name", "region", "avg_cpu_pct",
    "hours_billed", "on_demand_cost", "reserved_rate",
]
NUMBER = re.compile(r"[0-9]+(?:\.[0-9]+)?\Z")


def decimal_value(value, field, record):
    if not isinstance(value, str) or not NUMBER.fuテキスト処理系atch(value):
        raise ValueError(f"record {record}: invalid {field}")
    return Decimal(value)


def validate(raw, expected_total):
    reader = csv.DictReader(
        io.StringIO(raw.decode("utf-8-sig"), newline=""),
        strict=True,
    )
    headers = reader.fieldnames
    if (
        headers is None
        or len(headers) != len(FIELDS)
        or len(set(headers)) != len(headers)
        or set(headers) != set(FIELDS)
    ):
        raise ValueError("header must contain each required column once")

    seen = set()
    total = Decimal("0")
    count = 0

    for record, row in enumerate(reader, start=1):
        if None in row or any(value is None for value in row.values()):
            raise ValueError(f"record {record}: incorrect column count")

        for field in ("resource_id", "service_name", "region"):
            value = row[field]
            if not value or value != value.strip():
                raise ValueError(f"record {record}: invalid {field}")

        resource_id = row["resource_id"]
        if resource_id in seen:
            raise ValueError(f"record {record}: duplicate resource_id")
        seen.add(resource_id)

        numbers = {
            field: decimal_value(row[field], field, record)
            for field in FIELDS[3:]
        }
        if numbers["avg_cpu_pct"] > 100:
            raise ValueError(f"record {record}: CPU exceeds 100")

        total += numbers["on_demand_cost"]
        count += 1

    if count == 0:
        raise ValueError("empty dataset")
    if total != expected_total:
        raise ValueError("reference-cost reconciliation failed")

    return {
        "status": "validated",
        "records": count,
        "reference_cost": str(total),
        "sha256": hashlib.sha256(raw).hexdigest(),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("csv_path")
    parser.add_argument("--expected-reference-total", required=True)
    args = parser.parse_args()

    try:
        expected = decimal_value(
            args.expected_reference_total, "expected total", 0
        )
        with open(args.csv_path, "rb") as source:
            raw = source.read()
        report = validate(raw, expected)
    except (ValueError, UnicodeError, csv.Error) as exc:
        print(str(exc), file=sys.stderr)
        return 2
    except OSError as exc:
        print(str(exc), file=sys.stderr)
        return 3

    print(json.dumps(report, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
```

Example invocation:

```bash
python3 audit.py billing.csv \
  --expected-reference-total 18432.781245 > audit.json
```

Obtain the expected total from an independently controlled transformation manifest. Recalculating it from the same CSV immediately before validation defeats the completeness check.

For large files, replace whole-file loading with bounded streaming and incremental hashing. Apply input-size limits before processing untrusted exports.

## Define exit codes as an interface

Use a stable convention:

- `0`: Input valid; configured policy gates passed.
- `1`: Input valid; a configured findings gate failed.
- `2`: Invalid input, invalid invocation, or failed reconciliation.
- `3`: Operational failure, such as an unreadable file.

The example implements codes `0`, `2`, and `3`. A later policy layer can return `1` for agreed thresholds, such as unowned high-cost candidates.

Do not fail deployment simply because an opportunity exists. An audit job and an application release have different responsibilities. Publish findings as a restricted artifact and gate releases only where the organization has defined that relationship.

Add focused fixtures for duplicate identifiers, quoted commas, missing values, fractional rates, malformed rows, and reconciliation mismatches. Run the same fixtures against the browser implementation to prevent rule drift.

# Chapter 6: Standard Operating Checklist & Executive Sign-Off Template

## Run the operational checklist in order

Before analysis:

- Confirm reporting window, currency, account coverage, and source freshness.
- Verify the checksum and transformation version.
- Validate schema, primary keys, numerical units, and missing-value policy.
- Reconcile totals and document every exclusion.

Before changing resources:

- Identify the accountable workload owner.
- Check traffic, jobs, dependencies, memory, and peak performance.
- Confirm attachment and retention status for storage.
- Select a reversible action where practical.
- Define rollback triggers and an observation period.
- Record approval and the planned execution window.

Before purchasing commitments:

- Remove expected zombie and rightsizing reductions from the baseline.
- Use hourly eligible demand across representative periods.
- Model expiration of existing commitments and benefit overlap.
- Account for migrations, seasonality, and planned shutdowns.
- Verify term, payment structure, scope, exclusions, and flexibility.
- Stress-test lower demand before approving the purchase.

## Size commitments after waste removal

Purchasing against today’s waste can make tomorrow’s cleanup financially ineffective.

For a simplified fixed-capacity commitment, evaluate candidate quantity \(q\) against each hourly demand observation \(D_t\):

```text
cost(q) =
    q × reserved_rate × number_of_hours
    + sum(max(D_t − q, 0) × on_demand_rate)

savings(q) =
    sum(D_t × on_demand_rate) − cost(q)
```

This assumes homogeneous eligible units and constant comparable rates. Evaluate a range of quantities under base, reduced-demand, and migration scenarios.

For spend-based commitments, model eligible hourly spend using the applicable discounted rates and allocation rules. Do not substitute instance counts into a monetary commitment model.

Rank proposals by net savings, utilization risk, term exposure, and operational confidence. Include engineering effort and unavoidable residual charges in resource-removal proposals.

After implementation, measure realized savings against a normalized baseline that accounts for demand changes. A lower invoice alone does not prove that the optimization caused the reduction.

## Executive sign-off template

**Decision:**  
Approve resource removal, rightsizing, or commitment purchase.

**Scope:**  
Accounts, services, regions, resource identifiers, and reporting window.

**Evidence:**  
Source checksum, ruleset version, reconciliation result, telemetry period, and inventory verification date.

**Financial baseline:**  
Current reference cost, actual billed cost, existing discounts, currency, and excluded charges.

**Proposed action:**  
Exact resources or commitment amount, start date, term, payment schedule, and responsible operator.

**Expected economics:**  
Validated savings, implementation cost, net benefit, break-even assumptions, and downside scenario.

**Operational impact:**  
Affected workloads, maintenance window, performance acceptance criteria, and recovery dependencies.

**Risk controls:**  
Rollback procedure for resource changes; demand cushion and contractual limitations for commitments.

**Approvals:**  
Workload owner, platform owner, finance owner, and procurement authority where required.

**Verification:**  
Review date, measurement method, realized-savings owner, and escalation threshold.

An approval is complete when the proposed action, supporting evidence, financial exposure, and accountable owners are explicit. The audit report supports that decision; it does not replace it.
