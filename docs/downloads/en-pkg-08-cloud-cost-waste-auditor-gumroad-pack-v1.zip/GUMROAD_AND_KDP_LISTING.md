# Cloud Billing CSV Idle Resource & Commitment Sizing Auditor

**FinOps Browser Workbench, Python CLI & Cloud Cost Optimization Guide**

- **Suggested Price**: USD 21
- **Focus**: Identifying zombie instances, unattached volumes, oversized compute tiers, and high-ROI savings plan commitments from billing exports.
- **Included**:
  1. `en-pkg-08-cloud-cost-waste-auditor_workbench.html` — 100% Offline Browser Workbench (zero external requests)
  2. `en_pkg_08_cloud_cost_waste_auditor_cli.py` — Zero-Dependency Python 3 CLI Auditor
  3. `en-pkg-08-cloud-cost-waste-auditor-kdp-en-v1.epub` — Full Practical Engineering Handbook (EPUB3)
  4. `samples/` & `test_en_package.py` — Sample datasets and automated verification suite
