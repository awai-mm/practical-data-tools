# Chapter 1: Why Spreadsheets Fail in Production & The Pre-Flight Audit Pattern

Project pricing fails when estimates, contracts, time records, and invoices describe different versions of the same engagement.

A spreadsheet may calculate every formula correctly while still approving an unprofitable project. A milestone might exclude deployment support. A blended rate might omit employer costs. A discount might be applied after the margin review. A client might interpret “integration complete” as including data migration, training, and ongoing troubleshooting.

The problem is not arithmetic alone. It is the absence of an enforced commercial boundary.

## Establish one pricing contract

Use a canonical CSV with exactly these columns:

```csv
deliverable_id,phase,estimated_hours,blended_cost_rate,risk_buffer_pct,client_price,target_margin_pct
D-001,Discovery,24,85,15,3600,30
D-002,Implementation,100,90,20,16000,30
D-003,Acceptance,20,85,10,3000,30
```

Each row represents a deliverable that can be estimated, accepted, and commercially controlled. `deliverable_id` is its primary key.

The CSV is a pricing ledger, not a complete statement of work. Maintain a companion scope register keyed by the same identifier. It should specify:

- Included work and explicit exclusions.
- Acceptance evidence and acceptance owner.
- Client dependencies and response deadlines.
- Revision limits and support obligations.
- Change-control triggers and payment terms.

A deliverable without acceptance criteria is an open-ended obligation with a price attached.

## Define the economics before calculating them

For each deliverable, calculate:

```text
base_cost = estimated_hours × blended_cost_rate
buffered_cost = base_cost × (1 + risk_buffer_pct / 100)
profit = client_price − buffered_cost
margin_pct = 100 × profit / client_price
minimum_price = buffered_cost / (1 − target_margin_pct / 100)
```

These definitions treat the risk buffer as a cost allowance. It is neither a price markup nor automatically earned profit.

Margin and markup are different. A cost of 10,000 priced at 12,500 produces a 25% markup but a 20% margin. A 30% margin requires a price of approximately 14,285.72.

Define `blended_cost_rate` consistently across the engagement. It may represent direct delivery cost or a fully loaded internal rate, but the report must state which. A project margin calculated from direct labor alone is not company operating margin.

## Run the pre-flight audit at commercial boundaries

Audit before issuing a proposal, approving a milestone, accepting a change request, and releasing an invoice.

The audit should answer four questions:

1. Is the file structurally valid?
2. Are identifiers, values, and scope references internally consistent?
3. Does every deliverable meet its commercial threshold?
4. Does the approved version reconcile to the contract and billing schedule?

Record the input file hash, policy version, findings, and approver. Approval applies to those exact bytes. Editing the estimate afterward creates a new approval candidate.

Run scenario analysis before commitment. Increase estimated hours by 10%, 20%, and 30%; delay acceptance; add a support cycle. Identify which assumptions cause margin failure first.

The objective is not a reassuring average. It is a visible boundary between work the agency can deliver profitably and obligations requiring a different price, scope, or delivery method.

# Chapter 2: Core Validation & Reconciliation Rules for deliverable_id

The primary key connects commercial intent to operational evidence. Treat it as durable infrastructure.

## Validate identifiers without silently repairing them

Require `deliverable_id` to be nonempty, unique, and stable. A practical convention is uppercase letters, digits, and hyphens, beginning with a letter or digit.

Reject surrounding whitespace. Do not silently convert `D-007 ` into `D-007`; correction belongs in the source record. Silent normalization can conceal duplicate imports or join errors.

Never recycle an identifier. If a deliverable is withdrawn, retain its history in the scope register. A materially different replacement receives a new identifier, with an explicit predecessor reference.

Identifiers must remain text. Spreadsheet imports can destroy leading zeros or reinterpret values as dates. Prefer identifiers such as `D-0007` over bare numeric sequences.

## Enforce a typed schema

Apply these rules before calculating economics:

| Column | Required validation | Commercial meaning |
|---|---|---|
| `deliverable_id` | Unique, nonempty, approved syntax | Stable scope identity |
| `phase` | Nonempty; matches engagement vocabulary | Reporting group |
| `estimated_hours` | Finite decimal greater than zero | Expected delivery effort |
| `blended_cost_rate` | Finite decimal greater than zero | Internal cost per hour |
| `risk_buffer_pct` | Finite decimal from 0 through 100 | Cost contingency allowance |
| `client_price` | Finite decimal greater than zero | Net deliverable revenue |
| `target_margin_pct` | Finite decimal from 0 up to, but excluding, 100 | Required pricing margin |

The 100% risk-buffer ceiling is a chosen policy limit. If uncertainty requires more, decompose the work or use paid discovery rather than bypassing validation.

Zero-price work requires an explicit commercial exception or a separate adjustment register. Do not insert artificial revenue merely to satisfy validation.

Reject `NaN`, infinity, currency symbols, thousands separators, and percentage signs. Store `12.5`, not `12.5%`. Use a decimal point regardless of workstation locale.

## Reconcile beyond the file

Uniqueness within the CSV is necessary but insufficient. Compare its identifier set with the approved scope register:

- An approved scope item missing from pricing is a potential unbilled obligation.
- A priced item missing from scope lacks an enforceable acceptance boundary.
- A time entry with an unknown identifier cannot be reliably attributed.
- An invoice allocation without an approved identifier needs investigation.

If a deliverable spans several invoices, use an allocation ledger. Do not duplicate its pricing row. Reconcile allocated invoice amounts to approved deliverable revenue, accounting separately for credits, holdbacks, and unbilled balances.

Require one currency per pricing file. Since the required schema has no currency column, declare currency and minor-unit precision in a companion manifest. Also declare whether prices exclude tax, how expenses are treated, and which rate policy applies.

## Aggregate with revenue weighting

Project margin is:

```text
100 × (sum(client_price) − sum(buffered_cost)) / sum(client_price)
```

Do not average row margins. A small high-margin task can otherwise disguise a large loss-making milestone.

Apply row-level targets and a separate engagement-level target. A profitable total does not justify an underpriced milestone unless an authorized commercial decision explicitly permits cross-subsidy.

Finally, reconcile the approved total to the signed contract. Deposits and payment timing affect cash flow; they do not create additional project revenue. Keep profitability, invoicing, and cash collection distinct.

# Chapter 3: Real-World Edge Cases, Rounding Traps & Incident Postmortems

Pricing systems need explicit treatment of inconvenient cases. Unwritten assumptions become exceptions precisely when delivery pressure is highest.

## Make rounding a commercial policy

Use decimal arithmetic for monetary calculations. Preserve precision through cost and margin calculations, then round displayed amounts.

For a currency with two decimal places, round a minimum acceptable quote upward to the next cent. Ordinary rounding can produce a price slightly below the target.

| Case | Incorrect treatment | Correct treatment |
|---|---|---|
| Cost 100; target margin 30% | Quote 142.85 | Quote at least 142.86 |
| Price 1,000; buffered cost 700.004 | Display 30.00% and approve | Compare unrounded values; target is missed |
| Three costs of 0.335 | Assume every rounding order gives 1.01 | Per-row rounding gives 1.02; aggregate rounding gives 1.01 |
| Discount applied after approval | Retain the original margin result | Recalculate using discounted revenue |
| Credit issued against a milestone | Record it only in billing | Update the revenue forecast and reconcile the credit |

Document whether booked costs round per transaction or at aggregation. The estimator may retain precision internally, but reconciliation must follow the actual ledger convention.

Avoid arbitrary tolerances such as “within one percentage point is close enough.” If the organization allows a tolerance, define its monetary impact, owner, and approval rule.

## Incident: unlimited acceptance revisions

An agency priced 80 hours at a cost rate of 75, added a 15% risk buffer, and charged 10,000.

Buffered cost was 6,900, implying a 31% planning margin. The acceptance clause allowed revisions without a limit. Actual delivery reached 110 hours, costing 8,250 and reducing realized margin to 17.5%.

The arithmetic was correct. The contract boundary was defective.

**Corrective action:** define acceptance tests, included revision rounds, feedback deadlines, and chargeable changes. Re-estimate at the first failed assumption, not after the entire buffer has been consumed.

## Incident: hidden utilization subsidy

A team calculated its rate by dividing annual employment cost by every paid hour. It then assumed those hours were available for client delivery.

Illustrative economics:

| Item | Amount |
|---|---:|
| Annual employment cost | 120,000 |
| Paid hours | 2,000 |
| Nominal hourly cost | 60.00 |
| Planned delivery hours at 65% utilization | 1,300 |
| Employment cost per delivery hour | 92.31 |

At 500 delivery hours, the nominal method allocates 30,000 of employment cost. The utilization-adjusted method allocates approximately 46,153.85 before any additional overhead.

**Corrective action:** calculate available delivery capacity after leave, internal work, sales support, and realistic utilization. Distinguish delivery utilization from invoice collection and realized hourly revenue. Do not include the same overhead twice in both the rate and another allocation.

## Incident: contingency counted twice

A manager inflated estimated hours by 20%, then applied a 20% risk buffer described as covering the same uncertainty.

The resulting cost multiplier was 1.44, not 1.20. The proposal became less competitive without improving the risk model.

**Corrective action:** separate known work from uncertainty. Estimated hours should include expected coordination, testing, and deployment effort. The buffer should cover documented uncertainty, with an owner and release trigger.

## Handle special commercial structures deliberately

Retainers, capped time-and-materials work, and fixed bids require different controls. For a retainer, define included capacity and overage treatment. For a cap, monitor remaining authorized spend. For a fixed bid, monitor forecast cost to complete.

Keep credits and pass-through purchases in companion ledgers if they cannot satisfy the core row rules. Allocate project discounts explicitly across deliverables before auditing. Never hide a discount in a negative-hour row or conceal subcontractor spending inside a risk percentage.

# Chapter 4: Offline Browser Workbench Architecture & Zero-Upload Security

An offline workbench should make pricing decisions inspectable without sending commercial data to another system.

## Build a small, explicit processing pipeline

Use this sequence:

```text
Local file selection
→ CSV parser
→ schema validation
→ identifier and reconciliation checks
→ decimal calculations
→ interactive pricing matrix
→ local report export
```

The browser reads files selected by the user. Parsing and calculation remain within the local process. A worker can keep large imports responsive, but it must use the same validation contract as the command-line auditor.

Do not parse CSV by splitting lines and commas. Quoted fields, embedded line breaks, and escaped quotes require a proper parser.

Bundle scripts, styles, fonts, and other assets locally. Eliminate external analytics, remote fonts, telemetry, and runtime package downloads. Use a restrictive content security policy, including a network connection prohibition where the deployment supports it.

“Zero upload” describes an observable property of the application, not a guarantee against a compromised operating system, browser extension, or cloud-synchronized download folder.

## Make the matrix useful for decisions

Show each deliverable with estimated hours, buffered cost, client price, margin, required price, and target shortfall.

Support:

- Sorting by absolute profit exposure and margin shortfall.
- Filtering by phase and validation status.
- Adjusting hours, price, or risk in a clearly marked scenario.
- Comparing a scenario with the approved baseline.
- Exporting the revised CSV and its audit report together.

Preserve `deliverable_id` during scenario edits. Never make a scenario appear approved merely because its calculations pass.

Display both portfolio margin and individual failures. Include a stress control for additional effort, with clear semantics: applying another 20% to already buffered cost is different from replacing the buffer with 20%.

## Keep calculations consistent

Browser floating-point arithmetic can disagree with decimal calculations at thresholds. Use a bundled decimal implementation or scaled integers with explicit precision and rounding rules.

Maintain shared test fixtures covering duplicate identifiers, malformed CSV, boundary margins, fractional cents, and nonfinite numbers. Both implementations should produce the same findings and approval decisions.

Do not rely on displayed percentages for decisions. Show enough detail to explain a failure that visually rounds to the target.

## Control persistence and exports

Default to memory-only processing. If local persistence is offered, require a clear opt-in and provide deletion controls. Avoid placing source data in URLs, application logs, or crash reports.

Render imported text as text, never executable markup. For spreadsheet-facing exports, address formula interpretation in text fields beginning with characters such as `=`, `+`, `-`, or `@`. Keep a spreadsheet-safe presentation export separate from the canonical machine-readable CSV so sanitization does not silently change identifiers.

Verify the zero-upload claim with network inspection while importing, editing, and exporting. Repeat the check after dependency or packaging changes. Provide the application version, policy version, and input hash in every report so a commercial decision can be reproduced.

# Chapter 5: Automating Audits with Zero-Dependency Python 3 CLI & CI/CD Exit Codes

The command-line auditor is the repeatable gate between an estimate and an approved commercial artifact. It should run without third-party packages and return machine-readable results.

Use a stable exit-code contract:

| Exit code | Meaning | Pipeline action |
|---|---|---|
| `0` | Valid file; all row targets met | Continue to reconciliation and approval |
| `1` | Valid file; one or more targets missed | Block commercial release |
| `2` | Invalid input or unreadable file | Correct the source and rerun |
| `3` | Unexpected internal failure | Investigate; never treat as a pass |

A passing pricing check does not prove scope completeness. Contract reconciliation and authorization remain separate gates.

## Implement the core validator

The following implementation assumes a two-decimal currency, plain decimal inputs, exact column order, and six fractional digits at most. Its numeric limits also bound arithmetic precision.

```python
#!/usr/bin/env python3
import csv
import hashlib
import io
import json
import re
import sys
from decimal import Decimal, ROUND_CEILING, localcontext
from pathlib import Path

FIELDS = [
    "deliverable_id", "phase", "estimated_hours",
    "blended_cost_rate", "risk_buffer_pct",
    "client_price", "target_margin_pct",
]
IDENTIFIER = re.compile(r"[A-Z0-9][A-Z0-9-]{0,63}")
NUMBER = re.compile(r"[0-9]{1,12}(?:\.[0-9]{1,6})?")
CENT = Decimal("0.01")
HUNDRED = Decimal(100)


def number(raw, field):
    if not isinstance(raw, str) or not NUMBER.fuテキスト処理系atch(raw):
        raise ValueError(f"{field}: expected a plain decimal")
    return Decimal(raw)


def audit(path):
    data = Path(path).read_bytes()
    source = io.StringIO(data.decode("utf-8-sig"), newline="")
    reader = csv.DictReader(source, strict=True)

    if reader.fieldnames != FIELDS:
        raise ValueError("header must match the required columns")

    seen, results = set(), []
    total_cost = Decimal(0)
    total_price = Decimal(0)

    with localcontext() as ctx:
        ctx.prec = 80

        for row in reader:
            line = reader.line_num
            if None in row or any(v is None for v in row.values()):
                raise ValueError(f"line {line}: wrong field count")

            key = row["deliverable_id"]
            if not IDENTIFIER.fuテキスト処理系atch(key):
                raise ValueError(f"line {line}: invalid deliverable_id")
            if key in seen:
                raise ValueError(f"line {line}: duplicate {key}")
            seen.add(key)

            phase = row["phase"]
            if not phase or phase != phase.strip():
                raise ValueError(f"{key}: invalid phase")

            values = {
                name: number(row[name], name)
                for name in FIELDS[2:]
            }
            hours = values["estimated_hours"]
            rate = values["blended_cost_rate"]
            risk = values["risk_buffer_pct"]
            price = values["client_price"]
            target = values["target_margin_pct"]

            if min(hours, rate, price) <= 0:
                raise ValueError(f"{key}: hours, rate, price must be positive")
            if not Decimal(0) <= risk <= HUNDRED:
                raise ValueError(f"{key}: risk outside 0..100")
            if not Decimal(0) <= target < HUNDRED:
                raise ValueError(f"{key}: target outside 0..<100")
            if price != price.quantize(CENT):
                raise ValueError(f"{key}: price exceeds currency precision")

            cost = hours * rate * (1 + risk / HUNDRED)
            profit = price - cost

            # Compare directly; do not decide using a rounded margin.
            passed = profit * HUNDRED >= price * target
            margin = profit * HUNDRED / price
            minimum = (cost / (1 - target / HUNDRED)).quantize(
                CENT, rounding=ROUND_CEILING
            )

            total_cost += cost
            total_price += price
            results.append({
                "deliverable_id": key,
                "buffered_cost": str(cost),
                "margin_pct": str(margin),
                "minimum_price": str(minimum),
                "passed": passed,
            })

        if not results:
            raise ValueError("no deliverables")

        report = {
            "policy": "pricing-v1-two-decimal-currency",
            "input_sha256": hashlib.sha256(data).hexdigest(),
            "total_price": str(total_price),
            "total_buffered_cost": str(total_cost),
            "project_margin_pct": str(
                (total_price - total_cost) * HUNDRED / total_price
            ),
            "deliverables": results,
        }
        status = 0 if all(r["passed"] for r in results) else 1
        return report, status


def main():
    if len(sys.argv) != 2:
        print("usage: audit.py pricing.csv", file=sys.stderr)
        return 2

    try:
        report, status = audit(sys.argv[1])
    except (OSError, UnicodeError, csv.Error, ValueError) as exc:
        print(json.dumps({"error": str(exc)}))
        return 2
    except Exception as exc:
        print(json.dumps({
            "error": "internal auditor failure",
            "type": type(exc).__name__,
        }))
        return 3

    print(json.dumps(report, indent=2))
    return status


if __name__ == "__main__":
    sys.exit(main())
```

This is a core pricing gate. Add phase vocabulary checks, manifest validation, scope-register reconciliation, and an engagement-level target before treating it as the complete release process.

## Connect the gate to delivery

A minimal pipeline invocation is:

```sh
python3 audit.py pricing.csv > audit.json
```

Let the nonzero exit code fail the job. Publish the report even when the job fails, using the pipeline platform’s unconditional artifact step. Restrict artifact access because reports expose internal costs and margins.

Test economically meaningful boundaries: a price exactly meeting target, one cent below the required quote, duplicate identifiers, and a profitable portfolio containing an underpriced milestone.

Protect the auditor and policy alongside the estimate. A proposal change should not be able to weaken its own gate without review. Record approved exceptions separately, tied to the input hash, affected identifiers, rationale, owner, and expiry.

# Chapter 6: Standard Operating Checklist & Executive Sign-Off Template

A reliable estimator becomes valuable when its controls survive proposal pressure and delivery urgency.

## Before quoting

- Assign a stable identifier to every deliverable.
- Define acceptance criteria, exclusions, and revision limits.
- Include coordination, testing, deployment, and expected support effort.
- Verify rates against realistic delivery capacity.
- Declare currency, tax treatment, and rate methodology.
- Allocate discounts before calculating margins.
- Run validation, scenario analysis, and scope reconciliation.
- Review payment timing against expected cash outflows.

Name one commercial owner and one delivery owner. The commercial owner approves price and exceptions; the delivery owner confirms that the estimate covers the accepted obligation.

## During delivery

Review forecast cost to complete weekly and at every milestone boundary.

```text
forecast_final_cost = actual_cost_to_date + estimated_remaining_cost
forecast_margin = (approved_revenue − forecast_final_cost)
                  / approved_revenue
```

Use the same cost basis for actual and remaining costs. Do not add the original buffer again if the remaining forecast already includes contingency.

Track out-of-scope requests against deliverable identifiers. Record their expected effort and revenue status before work begins. A friendly verbal agreement is not a revised commercial baseline.

Escalate when forecast margin falls below the approved threshold, when a material dependency slips, or when acceptance criteria change. Pause the affected discretionary work where contract terms permit; continue unaffected obligations.

Monitor utilization separately from project margin. A profitable engagement can coexist with an unprofitable agency if too much capacity remains unassigned or absorbed by unpriced support.

## At milestone close

Reconcile acceptance evidence, actual effort, approved changes, invoice allocations, and remaining obligations.

Explain estimate variance by cause: missing scope, execution inefficiency, dependency delay, rework, or rate mismatch. Update future estimating assumptions from repeated causes, not from isolated anecdotes.

Release contingency only after the associated risk has expired. Do not classify unused planning allowance as realized profit while support or acceptance obligations remain open.

## Executive sign-off template

```text
Engagement:
Client:
Commercial owner:
Delivery owner:
Approval date:

Baseline
- Pricing file and SHA-256:
- Scope register version:
- Auditor and policy version:
- Currency and monetary precision:
- Cost-rate methodology:

Economics
- Approved net revenue:
- Buffered delivery cost:
- Planned project margin:
- Engagement target margin:
- Deliverables below individual targets:
- Stress scenario and resulting margin:

Commercial controls
- Acceptance owner and evidence:
- Included revision/support limits:
- Client dependencies:
- Change authorization process:
- Payment schedule and cash exposure:

Exceptions
- Affected deliverable identifiers:
- Monetary exposure:
- Business rationale:
- Mitigation owner:
- Expiry or review date:

Decision
[ ] Approved for the identified baseline
[ ] Returned for revision
[ ] Approved with the recorded exceptions

Commercial approval:
Delivery approval:
```

Approval should authorize a specific scope, price, and risk position. When any of those changes materially, rerun the audit and obtain a new decision before treating the change as part of the committed engagement.
