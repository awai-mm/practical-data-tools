#!/usr/bin/env python3
"""
Stochastic (s, S) Inventory, Yield Variance & Cash-Conversion-Cycle CVaR Optimization Solver.
Uses deterministic-seed Monte Carlo simulation + grid search over (reorder_point s, order_up_to S)
subject to Working Capital & Cash Shortfall CVaR constraints.
"""
from __future__ import annotations
import argparse, json, math, random, sys
from typing import Any


def simulate_sS_policy(
    s: int,
    S: int,
    horizon_days: int = 90,
    trials: int = 400,
    mean_demand: float = 25.0,
    demand_std: float = 9.0,
    lead_time_mean: float = 5.0,
    yield_mean: float = 0.96,
    unit_cost: float = 1200.0,
    unit_price: float = 2200.0,
    holding_cost_day: float = 8.0,
    working_capital_limit: float = 650000.0,
    seed: int = 42,
) -> dict[str, Any]:
    rng = random.Random(seed)
    profits: list[float] = []
    stockout_rates: list[float] = []
    peak_cash_drawdowns: list[float] = []

    for _ in range(trials):
        inv = S
        on_order: list[tuple[int, int]] = []
        cash_used = 0.0
        max_cash_used = 0.0
        total_revenue = 0.0
        total_cost = 0.0
        total_demanded = 0
        total_short = 0

        for day in range(horizon_days):
            arrived = sum(q for d_arr, q in on_order if d_arr == day)
            on_order = [(d_arr, q) for d_arr, q in on_order if d_arr > day]
            inv += arrived

            d = max(0, int(round(rng.gauss(mean_demand, demand_std))))
            total_demanded += d
            sold = min(inv, d)
            short = d - sold
            inv -= sold
            total_short += short

            rev = sold * unit_price
            hold = inv * holding_cost_day
            total_revenue += rev
            total_cost += hold
            cash_used = max(0.0, cash_used + hold - rev * 0.85)

            inv_position = inv + sum(q for _, q in on_order)
            if inv_position <= s:
                order_qty = max(0, S - inv_position)
                if order_qty > 0:
                    lt = max(1, int(round(rng.gauss(lead_time_mean, 1.2))))
                    eff_yield = min(1.0, max(0.75, rng.gauss(yield_mean, 0.03)))
                    realized_qty = int(round(order_qty * eff_yield))
                    on_order.append((day + lt, realized_qty))
                    order_cost = order_qty * unit_cost
                    total_cost += order_cost
                    cash_used += order_cost
                    if cash_used > max_cash_used:
                        max_cash_used = cash_used

        profits.append(total_revenue - total_cost)
        stockout_rates.append(total_short / max(1, total_demanded))
        peak_cash_drawdowns.append(max_cash_used)

    profits.sort()
    peak_cash_drawdowns.sort(reverse=True)
    tail_n = max(1, int(trials * 0.05))
    cvar95_profit = sum(profits[:tail_n]) / tail_n
    cvar95_cash_drawdown = sum(peak_cash_drawdowns[:tail_n]) / tail_n

    return {
        "s": s,
        "S": S,
        "expected_profit": round(sum(profits) / trials, 2),
        "cvar95_profit": round(cvar95_profit, 2),
        "avg_stockout_rate": round(sum(stockout_rates) / trials, 4),
        "cvar95_cash_drawdown": round(cvar95_cash_drawdown, 2),
        "within_working_capital": cvar95_cash_drawdown <= working_capital_limit,
    }


def optimize_sS_grid() -> dict[str, Any]:
    candidates = []
    for s in (80, 110, 140, 170):
        for delta in (120, 180, 240):
            res = simulate_sS_policy(s=s, S=s + delta)
            candidates.append(res)
    feasible = [c for c in candidates if c["within_working_capital"]] or candidates
    feasible.sort(key=lambda x: (x["expected_profit"] + 0.35 * x["cvar95_profit"]), reverse=True)
    return {"ok": True, "best_policy": feasible[0], "evaluated_count": len(candidates), "top_3": feasible[:3]}


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--self-test", action="store_true")
    args = p.parse_args()
    res = optimize_sS_grid()
    print(json.dumps(res, ensure_ascii=False, indent=2))
    return 0 if res["ok"] and res["best_policy"]["expected_profit"] > 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
