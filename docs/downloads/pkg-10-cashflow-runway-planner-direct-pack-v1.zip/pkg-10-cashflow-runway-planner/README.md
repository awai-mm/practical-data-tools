# 黒字倒産を防ぐ資金繰り表・入金サイト・運転資金シミュレーション実務ハンドブック — 実務ツール＆ブラウザ計算機パック

**12ヶ月先の現預金残高と納税資金を見通すキャッシュフロー管理と自動検算レシピ**

作成：実務データ設計室

---

## 1. 同梱ファイル一覧

- `cashflow_runway_workbench.html`：**ブラウザ完結型ワークベンチ（単一HTML）**
  インターネット接続不要・外部送信ゼロ。ダブルクリックしてブラウザ（Chrome / Edge / Safari / Firefox）で開くだけで即座に使用できます。
- `cashflow_runway_cli.py`：**Python標準ライブラリ完結 CLIツール**
  追加ライブラリ（`pip install`）一切不要。Python 3.9以上が動くすべての環境（macOS / Windows / Linux）でそのまま実行できます。
- `samples/problem_data.csv`：典型的な表記揺れ・重複・金額不一致・マイナス値を含む検品テスト用サンプルデータ
- `samples/clean_data.csv`：正規化・検品通過済みの基準サンプルデータ
- `test_tool.py`：同梱ツールの動作を自動検証する単体テストスクリプト
- `SPEC_SHEET.md`：仕様・導入案内ドキュメント

---

## 2. 主な機能

- 月末残高（opening + in - out == closing）検算
- 月次フリーキャッシュフロー算出
- 納税引当後の安全運転資金判定
- 検証済み資金繰りCSV出力

---

## 3. 最短30秒クイックスタート

### 方法A：ブラウザ画面で使う（インストール不要）
1. `cashflow_runway_workbench.html` をダブルクリックしてWebブラウザで開きます。
2. 初期状態でサンプルデータが読み込まれ、検品結果と集計表が表示されます。
3. 手元のCSV/TSVファイルを画面へ貼り付けるか「ファイル選択」から読み込み、「検品・クレンジング実行」をクリックします。
4. 「クレンジング済みCSVを保存」ボタンを押すと、正規化済みのクリーンなCSVファイルが手元にダウンロードされます。

### 方法B：コマンドライン（Python CLI）で使う

```bash
# 1. 問題サンプルデータの検品（読み取り専用チェック）
/usr/bin/python3 cashflow_runway_cli.py samples/problem_data.csv --key month_id

# 2. 自動クレンジング＆クリーンCSV出力
/usr/bin/python3 cashflow_runway_cli.py samples/problem_data.csv \
  --key month_id \
  --fix \
  --output-csv samples/cleaned_output.csv \
  --output-json samples/inspection_report.json

# 3. 自動テストスイートの実行
/usr/bin/python3 test_tool.py
```
