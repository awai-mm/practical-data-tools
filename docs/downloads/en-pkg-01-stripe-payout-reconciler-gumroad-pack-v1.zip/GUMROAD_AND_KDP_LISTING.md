# Stripe, PayPal & Bank Payout CSV Fee Reconciliation Kit

**Zero-Dependency Browser Workbench, Python CLI & Practical Guide for Accounting Close**

- **Suggested Price**: USD 19
- **Focus**: Reconciling gross sales, payment gateway fees, multi-currency rounding, refund clawbacks, and net bank deposits without cloud uploads.
- **Included**:
  1. `en-pkg-01-stripe-payout-reconciler_workbench.html` — 100% Offline Browser Workbench (zero external requests)
  2. `en_pkg_01_stripe_payout_reconciler_cli.py` — Zero-Dependency Python 3 CLI Auditor
  3. `en-pkg-01-stripe-payout-reconciler-kdp-en-v1.epub` — Full Practical Engineering Handbook (EPUB3)
  4. `samples/` & `test_en_package.py` — Sample datasets and automated verification suite
