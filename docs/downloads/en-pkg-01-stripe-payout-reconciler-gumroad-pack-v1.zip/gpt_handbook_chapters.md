# Chapter 1: Why Spreadsheets Fail in Production & The Pre-Flight Audit Pattern

Payment reconciliation becomes difficult when individually reasonable shortcuts interact. A spreadsheet converts an identifier into a number. A formula excludes newly appended rows. A refund appears after the original payout. A bank combines two settlements into one deposit. Every worksheet looks plausible, but the close no longer has a reproducible explanation.

The central problem is uncontrolled interpretation. Production reconciliation requires explicit definitions, exact arithmetic, stable identifiers, and evidence that another person can replay.

This kit uses one normalized transaction schema:

```csv
tx_id,payout_date,gross_amount,processor_fee,tax_withheld,net_payout,currency
sale-001,2026-10-27,100.00,3.20,0.00,96.80,USD
```

These are the required columns. `tx_id` is the primary key. Each row represents one settlement movement, including sales, refunds, fee adjustments, and other supported events.

Source files from Stripe, PayPal, and banks require documented adapters. Their reports can differ in scope, signs, timestamps, and settlement granularity. Renaming headers is insufficient.

**Start with a pre-flight audit.** Before posting entries or matching deposits, establish that the input is structurally valid, uniquely identified, arithmetically consistent, and suitable for the intended reporting period.

The workflow has five stages:

1. Preserve the original export and calculate its SHA-256 digest.
2. Apply a versioned normalization contract.
3. Validate every normalized record.
4. Reconcile settlement groups to independently obtained bank movements.
5. Package exceptions, evidence, and approvals for close.

Keep originals immutable. Normalized files are derived artifacts; corrections belong in the adapter or in a separately documented adjustment.

A successful pre-flight audit means the file satisfies its declared rules. It does not prove that the export contains every transaction, that every payout reached the bank, or that the accounting classification is correct.

Completeness needs independent controls: source report parameters, account coverage, export counts, statement totals, and opening-to-closing balance rollforwards. Arithmetic cannot detect a missing row when the remaining rows still balance.

Treat `payout_date` as the processor’s assigned settlement date under a documented timezone rule. It is not automatically the bank posting date. Weekend delays and bank processing calendars can move cash across reporting periods.

Likewise, `gross_amount` is a settlement measure. It may include amounts that require separate revenue, sales-tax, or liability treatment. The reconciliation kit proves movement of money; the accounting policy determines ledger classification.

Every run should produce a compact evidence bundle: source hashes, adapter version, currency configuration, record counts, validation findings, settlement totals, bank matches, and unresolved differences. That bundle turns a spreadsheet exercise into a repeatable control.

# Chapter 2: Core Validation & Reconciliation Rules for tx_id

**Define the record before validating its numbers.** A row must describe one signed settlement movement in one currency. All four monetary fields must use that currency.

Use this equation:

```text
net_payout = gross_amount - processor_fee - tax_withheld
```

The sign convention is deliberate:

- Positive gross increases settlement proceeds; negative gross reduces them.
- Positive processor fees reduce proceeds; negative fees return previously charged fees.
- Positive withholding reduces proceeds; negative withholding releases an earlier deduction.
- Net payout may be positive, zero, or negative.

A refund of 40.00 with no fee return is therefore `-40.00, 0.00, 0.00, -40.00`. A separate 1.20 fee rebate is `0.00, -1.20, 0.00, 1.20`.

Do not assume refunds reverse original fees. Record the actual settlement movements.

**Protect the primary key.** Treat `tx_id` as an opaque string. Preserve leading zeros, case, and punctuation. Reject empty values, surrounding whitespace, control characters, and duplicates.

Define uniqueness across the combined audit dataset, not separately for each uploaded file. Where source identifiers are only unique within a provider account, use a documented namespace such as:

```text
provider:account:source_event_id
```

Construct that namespace during normalization. Keep the original identifier in supporting evidence.

A customer payment identifier may recur across capture, refund, dispute, and fee events. It is unsuitable as the sole key unless the source guarantees movement-level uniqueness. Each movement needs its own stable identifier.

When overlapping exports contain the same movement, report the overlap. Do not silently discard duplicates. An approved import process may consolidate repeated records only after checking that their financial fields agree and recording provenance.

**Validate structure strictly.** Require the seven named columns exactly once. Reject malformed CSV, wrong field counts, missing amounts, and invalid dates. Allow header reordering only if the implementation maps columns by name.

Use UTF-8, optionally with an initial byte-order mark. Accept standard CSV quoting, including quoted fields containing commas or newlines. Never parse CSV by splitting on commas.

Dates must be real calendar dates in `YYYY-MM-DD` form. Currency codes must belong to a configured allowlist with an explicit minor-unit scale.

**Validate money exactly.** Accept plain decimal strings. Reject currency symbols, thousands separators, accounting parentheses, scientific notation, and excess fractional digits under the chosen contract.

Use integer minor units or exact decimal arithmetic. Binary floating-point arithmetic is unsuitable for acceptance decisions.

For each row, calculate:

```text
residual = gross_amount - processor_fee - tax_withheld - net_payout
```

The residual must equal zero minor units. A one-cent difference is an exception requiring explanation; a tolerance must not conceal it.

Aggregate valid rows by currency and settlement group. With only the required schema, `(payout_date, currency)` is a provisional control group. It is not a unique payout identifier.

Production bank matching needs additional evidence linking transactions to processor payouts and payouts to bank movements. Store those relationships in a sidecar file without changing the required transaction schema.

Never sum different currencies into one reconciliation total. A cross-currency management summary is a separate valuation exercise.

# Chapter 3: Real-World Edge Cases, Rounding Traps & Incident Postmortems

The following USD movements share one payout date. Each has a distinct `tx_id`, even where several relate to the same original customer payment.

| tx_id | gross_amount | processor_fee | tax_withheld | net_payout |
|---|---:|---:|---:|---:|
| sale-100 | 200.00 | 3.20 | 0.00 | 196.80 |
| refund-100 | -40.00 | 0.00 | 0.00 | -40.00 |
| dispute-100 | -60.00 | 15.00 | 0.00 | -75.00 |
| rebate-100 | 0.00 | -1.20 | 0.00 | 1.20 |
| withholding-100 | 0.00 | 0.00 | 2.00 | -2.00 |
| **Total** | **100.00** | **17.00** | **2.00** | **81.00** |

The expected settlement contribution is 81.00. The original sale alone would predict 196.80 and overstate expected cash by 115.80.

**Refund clawbacks cross periods.** A sale can settle in September while its refund reduces an October payout. Preserve the original sale and record the refund as a new movement in its actual settlement period. Link the two in supporting evidence.

**Currency precision is contractual.** Configure the scale for the settlement currency and verify that the export uses major-unit decimal amounts.

| Currency | Minor-unit scale | Valid amount | Reject under this strict contract |
|---|---:|---:|---:|
| USD | 2 | 12.34 | 12.345 |
| EUR | 2 | 12.34 | 12.345 |
| JPY | 0 | 1234 | 1234.5 |
| KWD | 3 | 12.345 | 12.3456 |

This is an example allowlist, not a complete currency registry. Provider APIs and reports may use different representations; adapters must resolve those differences before validation.

Rounding methods matter at conversion boundaries. Rounding 10.005 to two decimals yields 10.01 under half-up rounding and 10.00 under half-even rounding. Rounding three separate amounts of 0.005 half-up produces 0.03; rounding their combined 0.015 produces 0.02.

The auditor must validate already settled amounts without inventing a rounding policy. If conversion must be reproduced, retain the original currency, original amount, rate, rate direction, rounding method, and rounding stage in sidecar evidence.

The seven-column schema cannot independently prove foreign-exchange calculations. Its monetary fields must all be expressed in the declared settlement currency.

**Incident: duplicated payout totals.** An adapter copied a payout’s full net amount onto every constituent transaction. Bank expectations multiplied while gross sales appeared correct. Prevention: require row-level net amounts and independently compare transaction sums with payout control totals.

**Incident: approximate bank matching.** A matching rule accepted deposits within one dollar. Small differences accumulated unnoticed. Investigation found a bank charge and a separate export omission. Prevention: preserve exact residuals and classify each difference individually.

**Incident: duplicate refund keys.** A refund inherited its sale’s identifier. An import overwrote the sale, leaving a plausible but incomplete dataset. Prevention: movement-level keys, duplicate rejection, and source-count controls.

For the 81.00 example, a documented 0.25 receiving-bank charge could explain a 80.75 deposit:

```text
expected bank cash = transaction net + signed external adjustments
                   = 81.00 - 0.25
                   = 80.75
```

Record that charge once. An adjustment must have independent evidence; it must never be created merely to eliminate a residual.

# Chapter 4: Offline Browser Workbench Architecture & Zero-Upload Security

A zero-dependency browser workbench can be delivered as a local HTML file containing its own styles and scripts. It needs no hosted libraries, remote fonts, telemetry, or external account.

The processing path is straightforward:

```text
Local file selection
    → byte preservation and hashing
    → CSV parsing
    → schema and money validation
    → settlement aggregation
    → bank matching and exception review
    → local evidence download
```

Use a file picker or drag-and-drop interface. Read only files deliberately selected by the operator. Display the filename, byte count, record count, and digest so that the operator can identify the exact input.

**Keep arithmetic separate from presentation.** Parse decimal strings into `BigInt` minor units. Never pass monetary values through JavaScript `Number`, including during sorting, summation, or JSON serialization.

For USD, `"123.45"` becomes `12345n`. Formatting reverses the operation without division through floating-point values. Export large integer amounts as strings because JSON has no native `BigInt` type.

Use a state-machine CSV parser that handles quotes, escaped quotes, commas, and line endings. Report logical record numbers separately from physical line numbers when fields contain newlines.

Set documented file-size and record-count limits. For larger supported inputs, use incremental parsing or a locally packaged worker to keep the interface responsive. Reject an oversized file clearly; do not process a truncated prefix.

**Make validation states unmistakable.** Show separate states for parsing, pre-flight validation, bank reconciliation, and approval. A valid file can still have unmatched deposits. A matched deposit can still lack completeness evidence.

Expose each exception with its record number, transaction identifier, rule, and exact residual. Keep failed rows visible. Do not include incomplete totals in a display labeled “reconciled.”

Bank matching must support one payout to several bank entries and several payouts to one bank entry. Store explicit allocation relationships, currency, signed amount, processor payout reference, and bank transaction reference. Prevent any bank amount from being allocated twice.

**Enforce the zero-upload boundary.** Include no network calls, third-party scripts, analytics, remote images, or automatic error reporting. Use a restrictive Content Security Policy, including `connect-src 'none'`, `object-src 'none'`, and `form-action 'none'`. Where practical, authorize embedded scripts by hash.

Validate the distributed release in a disconnected environment and inspect its network activity in a connected test environment. The application’s controls do not govern browser extensions or other software on the workstation.

Keep working data in memory by default. Persistent storage and session restoration require an explicit operator action. Provide a clear reset control.

Render imported text with safe text APIs, never executable HTML. Offer separate machine-readable exports and spreadsheet-safe review exports: spreadsheet applications can interpret certain cell prefixes as formulas. Preserve original values in the evidence archive and document any display-only escaping.

# Chapter 5: Automating Audits with Zero-Dependency Python 3 CLI & CI/CD Exit Codes

The CLI should apply the same contract as the browser. Python’s standard library supplies CSV parsing, date validation, hashing, JSON output, and exact integer arithmetic.

The following Python 3.8+ example performs pre-flight validation. It deliberately reports bank reconciliation as unperformed. It accepts up to 50 MiB and uses a small, explicit currency allowlist.

```python
import csv
import hashlib
import io
import json
import re
import sys
from datetime import date

FIELDS = (
    "tx_id", "payout_date", "gross_amount",
    "processor_fee", "tax_withheld", "net_payout", "currency"
)
SCALES = {"USD": 2, "EUR": 2, "GBP": 2, "JPY": 0, "KWD": 3}
LIMIT = 50 * 1024 * 1024
AMOUNT = re.compile(r"-?(0|[1-9][0-9]{0,23})(\.[0-9]+)?")
DATE = re.compile(r"[0-9]{4}-[0-9]{2}-[0-9]{2}")


def minor_units(value, scale):
    if not AMOUNT.fuテキスト処理系atch(value):
        raise ValueError("invalid decimal amount")
    negative = value.startswith("-")
    whole, _, fraction = value.lstrip("-").partition(".")
    if len(fraction) > scale:
        raise ValueError("excess fractional digits")
    units = int(whole) * (10 ** scale)
    units += int(fraction.ljust(scale, "0") or "0")
    return -units if negative else units


def audit(raw):
    csv.field_size_limit(4096)
    text = raw.decode("utf-8-sig")
    reader = csv.reader(io.StringIO(text, newline=""), strict=True)
    header = next(reader, None)

    if (
        header is None
        or len(header) != len(FIELDS)
        or set(header) != set(FIELDS)
    ):
        raise ValueError("required headers must appear exactly once")

    seen = set()
    issues = []
    totals = {}
    count = 0

    for record, values in enumerate(reader, start=2):
        count += 1
        try:
            if len(values) != len(header):
                raise ValueError("wrong field count")
            row = dict(zip(header, values))
            tx = row["tx_id"]

            if (
                not tx
                or len(tx) > 160
                or tx != tx.strip()
                or any(ord(c) < 32 or ord(c) == 127 for c in tx)
            ):
                raise ValueError("invalid tx_id")
            if tx in seen:
                raise ValueError("duplicate tx_id")
            seen.add(tx)

            day = row["payout_date"]
            if not DATE.fuテキスト処理系atch(day):
                raise ValueError("date must be YYYY-MM-DD")
            date.fromisoformat(day)

            currency = row["currency"]
            if currency not in SCALES:
                raise ValueError("unsupported currency")
            scale = SCALES[currency]

            gross, fee, tax, net = [
                minor_units(row[name], scale)
                for name in FIELDS[2:6]
            ]
            residual = gross - fee - tax - net
            if residual:
                raise ValueError(
                    "equation residual: {} minor units".format(residual)
                )

            key = (day, currency)
            totals[key] = totals.get(key, 0) + net

        except ValueError as exc:
            issues.append({"record": record, "error": str(exc)})

    if count == 0:
        issues.append({"record": 1, "error": "no transaction records"})

    # Suppress partial totals whenever any record fails.
    groups = [] if issues else [
        {
            "payout_date": day,
            "currency": currency,
            "net_minor": str(net)
        }
        for (day, currency), net in sorted(totals.items())
    ]
    return {
        "status": "failed" if issues else "passed",
        "records_seen": count,
        "issues": issues,
        "provisional_groups": groups
    }


def main():
    report = {
        "tool_version": "1.0",
        "currency_scales": SCALES,
        "stage": "preflight",
        "bank_reconciliation": "not_performed"
    }
    try:
        if len(sys.argv) != 2:
            raise RuntimeError("usage: python3 audit.py PAYOUT.csv")
        with open(sys.argv[1], "rb") as source:
            raw = source.read(LIMIT + 1)
        if len(raw) > LIMIT:
            raise RuntimeError("input exceeds 50 MiB limit")

        report["source_sha256"] = hashlib.sha256(raw).hexdigest()
        report.update(audit(raw))
        code = 1 if report["issues"] else 0

    except (OSError, UnicodeError, csv.Error, RuntimeError) as exc:
        report.update(status="error", error=str(exc))
        code = 2
    except ValueError as exc:
        report.update(status="failed", error=str(exc))
        code = 1

    print(json.dumps(report, sort_keys=True, indent=2))
    return code


if __name__ == "__main__":
    sys.exit(main())
```

The program reports the first validation failure encountered in each record. A record number identifies a CSV record, which may span several physical lines.

Exit code `0` means pre-flight passed. Code `1` means the input violated the contract. Code `2` means invocation, reading, decoding, parsing, or resource limits prevented completion. None means the accounting close is approved.

A production bank-matching stage should use exact signed integers:

```python
def bank_residual(expected_net, bank_movements, adjustments):
    expected_cash = expected_net + sum(adjustments)
    return sum(bank_movements) - expected_cash
```

Call this only after verifying that every argument belongs to one currency and an explicitly linked settlement group. Adjustment evidence must establish that the amount is absent from transaction net totals.

The production wrapper can reserve code `3` for unresolved bank differences or incomplete allocations. Its report should distinguish unmatched cash, timing items, documented charges, reserves, and unexplained differences.

For scheduled operation, run the audit on a controlled local runner. Hosted continuous integration can violate the zero-upload requirement when payment files or reports enter remote jobs, caches, logs, or artifact stores. Shared CI can test the code using synthetic fixtures.

A local job can invoke the CLI without a shell:

```python
import subprocess
import sys

with open("preflight-report.json", "w", encoding="utf-8") as output:
    result = subprocess.run(
        [sys.executable, "audit.py", "normalized.csv"],
        stdout=output,
        check=False,
    )
sys.exit(result.returncode)
```

Test duplicate identifiers, missing rows against external controls, quoted CSV fields, invalid dates, refunds, negative fees, unsupported currencies, excessive precision, and deliberately broken equations. Include amounts beyond JavaScript’s safe integer range to verify browser parity.

Bind every report to the input digest, executable digest, adapter version, and currency configuration. Re-running identical inputs under identical rules should produce identical financial findings.

# Chapter 6: Standard Operating Checklist & Executive Sign-Off Template

A reliable close separates preparation, reconciliation, and approval. Each stage leaves evidence that the next reviewer can inspect.

**Preparation checklist**

- Confirm legal entity, processor accounts, bank accounts, reporting period, and timezone.
- Preserve original exports and record their filters, timestamps, and hashes.
- Check completeness against independent source totals and balance rollforwards.
- Confirm adapter version, movement-level identifiers, currency scales, and sign conventions.
- Identify late settlements, refunds, disputes, reserves, and foreign-exchange evidence.

**Execution checklist**

- Run structural validation before using any totals.
- Resolve duplicate keys and malformed records through documented corrections.
- Require zero unexplained row-equation residuals.
- Compare normalized transaction sums with processor payout controls.
- Match payouts to bank movements using explicit allocation references.
- Prevent duplicate or excessive allocation of each bank movement.
- Reconcile external charges, reserves, and other adjustments with independent evidence.
- Separate timing items from unexplained differences and assign owners and deadlines.
- Tie approved settlement and cash totals to the appropriate ledger accounts.

A timing difference is an open reconciliation item until subsequent bank evidence resolves it. Record the expected clearing date and verify actual clearance in the next cycle. Do not perpetually relabel an aging unexplained difference as timing.

**Review checklist**

- Confirm that the final report references the exact reviewed files.
- Check transaction counts and totals against source controls.
- Inspect material adjustments and every unresolved exception.
- Confirm that foreign currencies remain separately reconciled.
- Verify that rounding policy is documented wherever conversion occurs.
- Archive the evidence package under the organization’s retention and access policy.

Use the following sign-off template:

> **Close period:**  
> **Entity and accounts covered:**  
> **Prepared by / date:**  
> **Reviewed by / date:**  
> **Evidence package reference and digest:**  
> **Adapter, validator, and currency configuration versions:**  
> **Completeness controls and results:**  
> **Gross, fees, withholding, and net totals by currency:**  
> **Processor payout control totals:**  
> **Matched bank movements and allocation references:**  
> **Documented external adjustments:**  
> **Open timing items, owners, and expected clearance dates:**  
> **Unexplained differences and disposition:**  
> **Ledger posting references:**  
> **Decision:** Approved / Approved with documented exceptions / Held  
> **Approval authority and date:**

Approval certifies the scope and evidence stated in the package. Any accepted exception needs an amount, currency, rationale, owner, and resolution deadline. Materiality guides escalation; it does not justify deleting discrepancies or altering source amounts.

A subsequent correction must produce a new evidence package linked to the superseded version. Preserve both versions so that the close remains reproducible.
