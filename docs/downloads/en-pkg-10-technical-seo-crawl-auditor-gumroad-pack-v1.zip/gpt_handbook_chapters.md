# Chapter 1: Why Spreadsheets Fail in Production & The Pre-Flight Audit Pattern

A crawl export is evidence of observed responses, links, and page attributes. It is not a complete inventory of search eligibility. Treating it as a spreadsheet cleanup exercise creates false confidence: rows become tidy while redirect cycles, conflicting canonical signals, and performance problems remain unresolved.

A production audit must answer four questions:

1. Can the export be trusted?
2. Where do redirects and canonical references lead?
3. Which pages deserve remediation first?
4. What evidence proves that the release fixed the problem?

The objective is a reproducible decision process, supported by an offline browser workbench and a command-line checker that apply the same rules.

## Why spreadsheets become unreliable

Spreadsheet applications routinely reinterpret identifiers, convert URL-like strings into links, hide rows behind filters, and round values for display. A primary key such as `000174` may become `174`. Two distinct records then appear identical.

Redirects introduce a second problem: they form a directed graph. A lookup can identify the next destination, but detecting a cycle requires following successive edges while retaining traversal state. Sorting rows cannot expose every cycle, particularly when the cycle crosses crawl segments.

Canonical relationships add another graph with different semantics. A redirect changes navigation; a canonical declaration expresses a preferred representative. Combining both into one “destination” column destroys information needed to diagnose conflicting signals.

Finally, manual edits undermine reconciliation. If an analyst deletes duplicate rows, changes thresholds, or pastes corrected URLs into the source sheet, the resulting report may no longer explain what the crawler actually observed.

## Establish the evidence contract

Every input must contain these columns:

```text
url_id,source_url,http_status,redirect_target,canonical_url,word_count,load_time_ms
```

`url_id` is the primary key. Keep it as an opaque string.

Before interpreting findings, record:

- Export filename, byte size, and SHA-256 digest.
- Crawl start and completion times, where available.
- Crawler version, rendering mode, user agent, and authentication context.
- Included hosts, excluded paths, and URL sampling rules.
- Rule version and configured thresholds.
- Known gaps in robots directives, content extraction, or timing measurements.

A hash identifies the artifact; it does not prove that the crawler collected correct or complete data.

## Apply the pre-flight pattern

The pre-flight audit separates structural validity from site findings.

**Parse.** Decode the file deterministically, support quoted commas and multiline fields, and reject malformed records. Never split CSV lines manually.

**Validate.** Check required columns, identifier uniqueness, numeric domains, and URL syntax. Preserve original values alongside any derived comparison keys.

**Reconcile.** Account for every parsed record as accepted or rejected. Count distinct identifiers separately from physical records. A multiline CSV record may span several file lines.

**Analyze.** Construct redirect and canonical graphs only after ambiguous identity relationships have been resolved.

**Release evidence.** Produce machine-readable findings and a human review summary tied to the input digest and rule configuration.

Keep two gates distinct. An invalid export blocks trustworthy analysis. A valid export may still reveal critical site defects.

For financial prioritization, estimate affected organic landing pages, traffic exposure, conversion contribution, and engineering effort. Label estimates explicitly. A crawl alone cannot establish lost revenue, causality, or guaranteed recovery.

# Chapter 2: Core Validation & Reconciliation Rules for url_id

## Preserve identity before normalizing anything

A valid `url_id` is nonempty, contains no prohibited control characters, and is unique within the audit artifact. Leading zeros are significant. Case is significant unless the producing system explicitly defines otherwise.

Reject surrounding whitespace rather than silently trimming it. Otherwise, `"page-7"` and `" page-7 "` can collapse into the same identity after ingestion.

Duplicate identifiers require investigation even when every field matches. An exact duplicate may indicate an export merge defect; a conflicting duplicate may indicate mixed crawl snapshots. Neither should be silently discarded.

Also detect duplicate `source_url` values under different identifiers. These do not violate the primary-key rule, but they can make graph traversal ambiguous. Two rows for the same URL might report different statuses or destinations.

For this workbench, use a strict single-snapshot contract: one source URL per artifact. If repeated observations are intentional, redesign the input contract to include observation identity and timestamps.

## Validate each field against its meaning

`source_url` must be an absolute HTTP or HTTPS URL with a valid authority. Reject embedded credentials. Treat fragments as an input-contract problem because they do not identify separate HTTP retrievals.

`http_status` must be an integer from 100 through 599. If the crawler uses zero or text for network failures, map that representation through a documented preprocessing step; do not reinterpret it as an HTTP response.

`word_count` must be a nonnegative integer. Define whether it measures rendered main content, all visible text, or extracted HTML text. Counts from different extraction methods are not directly comparable.

`load_time_ms` must be finite and nonnegative. Parse it as a decimal value when decimal precision matters. Missing timing is unknown, not zero.

Empty `redirect_target` and `canonical_url` fields can be legitimate. Their absence must be evaluated in context.

Resolve relative references against the source URL only if the export contract defines that behavior. A raw HTML canonical may depend on a document base URL that these seven columns do not contain. Prefer exports that already contain resolved canonical URLs.

## Keep URL comparison conservative

Maintain three distinct representations:

- The original exported string.
- A resolved absolute destination.
- A documented comparison key.

A production comparison key can lowercase the scheme and hostname and remove default ports. It must not lowercase paths, remove arbitrary query parameters, collapse trailing slashes, or decode reserved characters without an explicit site policy.

For example, `/Guide` and `/guide` may be different resources. Likewise, `?page=2` can change content rather than merely track attribution.

Normalization must never create undocumented merges.

## Evaluate redirect paths

Treat 301, 302, 303, 307, and 308 as redirect statuses for this checker. A 304 response is not a navigation redirect.

For each redirecting source:

1. Require a usable destination.
2. Resolve the destination.
3. Follow observed redirect edges.
4. Stop at a terminal response, missing observation, or repeated node.
5. Record the complete path and the stopping reason.

A repeated node proves a cycle in the observed graph. A destination missing from the export proves only that the path is incomplete. It does not prove that the destination is broken.

Define chain length as the number of redirect responses traversed. A direct redirect to a 200 page has one hop.

## Evaluate canonical agreement

Review canonical declarations for targets that:

- Return an observed error.
- Redirect elsewhere.
- Point back through a canonical cycle.
- Conflict with the intended representative URL.
- Fall outside the available crawl evidence.

A non-self canonical is not inherently defective. Syndication, duplicate variants, and parameterized URLs can justify consolidation. Maintain approved patterns and exceptions.

A particularly useful conflict is a redirect from A to B followed by a canonical from B back to A. Report both relationships so the owner can choose a consistent representative.

These columns cannot establish indexability. They lack robots directives, response headers, robots.txt decisions, and other eligibility evidence. Label successful responses as **200-response candidates**, then join additional evidence before describing them as indexable.

# Chapter 3: Real-World Edge Cases, Rounding Traps & Incident Postmortems

## Edge cases that change the decision

| Observation | Incorrect conclusion | Required interpretation |
|---|---|---|
| A redirects to B; B is absent | B is broken | Destination is unobserved |
| A returns 304 | Follow a redirect | Review conditional-request crawl settings |
| A canonicals to B; both return 200 | Canonical mismatch | Check intended consolidation policy |
| A has 80 extracted words | Delete A | Inspect purpose and extraction quality |
| A loads in 2,500.4 ms | Meets a 2,500 ms limit | Compare the original decimal value |
| Two identifiers share one source URL | Both rows are safe to traverse | Resolve duplicate observations first |
| A returns 200 with an error message | Healthy page | Inspect for a soft-error response |

## Define boundaries before displaying rounded values

Suppose the warning threshold is strictly greater than 2,500 milliseconds. The value `2500.4` must trigger a warning even if the dashboard displays `2.5 s`.

Use raw values for rule evaluation and rounded values only for presentation. Display enough precision near boundaries to explain the result.

Binary floating-point can introduce unexpected results in decimal arithmetic. Decimal parsing also makes it straightforward to reject non-finite values such as `NaN` and `Infinity`. Those values can otherwise bypass ordinary comparisons or contaminate summaries.

Write threshold semantics explicitly:

```text
Thin-content review: word_count < 200
Slow-response review: load_time_ms > 2500
Long redirect chain: redirect_hops > 1
```

Equality therefore passes all three example thresholds.

A single load measurement is noisy. Document whether timing represents server response, document completion, or a browser event. Do not compare measurements taken under materially different conditions.

For template performance, group URLs using maintained route rules, then inspect counts, medians, upper percentiles, and repeated measurements. A single observation cannot establish a template regression.

## Postmortem: migration rules created a cycle

A release introduced these rules:

| Source | Status | Destination |
|---|---:|---|
| `/products/widget` | 301 | `/shop/widget` |
| `/shop/widget` | 302 | `/products/widget` |

The migration team owned the first rule. A regional routing layer owned the second. Each rule passed an isolated test because the test checked only the immediate response.

The user-visible result was a redirect loop. The underlying process failure was fragmented ownership and insufficient end-to-end verification.

The repair selected `/shop/widget` as the intended destination, removed the reverse redirect, and aligned its canonical declaration. Verification followed redirects through the deployed routing layers and recrawled both URLs.

The preventive control was a graph check against the combined routing inventory, supplemented by deployed HTTP checks. Reviewing configuration files alone would not cover runtime routing behavior.

## Postmortem: canonical cleanup concealed useful pages

A category template applied the first page’s canonical to every paginated page. Reviewers assumed the pages were duplicates because headings and introductions matched.

The exported word counts looked healthy because navigation and footer text dominated extraction. Product listings differed substantially between pages, but the aggregate counts hid that distinction.

The repair required content and search architecture review: identify which pages served distinct discovery needs, choose the intended canonical policy, and align internal links and sitemaps. Changing canonicals alone could not resolve contradictory architecture.

The preventive control separated content-extraction quality from word-count thresholds. Low or high counts became review signals rather than automatic publishing decisions.

## Postmortem: performance remediation targeted the wrong component

A dashboard ranked pages by one slow crawl measurement. Engineers optimized application code, but repeat tests showed that the delay came from a temporary downstream dependency.

The initial report had omitted sample size and measurement conditions. It also treated a measured delay as a confirmed template defect.

The corrected report grouped results by template, recorded repeated samples, and separated server, rendering, and dependency hypotheses. Financial prioritization used affected sessions and conversion exposure, with confidence ranges rather than a single promised revenue figure.

# Chapter 4: Offline Browser Workbench Architecture & Zero-Upload Security

## Make local processing an architectural property

A zero-upload workbench reads user-selected files and performs parsing, validation, and analysis inside the browser. It does not send crawl rows, URLs, findings, or filenames to a remote service.

Package scripts, styles, fonts, and documentation locally. Exclude analytics, remote error reporting, external font requests, and third-party script loaders. Where supported, use a restrictive content security policy, including `connect-src 'none'`, and verify its behavior in the intended deployment environment.

The workbench must not fetch audited URLs. Doing so would disclose the inventory, introduce network-dependent results, and turn an offline checker into a crawler.

Remote destination verification belongs in a separate, explicitly configured process.

## Separate ingestion, analysis, and presentation

Use a background worker for CSV parsing and graph processing. Stream chunks through a parser that correctly handles quoted fields crossing chunk boundaries. Provide cancellation, progress, and configurable size limits.

Maintain:

- A record store keyed by `url_id`.
- A source URL index.
- Redirect and canonical adjacency structures.
- A finding store with rule codes and evidence paths.
- A run manifest containing hashes, versions, and thresholds.

Memoize graph results to avoid retraversing long shared chains. A well-designed traversal can analyze the observed graph in time proportional to vertices and edges.

Large exports still consume substantial memory: decoded strings, indexes, and findings can exceed the original file size. Publish tested capacity limits and refuse oversized inputs cleanly.

## Design review around evidence

The interface should offer an overview, a filterable findings list, and a path inspector. Each finding should expose the source identifier, original values, resolved references, rule explanation, and recommended verification.

Allow reviewers to group by template or path family without losing access to individual records. Separate invalid data, confirmed graph defects, incomplete evidence, and editorial review signals.

Exceptions need an owner, reason, scope, and expiry date. Store them separately from the source export and include them in the run manifest.

For browser and CLI consistency, maintain shared test fixtures covering relative references, cycles, duplicate identifiers, decimal boundaries, and missing targets.

## Treat exports as sensitive artifacts

Render imported content as text, never as executable HTML. Do not automatically load images, previews, or clickable destinations from CSV cells.

Memory-only operation should be the default. Any persistent browser storage must be explicit, inspectable, and removable. Avoid retaining crawl data in service-worker caches.

Spreadsheet exports require formula-injection defenses. Merely quoting a field does not stop a spreadsheet from interpreting leading formula characters. Offer a separately labeled spreadsheet-safe export and preserve exact source values in JSON.

Zero upload does not mean zero exposure. Browser extensions, local backups, exported files, screenshots, and shared devices remain outside the application’s confidentiality boundary. Verify network behavior and retention behavior rather than relying on a privacy label.

# Chapter 5: Automating Audits with Zero-Dependency Python 3 CLI & CI/CD Exit Codes

The following compact checker uses only the Python standard library. It validates the input contract, detects redirect loops and incomplete chains, and emits canonical, content, and timing review signals.

Its URL comparison is deliberately exact after relative-reference resolution. Canonical cycles, template aggregation, approved consolidation policies, and richer normalization remain extension points.

Save it as `audit.py`:

```python
import argparse
import csv
import hashlib
import io
import json
import re
from decimal import Decimal, InvalidOperation
from pathlib import Path
from urllib.parse import urljoin, urlsplit

FIELDS = [
    "url_id", "source_url", "http_status", "redirect_target",
    "canonical_url", "word_count", "load_time_ms",
]
REDIRECTS = {301, 302, 303, 307, 308}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def absolute_url(value):
    require(bool(value), "empty URL")
    require(
        not any(c.isspace() or ord(c) < 32 or ord(c) == 127
                for c in value),
        "URL contains whitespace or controls",
    )
    require("\\" not in value, "URL contains backslash")
    p = urlsplit(value)
    require(p.scheme in {"http", "https"} and p.hostname,
            "expected absolute HTTP(S) URL")
    require(p.username is None and p.password is None,
            "credentials in URL")
    require("#" not in value, "fragment unsupported")
    _ = p.port  # Raises ValueError for malformed ports.
    return value


def reference(source, value):
    if not value:
        return ""
    require(
        not any(c.isspace() or ord(c) < 32 or ord(c) == 127
                for c in value),
        "reference contains whitespace or controls",
    )
    require("\\" not in value and "#" not in value,
            "unsupported reference")
    return absolute_url(urljoin(source, value))


def run(path, min_words, max_ms):
    raw = Path(path).read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    stream = io.StringIO(raw.decode("utf-8-sig"), newline="")
    reader = csv.DictReader(stream, strict=True)
    headers = reader.fieldnames
    require(headers is not None, "missing header")
    require(len(headers) == len(set(headers)), "duplicate header")
    require(set(FIELDS) <= set(headers), "missing required columns")

    records, ids, urls = [], set(), set()
    for number, row in enumerate(reader, start=1):
        try:
            require(None not in row, "extra CSV fields")
            require(all(v is not None for v in row.values()),
                    "missing CSV fields")
            key = row["url_id"]
            require(key and key == key.strip(), "invalid url_id")
            require(not any(ord(c) < 32 or ord(c) == 127
                            for c in key), "control in url_id")
            require(key not in ids, "duplicate url_id")
            source = absolute_url(row["source_url"])
            require(source not in urls, "duplicate source_url")

            require(re.fuテキスト処理系atch(r"[0-9]{3}", row["http_status"]),
                    "invalid status")
            status = int(row["http_status"])
            require(100 <= status <= 599, "status out of range")
            require(re.fuテキスト処理系atch(r"[0-9]+", row["word_count"]),
                    "invalid word_count")
            words = int(row["word_count"])
            require(re.fuテキスト処理系atch(r"[0-9]+(?:\.[0-9]+)?",
                                 row["load_time_ms"]),
                    "invalid load_time_ms")
            elapsed = Decimal(row["load_time_ms"])
            require(elapsed.is_finite() and elapsed >= 0,
                    "invalid timing")

            records.append({
                "id": key, "url": source, "status": status,
                "redirect": reference(source, row["redirect_target"]),
                "canonical": reference(source, row["canonical_url"]),
                "words": words, "ms": elapsed,
            })
            ids.add(key)
            urls.add(source)
        except (ValueError, InvalidOperation) as exc:
            raise ValueError(f"record {number}: {exc}") from exc

    require(bool(records), "empty crawl")
    index = {r["url"]: r for r in records}
    findings = []

    def add(row, code, severity, **evidence):
        findings.append({
            "url_id": row["id"], "source_url": row["url"],
            "code": code, "severity": severity, **evidence,
        })

    for row in records:
        if row["status"] in REDIRECTS:
            current, seen, route = row["url"], set(), []
            hops = 0
            while True:
                route.append(current)
                if current in seen:
                    add(row, "REDIRECT_LOOP", "error", path=route)
                    break
                seen.add(current)
                node = index.get(current)
                if node is None:
                    add(row, "UNOBSERVED_TARGET", "warning", path=route)
                    break
                if node["status"] not in REDIRECTS:
                    if node["status"] != 200:
                        add(row, "TERMINAL_STATUS_REVIEW", "warning",
                            status=node["status"], path=route)
                    break
                if not node["redirect"]:
                    add(row, "MISSING_REDIRECT_TARGET", "error",
                        path=route)
                    break
                hops += 1
                current = node["redirect"]
            if hops > 1:
                add(row, "MULTIPLE_REDIRECT_HOPS", "warning", hops=hops)
        elif row["redirect"]:
            add(row, "UNEXPECTED_REDIRECT_FIELD", "warning")

        if row["status"] >= 400:
            add(row, "HTTP_ERROR_REVIEW", "warning",
                status=row["status"])

        if row["status"] == 200:
            target = row["canonical"]
            if target:
                observed = index.get(target)
                if observed is None:
                    add(row, "CANONICAL_UNOBSERVED", "warning",
                        target=target)
                elif observed["status"] != 200:
                    add(row, "CANONICAL_TARGET_STATUS", "warning",
                        target=target, status=observed["status"])
                if target != row["url"]:
                    add(row, "NONSELF_CANONICAL_REVIEW", "warning",
                        target=target)
            if row["words"] < min_words:
                add(row, "LOW_WORD_COUNT_REVIEW", "warning",
                    word_count=row["words"])
            if row["ms"] > max_ms:
                add(row, "SLOW_RESPONSE_REVIEW", "warning",
                    load_time_ms=str(row["ms"]))

    return {
        "sha256": digest,
        "rule_version": "1",
        "policy": {"min_words": min_words, "max_ms": str(max_ms)},
        "records": len(records),
        "findings": findings,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("csv_path")
    parser.add_argument("--min-words", type=int, default=200)
    parser.add_argument("--max-ms", default="2500")
    parser.add_argument("--fail-on-warning", action="store_true")
    args = parser.parse_args()
    try:
        limit = Decimal(args.max_ms)
        require(args.min_words >= 0, "negative word threshold")
        require(limit.is_finite() and limit >= 0,
                "invalid timing threshold")
        report = run(args.csv_path, args.min_words, limit)
    except (OSError, UnicodeError, csv.Error,
            ValueError, InvalidOperation) as exc:
        print(json.dumps({"input_error": str(exc)}))
        return 2

    print(json.dumps(report, ensure_ascii=True, indent=2))
    blocked = any(
        f["severity"] == "error" or args.fail_on_warning
        for f in report["findings"]
    )
    return 1 if blocked else 0


if __name__ == "__main__":
    raise SystemExit(main())
```

Run the checker and retain its report:

```sh
python3 audit.py crawl.csv --min-words 200 --max-ms 2500 > audit.json
```

The exit-code contract is:

| Code | Meaning | Pipeline action |
|---:|---|---|
| 0 | Valid input; no blocking findings | Continue; retain warnings |
| 1 | Valid input; blocking findings | Stop the release gate |
| 2 | Invalid input, configuration, or file access | Repair the audit input or invocation |

Argument-parser errors also return 2. Unexpected runtime failures must be classified as checker failures by the CI wrapper, using process output and report-schema validation; never treat an absent report as a successful audit.

This example fails fast on invalid input and reads the file into memory. Its redirect traversal can be quadratic on long shared chains. Apply input limits, then add streaming, memoization, and aggregated validation diagnostics for large deployments.

In CI, pin Python and rule versions, retain the input digest, and restrict artifact access. Avoid piping through commands that hide the checker’s exit status.

Test meaningful failure modes: self-loops, multi-node loops, relative references, missing observations, duplicate identifiers, quoted multiline fields, and threshold boundaries. Compare findings against a reviewed baseline only after checking crawl coverage; a smaller crawl can appear healthier simply because problematic URLs disappeared.

# Chapter 6: Standard Operating Checklist & Executive Sign-Off Template

## Operating checklist

Before analysis:

- Confirm crawl scope, timing definitions, and content extraction method.
- Preserve the original export and compute its digest.
- Validate identifiers, field types, and record reconciliation.
- Confirm that duplicate observations and unresolved references are visible.

Before remediation:

- Assign redirect and canonical decisions to named owners.
- Select intended representative URLs.
- Review thin-content candidates for user purpose and distinct value.
- Confirm performance patterns with repeat measurements.
- Estimate business exposure separately from confirmed technical defects.

Before release:

- Test complete redirect paths through deployed routing layers.
- Align canonical declarations, internal links, and sitemap entries.
- Review approved exceptions and their expiration dates.
- Verify that audit coverage remains comparable.
- Attach rollback steps and assign post-release monitoring.

After release:

- Recrawl affected paths and representative unaffected templates.
- Confirm that loops and conflicting signals are resolved.
- Monitor search outcomes separately from deployment correctness.
- Record remaining uncertainty and schedule follow-up review.

## Executive sign-off template

**Audit identity:**  
Artifact name, SHA-256 digest, crawl window, rule version, and policy thresholds.

**Scope and limitations:**  
Included hosts and templates, exclusions, missing indexability evidence, and timing constraints.

**Confirmed defects:**  
Counts of unique affected URLs, grouped by defect type. Separate root causes from downstream affected paths.

**Remediation delivered:**  
Routing changes, canonical policy changes, content decisions, and performance fixes, with accountable owners.

**Verification evidence:**  
Pre-release checks, deployed-path verification, recrawl results, and comparable coverage measures.

**Business assessment:**  
Observed traffic exposure, estimated financial implications, assumptions, confidence level, and implementation cost.

**Accepted exceptions:**  
Issue, rationale, owner, expiration date, and compensating monitoring.

**Release decision:**  
Approved, approved with documented exceptions, or blocked.

**Accountability:**  
Engineering owner, search owner, business approver, decision date, and next review date.

Approval confirms that the specified evidence supports the release decision. It does not guarantee indexing, rankings, or revenue. Those outcomes require subsequent measurement against the agreed baseline.
