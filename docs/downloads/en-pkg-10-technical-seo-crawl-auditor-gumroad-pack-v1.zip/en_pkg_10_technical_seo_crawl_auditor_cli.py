#!/usr/bin/env python3
"""Technical SEO Crawl CSV, Redirect Chain & Canonical Auditor — Zero-Dependency Python 3 CLI Auditor."""
from __future__ import annotations
import argparse, csv, json, sys
from pathlib import Path

KEY_COLUMN = "url_id"
REQUIRED_COLUMNS = ["url_id", "source_url", "http_status", "redirect_target", "canonical_url", "word_count", "load_time_ms"]

def audit_csv(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        cols = reader.fieldnames or []
        missing = [c for c in REQUIRED_COLUMNS if c not in cols]
        seen = set()
        issues = []
        rows = 0
        for idx, row in enumerate(reader, start=2):
            rows += 1
            k = (row.get(KEY_COLUMN) or "").strip()
            if not k:
                issues.append({"line": idx, "code": "EMPTY_KEY"})
            elif k in seen:
                issues.append({"line": idx, "code": "DUPLICATE_KEY", "key": k})
            else:
                seen.add(k)
        return {"ok": not missing and not issues, "rows": rows, "missing_columns": missing, "issues": issues}

def main() -> int:
    p = argparse.ArgumentParser(description="Technical SEO Crawl CSV, Redirect Chain & Canonical Auditor")
    p.add_argument("csv_file")
    args = p.parse_args()
    res = audit_csv(Path(args.csv_file))
    print(json.dumps(res, indent=2))
    return 0 if res["ok"] else 1

if __name__ == "__main__":
    raise SystemExit(main())
