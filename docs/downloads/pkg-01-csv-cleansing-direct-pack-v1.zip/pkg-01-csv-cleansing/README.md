# 現場のCSV・売上・在庫・帳簿データを一発検品・クレンジングする実務ハンドブック — 実務ツール＆ブラウザ計算機パック

**手作業の手戻りをゼロにするデータ品質検査・表記揺れ正規化・集計自動化レシピ**

作成：実務データ設計室

---

## 1. 同梱ファイル一覧

- `csv_cleansing_workbench.html`：**ブラウザ完結型ワークベンチ（単一HTML）**
  インターネット接続不要・外部送信ゼロ。ダブルクリックしてブラウザ（Chrome / Edge / Safari / Firefox）で開くだけで即座に使用できます。
- `csv_cleansing_cli.py`：**Python標準ライブラリ完結 CLIツール**
  追加ライブラリ（`pip install`）一切不要。Python 3.9以上が動くすべての環境（macOS / Windows / Linux）でそのまま実行できます。
- `samples/problem_data.csv`：典型的な表記揺れ・重複・金額不一致・マイナス値を含む検品テスト用サンプルデータ
- `samples/clean_data.csv`：正規化・検品通過済みの基準サンプルデータ
- `test_tool.py`：同梱ツールの動作を自動検証する単体テストスクリプト
- `SPEC_SHEET.md`：仕様・導入案内ドキュメント

---

## 2. 主な機能

- CSV/TSV自動判定およびパース
- 主キー（record_id）の重複・欠損検査
- 日付表記揺れ（YYYY/MM/DD, YYYY.M.D, 全角数字等）の検出とYYYY-MM-DD正規化
- 数量・単価・金額・在庫数の全角数字・カンマ・通貨記号クレンジング
- 数量×単価＝金額（quantity * unit_price == amount）の自動検算
- マイナス在庫（stock_after < 0）および異常数量の警告
- カテゴリ別・日別の売上・数量サマリ集計とクリーンCSV出力

---

## 3. 最短30秒クイックスタート

### 方法A：ブラウザ画面で使う（インストール不要）
1. `csv_cleansing_workbench.html` をダブルクリックしてWebブラウザで開きます。
2. 初期状態でサンプルデータが読み込まれ、検品結果と集計表が表示されます。
3. 手元のCSV/TSVファイルを画面へ貼り付けるか「ファイル選択」から読み込み、「検品・クレンジング実行」をクリックします。
4. 「クレンジング済みCSVを保存」ボタンを押すと、正規化済みのクリーンなCSVファイルが手元にダウンロードされます。

### 方法B：コマンドライン（Python CLI）で使う

```bash
# 1. 問題サンプルデータの検品（読み取り専用チェック）
/usr/bin/python3 csv_cleansing_cli.py samples/problem_data.csv --key record_id

# 2. 自動クレンジング＆クリーンCSV出力
/usr/bin/python3 csv_cleansing_cli.py samples/problem_data.csv \
  --key record_id \
  --fix \
  --output-csv samples/cleaned_output.csv \
  --output-json samples/inspection_report.json

# 3. 自動テストスイートの実行
/usr/bin/python3 test_tool.py
```
