#!/usr/bin/env python3
# coding: utf-8
"""
自動検証テストスイート (pkg-08 / pkg-08-log-error-digest)
- Python CLIツールの異常検出（終了コード1）検証
- 正常データの検品パス（終了コード0）検証
- --fix 自動クレンジング後のラウンドトリップ再検証（終了コード0）
- 単一HTMLワークベンチの構造・オフライン完結性検証
"""
from __future__ import annotations

import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

BASE_DIR = Path(__file__).resolve().parent
CLI_PATH = BASE_DIR / "log_error_digest_cli.py"
WEB_PATH = BASE_DIR / "log_error_digest_workbench.html"
PROBLEM_CSV = BASE_DIR / "samples" / "problem_data.csv"
CLEAN_CSV = BASE_DIR / "samples" / "clean_data.csv"
KEY_COLUMN = "endpoint_id"


class TestVendingToolPack(unittest.TestCase):
    def test_01_files_exist(self) -> None:
        self.assertTrue(CLI_PATH.is_file(), f"Missing CLI: {CLI_PATH}")
        self.assertTrue(WEB_PATH.is_file(), f"Missing Web HTML: {WEB_PATH}")
        self.assertTrue(PROBLEM_CSV.is_file(), f"Missing problem sample: {PROBLEM_CSV}")
        self.assertTrue(CLEAN_CSV.is_file(), f"Missing clean sample: {CLEAN_CSV}")

    def test_02_problem_csv_detected_as_error(self) -> None:
        proc = subprocess.run(
            [sys.executable, "-B", str(CLI_PATH), str(PROBLEM_CSV), "--key", KEY_COLUMN],
            capture_output=True,
            text=True,
            check=False,
        )
        self.assertEqual(proc.returncode, 1, f"Expected exit code 1 on problem CSV, got {proc.returncode}")
        payload = json.loads(proc.stdout)
        self.assertFalse(payload["ok"])
        self.assertGreater(payload["error_count"], 0)
        self.assertGreater(payload["warning_count"], 0)

    def test_03_clean_csv_passes_with_zero_errors(self) -> None:
        proc = subprocess.run(
            [sys.executable, "-B", str(CLI_PATH), str(CLEAN_CSV), "--key", KEY_COLUMN],
            capture_output=True,
            text=True,
            check=False,
        )
        self.assertEqual(proc.returncode, 0, f"Expected exit code 0 on clean CSV, got {proc.returncode}: {proc.stdout}")
        payload = json.loads(proc.stdout)
        self.assertTrue(payload["ok"])
        self.assertEqual(payload["error_count"], 0)
        self.assertEqual(payload["warning_count"], 0)

    def test_04_fix_mode_roundtrip_produces_clean_csv(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            fixed_csv = Path(tmp) / "fixed.csv"
            report_json = Path(tmp) / "report.json"
            proc_fix = subprocess.run(
                [
                    sys.executable, "-B", str(CLI_PATH), str(PROBLEM_CSV),
                    "--key", KEY_COLUMN, "--fix",
                    "--output-csv", str(fixed_csv),
                    "--output-json", str(report_json),
                ],
                capture_output=True,
                text=True,
                check=False,
            )
            self.assertEqual(proc_fix.returncode, 0)
            self.assertTrue(fixed_csv.is_file())
            self.assertTrue(report_json.is_file())

            # Re-verify the fixed CSV in strict read-only mode
            proc_recheck = subprocess.run(
                [sys.executable, "-B", str(CLI_PATH), str(fixed_csv), "--key", KEY_COLUMN],
                capture_output=True,
                text=True,
                check=False,
            )
            self.assertEqual(proc_recheck.returncode, 0, f"Fixed CSV failed recheck: {proc_recheck.stdout}")
            recheck_data = json.loads(proc_recheck.stdout)
            self.assertTrue(recheck_data["ok"])
            self.assertEqual(recheck_data["error_count"], 0)
            self.assertEqual(recheck_data["warning_count"], 0)

    def test_05_single_html_workbench_integrity(self) -> None:
        html_text = WEB_PATH.read_text(encoding="utf-8")
        self.assertIn("<!DOCTYPE html>", html_text)
        self.assertIn("btnRunInspect", html_text)
        self.assertIn("btnDownloadCsv", html_text)
        self.assertIn("SAMPLE_PROBLEM_CSV", html_text)
        self.assertNotIn("https://cdn.", html_text.lower())


if __name__ == "__main__":
    unittest.main(verbosity=2)
