# E-Commerce SKU Landed Cost, Tariff & Contribution Margin Calculator

**Multi-Channel Profit Simulator, Bulk CSV CLI & Inventory Pricing Guide**

- **Suggested Price**: USD 19
- **Focus**: Protecting SKU-level contribution margins across Amazon FBA, Shopify, and wholesale channels under fluctuating freight and tariff rates.
- **Included**:
  1. `en-pkg-05-ecommerce-landed-cost-margin_workbench.html` — 100% Offline Browser Workbench (zero external requests)
  2. `en_pkg_05_ecommerce_landed_cost_margin_cli.py` — Zero-Dependency Python 3 CLI Auditor
  3. `en-pkg-05-ecommerce-landed-cost-margin-kdp-en-v1.epub` — Full Practical Engineering Handbook (EPUB3)
  4. `samples/` & `test_en_package.py` — Sample datasets and automated verification suite
