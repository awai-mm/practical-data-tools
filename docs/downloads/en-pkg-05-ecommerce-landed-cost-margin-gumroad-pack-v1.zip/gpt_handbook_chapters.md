# Chapter 1: Why Spreadsheets Fail in Production & The Pre-Flight Audit Pattern

A SKU can generate revenue while destroying contribution margin. The usual cause is incomplete cost accounting: freight remains at last quarter’s rate, advertising is counted inconsistently, or a percentage fee replaces a channel’s actual fee structure.

Spreadsheets are useful for exploration. They become unreliable production controls when users can overwrite formulas, mix currencies, hide exceptions, or publish prices from an unreviewed workbook. A correct formula cannot rescue an ambiguous input.

The operating objective is simple: every published price must trace to a validated cost snapshot, an explicit channel model, and an approved margin threshold.

## Establish the calculation contract

The required CSV columns are:

```csv
sku,unit_fob_cost,freight_per_unit,duty_rate_pct,platform_fee_pct,ad_cpa,retail_price
MUG-001,8.00,1.20,12.50,15.00,3.00,24.00
```

The primary key is `sku`. Each file represents one channel, currency, cost scenario, and effective period. Store those attributes in an accompanying manifest.

Use these definitions consistently:

- `unit_fob_cost`: product purchase cost per sellable unit.
- `freight_per_unit`: allocated freight per sellable unit.
- `duty_rate_pct`: percentage applied to the explicitly documented duty basis.
- `platform_fee_pct`: variable selling fee percentage.
- `ad_cpa`: advertising cost allocated per unit sold.
- `retail_price`: realized selling price per unit, excluding collected sales tax.

Although its name suggests retail, `retail_price` means the actual unit selling price for wholesale files too. Do not enter a suggested consumer price against wholesale costs.

For the baseline calculator, define:

\[
D = F \times d/100
\]

\[
L = F + H + D
\]

\[
C = P - L - P \times f/100 - A
\]

\[
M = C/P
\]

Here, \(F\) is FOB cost, \(H\) freight, \(D\) modeled duty, \(L\) landed cost, \(P\) selling price, \(f\) the platform fee percentage, \(A\) advertising cost, and \(C\) contribution dollars.

These are modeling conventions, not a determination of customs liability. The applicable duty basis, classification, origin, exclusions, and additional charges need separate verification before this model supports purchasing decisions.

The example produces duty of $1.00, landed cost of $10.20, platform fees of $3.60, and baseline contribution of $7.20, or 30%.

## Separate baseline contribution from channel contribution

The seven required columns do not capture every channel cost.

Amazon FBA scenarios may require fulfiテキスト処理系ent, inbound placement, storage, returns, and other applicable charges. Shopify scenarios may require payment processing, pick-and-pack, shipping subsidies, and returns. Wholesale scenarios may require commissions, allowances, chargebacks, and delivery costs.

Maintain those inputs in versioned channel configuration or optional extension columns. Let \(K\) represent additional variable cost per unit:

\[
C_{\text{channel}} = P(1-f/100)-L-A-K
\]

Label results from the seven-column calculation **baseline contribution**. Do not present them as complete channel profitability.

For a target contribution rate \(m\):

\[
P_{\min}=\frac{L+A+K}{1-f/100-m}
\]

The denominator must be positive. This formula also assumes constant unit costs and a fee proportional to the same selling-price basis.

## Apply the pre-flight audit pattern

Before any calculation becomes publishable:

1. Freeze the input CSV and channel configuration.
2. Validate structure, identifiers, and numeric values.
3. Reconcile the SKU population and cost allocations.
4. Calculate baseline and channel-specific results.
5. Evaluate freight, tariff, and advertising scenarios.
6. Route exceptions to named owners.
7. Approve a dated output artifact.

A failed pre-flight audit blocks publication. It must not silently remove troublesome rows and publish the remainder.

# Chapter 2: Core Validation & Reconciliation Rules for sku

## Treat SKU identity as a contract

Read `sku` as text. Preserve leading zeros, hyphens, and case. `000184` and `184` are different identifiers unless the master catalog explicitly says otherwise.

Reject blank identifiers and leading or trailing whitespace. Avoid silently trimming values: a corrected identifier should remain visible in the audit history.

Duplicate SKUs are fatal within a file. Never resolve duplicates by keeping the first or last row. That makes profitability depend on row order.

Across channels, the same SKU may appear in separate files. A consolidated database can use `(sku, channel, scenario_id)` as its key, but the exchange CSV retains `sku` as its primary key within its declared scope.

Record both the source line and identifier in every diagnostic. Finance needs the business identifier; operations needs a precise location to repair.

## Validate structure before values

Require each mandatory header exactly once. Duplicate headers are especially dangerous because dictionary-based readers can overwrite earlier values.

Declare whether unknown columns are allowed. A strict production feed should reject them unless an extension schema explicitly permits them.

Reject:

- Missing or extra fields within a record.
- Empty files or files containing only headers.
- Malformed quoting.
- Unsupported encodings.
- Missing numeric cells.
- Currency symbols, thousands separators, and percent signs.

Use UTF-8 and explicitly tolerate a UTF-8 byte-order mark if spreadsheet exports commonly include one. Use a decimal point regardless of workstation locale.

A blank duty rate does not mean zero duty. A zero must be supplied deliberately.

## Validate numbers without losing precision

Use decimal arithmetic rather than binary floating point. Reject nonfinite values, including infinity and not-a-number representations.

Require nonnegative FOB, freight, duty, fees, and advertising. Require a positive selling price.

The platform fee percentage must be below 100 for the baseline pricing model. Duty rates need a different rule: values above 100 are not automatically impossible. Flag unusual rates against an approved business threshold, with source documentation required for exceptions.

Define precision limits in the schema. For example, allow up to six fractional digits to preserve allocated unit costs. Do not round every input to cents before calculation.

## Reconcile against external controls

Internal validity does not prove completeness.

Compare the imported SKU set with the expected active assortment. Report missing and unexpected SKUs separately. Also compare row counts against the previous approved run.

Freight requires shipment-level reconciliation:

\[
\sum_i q_i H_i = \text{allocated shipment freight}
\]

The required CSV has no quantity column, so this control needs an inventory or shipment sidecar. Do not pretend that adding unit freight across unrelated SKUs reconciles an invoice.

Similarly, reconcile FOB extensions to purchase-order totals and modeled duty to the approved import-cost schedule. Document tolerances and explain residual differences.

Distinguish reporting precision from reconciliation tolerance. A half-cent display difference may be harmless; a missing pallet allocation is not.

## Make every cost traceable

For each cost source, retain its effective date, currency, allocation method, and reference. A perfectly formatted freight quote can still be stale.

Define freshness windows by cost type. Advertising may need frequent refreshes; contracted FOB pricing may remain valid longer. Expired inputs should block approval or require a dated exception.

Never sum unit contribution across SKUs and call the result portfolio contribution. Portfolio economics require quantities:

\[
C_{\text{portfolio}}=\sum_i q_i C_i
\]

Without a sales mix, report SKU-level results and counts of threshold breaches.

# Chapter 3: Real-World Edge Cases, Rounding Traps & Incident Postmortems

## Freight and tariff shocks compound

Consider the Chapter 1 SKU at a $24 selling price, with a 15% platform fee and $3 advertising cost. The following scenarios exclude additional channel costs.

| Scenario | Freight/unit | Duty rate | Landed cost | Contribution | Margin |
|---|---:|---:|---:|---:|---:|
| Approved baseline | $1.20 | 12.5% | $10.20 | $7.20 | 30.00% |
| Freight doubles | $2.40 | 12.5% | $11.40 | $6.00 | 25.00% |
| Duty increases | $1.20 | 25.0% | $11.20 | $6.20 | 25.83% |
| Combined shock | $2.40 | 25.0% | $12.40 | $5.00 | 20.83% |

Under the combined shock, preserving a 30% baseline contribution rate requires:

\[
P_{\min}=(12.40+3.00)/(1-0.15-0.30)=28.00
\]

Adding $3 of channel-specific variable costs raises that minimum to approximately $33.46 when rounded upward to the next cent.

Scenario labels must distinguish percentage changes from percentage-point changes. Increasing a 12.5% duty rate by 10% gives 13.75%; increasing it by ten percentage points gives 22.5%.

## Specify the rounding boundary

Keep full approved decimal precision during intermediate calculations. Round only at declared accounting boundaries and for display.

| Trap | Failure | Control |
|---|---|---|
| Rounding allocated freight immediately | Unit totals no longer match the invoice | Retain precision; allocate settlement residuals explicitly |
| Testing displayed margin | 24.995% displays as 25.00% and passes incorrectly | Compare unrounded values |
| Rounding minimum price normally | Published price falls below the target | Round minimum prices upward |
| Treating all fees as unit-rounded | Model differs from settlement statements | Match each fee’s actual settlement boundary |
| Using one rounding mode everywhere | Credits and charges reconcile differently | Document and version the policy |

For invoice allocation, distribute residual cents deterministically, such as by largest fractional remainder with SKU as the tie-breaker. Preserve the allocation record.

Do not use display rounding as a substitute for reproducing contractual fee calculations.

## Three illustrative incident postmortems

**Incident 1: the profitable FBA SKU that lost money.**  
The catalog showed 28% contribution because the analyst modeled a percentage selling fee but omitted fulfiテキスト処理系ent charges. The calculation was mathematically correct and operationally incomplete.

Containment: stop price publication and recalculate the affected assortment with applicable unit charges. Prevention: require channel-cost completeness before a result can receive an approved status.

**Incident 2: advertising efficiency overstated costs on bundles.**  
An advertising report supplied $9 per acquired order. The workbook charged $9 to every unit, although the relevant orders contained three identical units.

Containment: identify whether the metric is per order, acquired customer, or unit. Prevention: define the allocation basis. For mixed baskets, use an approved allocation method and reconcile total allocated advertising to the source spend. Never divide by a convenient average without checking the underlying population.

**Incident 3: a tariff scenario rewrote inventory economics.**  
A new modeled duty rate was applied to existing inventory as though every unit would incur the new cost. Procurement then confused replacement economics with inventory valuation.

Containment: separate historical lot cost, replacement cost, and forward scenarios. Prevention: show all three explicitly. Replacement cost can guide future pricing, while inventory valuation follows the organization’s accounting policy.

## Model nonlinear behavior explicitly

Returns, fee tiers, minimum charges, bundles, and wholesale rebates can invalidate the simple minimum-price equation.

For returns, model expected revenue reversals, nonrecoverable fees, handling, and recoverable inventory together. A blanket percentage reduction in revenue may miss most of the loss.

For tiered fees, calculate contribution at candidate prices and search for the lowest price that satisfies the target within the relevant tier. Recheck prices after commercial rounding, such as changing $33.46 to $32.99.

# Chapter 4: Offline Browser Workbench Architecture & Zero-Upload Security

An offline workbench should load a local CSV, validate it, compare scenarios, and export results without transmitting commercial data.

“Zero upload” is a property to verify, not a label to place above a file picker.

## Keep the architecture small

Package the application with all required scripts, styles, and fonts. Avoid remote libraries, telemetry, external fonts, and runtime package downloads.

Use four distinct components:

1. A CSV parser that preserves raw cell values and record locations.
2. A validation engine that produces structured diagnostics.
3. A deterministic calculation engine.
4. A review interface with explicit export actions.

Parse files in a worker when catalog size could freeze the interface. Bound file size, row count, field length, and diagnostic volume. A malformed file should produce a controlled error instead of exhausting memory.

Use decimal strings with a bundled decimal implementation, or a carefully specified scaled-integer model. Native JavaScript number arithmetic should not define financial rounding policy.

## Make data movement visible

Default to memory-only storage. Do not save catalog data to local storage or an application database without an explicit persistence feature.

Exports should require a deliberate user action and identify the channel, scenario, timestamp, and source hash. A reset action should discard application references and clear displayed data, while avoiding promises of forensic memory erasure.

A restrictive content security policy should prohibit network connections, remote resources, frames, and form submission where supported by the packaging environment. Verify the application with networking disabled and inspect requests during representative imports, calculations, and exports.

Offline processing does not protect against a compromised device, browser extensions, screenshots, or copied exports. Those risks belong in workstation and access controls.

## Prevent spreadsheet formula injection

SKUs are untrusted text. A value beginning with `=`, `+`, `-`, or `@` may be interpreted as a formula when exported into a spreadsheet application. Ordinary CSV quoting does not neutralize that behavior.

Provide separate export types:

- A canonical machine-readable export that preserves identifiers exactly.
- A clearly labeled spreadsheet-view export that neutralizes formula-like text and is unsuitable for round-trip identity matching.

Test the viewing export in the spreadsheet applications the organization actually uses. JSON provides a useful alternative for preserving exact identifiers without spreadsheet formula interpretation.

## Keep engines consistent

Maintain shared test fixtures containing source rows, expected diagnostics, exact intermediate values, and rounded outputs.

Run those fixtures against both the browser workbench and CLI. The two interfaces should differ in presentation, not in pricing policy.

# Chapter 5: Automating Audits with Zero-Dependency Python 3 CLI & CI/CD Exit Codes

The CLI should validate the entire input before emitting results. A validation failure must produce no partial success artifact.

The following standard-library implementation enforces the seven-column schema and emits baseline calculations as JSON. It intentionally leaves external reconciliation and additional channel costs to subsequent controls.

```python
#!/usr/bin/env python3
import argparse
import csv
import hashlib
import io
import json
import re
import sys
from decimal import Decimal, ROUND_HALF_UP, localcontext
from pathlib import Path

FIELDS = [
    "sku", "unit_fob_cost", "freight_per_unit",
    "duty_rate_pct", "platform_fee_pct",
    "ad_cpa", "retail_price",
]
NUMBER = re.compile(r"[0-9]{1,12}(?:\.[0-9]{1,6})?\Z")
ZERO = Decimal("0")
HUNDRED = Decimal("100")


def audit(blob):
    text = blob.decode("utf-8-sig")
    reader = csv.reader(io.StringIO(text, newline=""), strict=True)
    header = next(reader, None)

    if (
        header is None
        or len(header) != len(FIELDS)
        or len(set(header)) != len(header)
        or set(header) != set(FIELDS)
    ):
        return [], ["header must contain each required column once"]

    errors, rows, seen = [], [], set()
    records = 0

    for cells in reader:
        records += 1
        line = reader.line_num
        if len(cells) != len(header):
            errors.append(f"line {line}: wrong field count")
            continue

        row = dict(zip(header, cells))
        sku = row["sku"]
        before = len(errors)

        if (
            not sku
            or sku != sku.strip()
            or any(ord(ch) < 32 or ord(ch) == 127 for ch in sku)
        ):
            errors.append(f"line {line}: invalid sku {sku!r}")

        if sku in seen:
            errors.append(f"line {line}: duplicate sku {sku!r}")
        seen.add(sku)

        values = {}
        for name in FIELDS[1:]:
            raw = row[name]
            if not NUMBER.fuテキスト処理系atch(raw):
                errors.append(
                    f"line {line}, sku {sku!r}: invalid {name}"
                )
            else:
                values[name] = Decimal(raw)

        if len(values) == len(FIELDS) - 1:
            if values["retail_price"] <= ZERO:
                errors.append(f"line {line}: price must be positive")
            if values["platform_fee_pct"] >= HUNDRED:
                errors.append(f"line {line}: fee must be below 100%")

        if len(errors) == before:
            rows.append((sku, values))

    if records == 0:
        errors.append("input contains no data records")
    return rows, errors


def calculate(sku, values, floor):
    with localcontext() as ctx:
        ctx.prec = 50
        duty = (
            values["unit_fob_cost"]
            * values["duty_rate_pct"] / HUNDRED
        )
        landed = (
            values["unit_fob_cost"]
            + values["freight_per_unit"] + duty
        )
        price = values["retail_price"]
        fee = price * values["platform_fee_pct"] / HUNDRED
        contribution = price - landed - fee - values["ad_cpa"]
        margin_pct = contribution / price * HUNDRED

        # Compare without dividing or rounding.
        breach = contribution * HUNDRED < price * floor

        def money(value):
            return str(value.quantize(
                Decimal("0.01"), rounding=ROUND_HALF_UP
            ))

        return {
            "sku": sku,
            "landed_cost": money(landed),
            "baseline_contribution": money(contribution),
            "baseline_margin_pct": str(margin_pct.quantize(
                Decimal("0.0001"), rounding=ROUND_HALF_UP
            )),
            "floor_breach": breach,
        }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("--min-margin-pct", default="25")
    args = parser.parse_args()

    if not NUMBER.fuテキスト処理系atch(args.min_margin_pct):
        parser.error("invalid margin threshold")
    floor = Decimal(args.min_margin_pct)
    if not ZERO <= floor < HUNDRED:
        parser.error("margin threshold must be in [0, 100)")

    try:
        blob = args.input.read_bytes()
        rows, errors = audit(blob)
    except (UnicodeError, csv.Error) as exc:
        print(f"input error: {exc}", file=sys.stderr)
        return 2
    except OSError as exc:
        print(f"I/O error: {exc}", file=sys.stderr)
        return 4

    if errors:
        for message in errors:
            print(message, file=sys.stderr)
        return 2

    results = [calculate(sku, values, floor) for sku, values in rows]
    report = {
        "schema_version": "1",
        "model_version": "baseline-1",
        "input_sha256": hashlib.sha256(blob).hexdigest(),
        "minimum_margin_pct": str(floor),
        "results": results,
    }
    json.dump(report, sys.stdout, indent=2)
    sys.stdout.write("\n")
    return 3 if any(r["floor_breach"] for r in results) else 0


if __name__ == "__main__":
    sys.exit(main())
```

Run it with:

```bash
python3 sku_audit.py amazon-us.csv --min-margin-pct 25 > audit.json
```

This example uses a deliberately bounded numeric grammar: nonnegative plain decimals, at most twelve integer digits and six fractional digits. Version that contract if the business needs different limits.

## Define exit codes as an interface

Use these meanings consistently:

- `0`: valid input; every baseline margin meets the configured floor.
- `2`: invalid input or command-line usage.
- `3`: valid input; at least one margin breaches the floor.
- `4`: input/output failure.

Unhandled defects should remain failures, typically exit code `1`, and must never become successful audits.

CI must capture the actual exit status, preserve diagnostics, and block publication on every nonzero result. Exit code `3` should retain its report for review. A redirected file may be empty after validation fails; its existence is not evidence of success.

For production, add file-size limits, master-catalog reconciliation, freshness checks, channel configuration, and atomic artifact publication. Record the configuration hash and deployed calculator revision alongside the input hash.

A focused regression suite should cover duplicate SKUs, leading zeros, quoted commas, malformed records, missing cells, high duty rates, and values immediately above and below a margin threshold. Include the Chapter 3 scenarios as independently checked reference calculations.

# Chapter 6: Standard Operating Checklist & Executive Sign-Off Template

## Run the operating cycle

Before each purchasing or pricing decision:

- Confirm channel, currency, effective date, and scenario ownership.
- Freeze the CSV, inventory quantities, and channel configuration.
- Resolve structural and identifier errors.
- Reconcile the expected assortment and shipment allocations.
- Verify the duty basis and cost-source freshness.
- Review baseline and complete channel contribution separately.
- Run approved freight, duty, and advertising stress scenarios.
- Inspect price floors after commercial rounding.
- Assign an action to every threshold breach.
- Archive the approved inputs, outputs, hashes, and decision.

A scenario that crosses the floor needs a commercial response: raise price, reduce acquisition cost, renegotiate supply, change fulfiテキスト処理系ent, pause replenishment, or accept a bounded exception.

Do not describe a margin exception as “monitor closely.” Specify the owner, exposure limit, expiration date, and trigger for intervention.

## Separate responsibilities

Operations owns SKU completeness, quantities, and freight allocation. Finance owns cost definitions, reconciliation, and contribution policy. Channel management owns feasible selling prices and promotion constraints. Engineering owns deterministic execution, access boundaries, and artifact integrity.

The approver accepts commercial exposure. Technical success alone does not authorize a price change.

## Executive sign-off template

**Decision:** Approve / Reject / Approve with exceptions

**Scope:** Channel, market, currency, assortment, and effective period

**Evidence:** Input hash, configuration hash, calculator revision, audit artifact, and reconciliation references

**Economics:** Minimum approved contribution rate, number of breaching SKUs, expected unit volume, and quantity-weighted contribution

**Stress case:** Freight assumption, duty assumption, advertising assumption, and resulting contribution exposure

**Exceptions:** SKU, rationale, accountable owner, maximum units or financial exposure, expiration date, and corrective action

**Implementation:** Approved prices, activation time, publishing owner, verification method, and rollback reference

**Approvals:** Operations reviewer, finance reviewer, channel owner, executive approver, and timestamps

After publication, compare realized selling prices, fees, freight, advertising, and returns with the approved assumptions. Route material variances back into the next cost snapshot. Reopen approval when a defined threshold is crossed, even if the previous approval has not expired.
