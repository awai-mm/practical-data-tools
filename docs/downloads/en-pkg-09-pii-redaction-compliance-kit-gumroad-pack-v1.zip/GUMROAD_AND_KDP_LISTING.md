# Dataset PII Detection, Masking & Safe-Sharing Compliance Kit

**Offline Privacy Scrubber HTML App, Python CLI & Data Governance Guide**

- **Suggested Price**: USD 19
- **Focus**: Auditing and deterministically masking emails, phone numbers, IP addresses, and sensitive free-text tokens prior to analytics sharing.
- **Included**:
  1. `en-pkg-09-pii-redaction-compliance-kit_workbench.html` — 100% Offline Browser Workbench (zero external requests)
  2. `en_pkg_09_pii_redaction_compliance_kit_cli.py` — Zero-Dependency Python 3 CLI Auditor
  3. `en-pkg-09-pii-redaction-compliance-kit-kdp-en-v1.epub` — Full Practical Engineering Handbook (EPUB3)
  4. `samples/` & `test_en_package.py` — Sample datasets and automated verification suite
