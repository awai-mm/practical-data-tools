# Chapter 1: Why Spreadsheets Fail in Production & The Pre-Flight Audit Pattern

A privacy scrubber is a controlled release system. Its job is to establish what arrived, identify prohibited content, transform approved fields consistently, and prove that the released dataset satisfies a defined sharing policy.

The input contract for this kit is a CSV file with these required columns:

```text
record_id,full_name,email_addr,phone_raw,ip_address,notes_text,consent_flag
```

The primary key is `record_id`. Treat every column as text during ingestion. Numeric conversion, date inference, and spreadsheet formatting can silently change identifiers, telephone numbers, and consent values.

## Why spreadsheet workflows break

Spreadsheets encourage edits whose meaning depends on display settings and operator behavior. An identifier such as `0001842` becomes `1842`. A long identifier loses significant digits. A telephone number beginning with `+` is interpreted as a formula or number. Filters hide records that remain in an exported workbook.

Manual replacement also lacks reliable scope. Replacing an email column does not remove an address copied into `notes_text`. Hiding a column does not remove its contents. Workbook comments, secondary sheets, and cached data can survive an otherwise careful review.

The most serious failure is procedural: nobody can reproduce exactly which rules produced a shared file.

A production workflow replaces informal editing with a versioned contract, deterministic transformations, reconciliation, and an explicit release decision.

## The pre-flight audit pattern

Run the following stages before creating a shareable artifact:

1. **Identify the input.** Record its byte size, SHA-256 digest, arrival time, and authorized source.
2. **Validate the structure.** Check encoding, headers, duplicate headers, row widths, and configured size limits.
3. **Validate records.** Enforce primary-key rules, consent vocabulary, and field-specific acceptance rules.
4. **Detect exposure.** Inspect structured fields and free text for prohibited identifiers and configured sensitive tokens.
5. **Apply the release policy.** Exclude ineligible records and transform eligible records.
6. **Reconcile and verify.** Account for every input record, inspect the resulting schema, and scan the output.
7. **Approve release.** Bind authorization to the exact artifact digest.

An audit should produce aggregate findings without reproducing the sensitive material it discovered. Report “12 invalid telephone fields,” not twelve telephone numbers.

Separate blocking failures from advisory findings. A duplicate primary key blocks the batch. An absent optional telephone number may be advisory. An unrecognized consent value blocks the batch because eligibility cannot be determined safely.

## Establish the default sharing policy

For an external analytics release, use a conservative baseline:

- Replace `record_id` with a release-scoped pseudonym.
- Suppress `full_name`.
- Replace valid emails, telephone numbers, and IP addresses with deterministic tokens.
- Suppress `notes_text` unless an explicitly approved extraction policy exists.
- Exclude records without an affirmative sharing eligibility value.

Here, `consent_flag` is an operational eligibility input. It is not, by itself, evidence that every proposed use is authorized. The release owner must also approve the recipient, purpose, fields, retention period, and access restrictions.

Deterministic tokens preserve linkage. They do not establish anonymity. Repeated tokens can reveal activity patterns, and other attributes can still identify people.

# Chapter 2: Core Validation & Reconciliation Rules for record_id

## Define identity before transforming it

The primary key must be present, unique, and stable within the source contract. It is a string identifier, not a quantity.

A practical contract is:

```text
Allowed characters: ASCII letters, digits, underscore, hyphen
Length: 1–64 characters
Whitespace: prohibited
Comparison: case-sensitive
Numeric conversion: prohibited
```

Under this contract, `A001`, `a001`, and `001` are different identifiers.

Reject invalid identifiers rather than silently trimming or rewriting them. If an upstream system requires normalization, document that rule separately and test uniqueness after normalization. Otherwise, a repair such as removing spaces can collapse two records into the same key.

Check duplicate headers before loading rows into dictionaries. Two `record_id` columns can cause one value to overwrite another before validation begins.

Reject both kinds of duplicate:

- Identical records sharing a primary key.
- Different records sharing a primary key.

The first may reflect a repeated export; the second may reflect an upstream identity error. Neither should be resolved by retaining whichever row happens to appear last.

## Make deterministic masking explicit

Use keyed HMAC-SHA-256 for deterministic tokens:

```text
token = HMAC-SHA-256(secret_key, domain || separator || canonical_value)
```

A plain hash is insufficient. Email addresses and telephone numbers often come from guessable spaces, allowing an attacker to hash candidates and compare results.

Domain separation prevents identical strings in different fields from producing identical tokens. Include the policy version and sharing scope in the domain:

```text
partner_a:study_2026:policy_v1:email
```

Use a distinct scope when cross-release linkage is unnecessary. Keep the key outside the released dataset, manifests, source repository, and ordinary logs.

For modest datasets, 128-bit truncated tokens may be sufficient when collision checks are implemented. Full 256-bit tokens simplify the reference implementation. Cryptographic collisions remain theoretically possible; canonicalization collisions are a separate issue and often intentional.

## Canonicalize each field deliberately

Canonicalization determines which inputs become equivalent:

- **Email:** trim surrounding whitespace and lowercase the domain. Preserve local-part case unless the source contract explicitly permits folding it.
- **Telephone:** require a documented international form or a trusted country context. Do not guess a country from punctuation.
- **IP address:** parse with an IP library and serialize its canonical representation. Decide explicitly whether IPv4-mapped IPv6 addresses remain distinct.
- **Record identifier:** preserve the accepted source string exactly.

Do not remove email dots or plus-address suffixes globally. Those conventions are provider-specific and can merge different mailboxes.

Missing values require their own policy. An empty field may remain empty; it should not become the token for the literal string `"missing"`.

## Reconcile the release population

Track mutually exclusive row dispositions:

```text
input_records = eligible_records + excluded_records + quarantined_records
output_records = eligible_records
```

Count parsed CSV records, not physical lines: quoted notes can contain line breaks. If parsing fails, report the batch as structurally unreadable rather than inventing a complete row count.

For a strict batch policy, any quarantined record prevents publication. The audit can still report provisional counts.

Verify output primary-key uniqueness, then compare input and output key sets inside the trusted processing boundary. Counts alone cannot detect one missing record replaced by a duplicate.

Bind the release manifest to the input digest, output digest, policy version, key identifier, software version, and disposition counts. A key identifier names the secret; it must never contain the secret.

# Chapter 3: Real-World Edge Cases, Rounding Traps & Incident Postmortems

Privacy failures frequently arise from reasonable-looking shortcuts. A good test suite contains awkward records, not just clean demonstrations.

## Edge-case decision table

| Input condition | Hidden risk | Required treatment |
|---|---|---|
| `00001234567890123456` as a key | Numeric import removes zeros or precision | Preserve as text; reject numeric coercion |
| Mixed-case email domain | Equivalent domains receive different tokens | Lowercase the domain |
| Email with a plus suffix | Removing the suffix merges identities | Preserve unless explicitly authorized |
| `020 7946 0958` as a telephone number | Country cannot be inferred reliably | Reject or require trusted country context |
| Telephone extension in `phone_raw` | Extension disappears during cleanup | Reject under the baseline contract |
| Expanded IPv6 address | Equivalent spellings fragment linkage | Parse and canonicalize |
| `::ffff:192.0.2.8` | Mapping policy changes token equivalence | Document whether it stays distinct |
| Quoted notes containing newlines | Line counts disagree with record counts | Use a CSV parser |
| Zero-width characters in notes | Literal token matching misses content | Suppress notes or use reviewed normalization |
| Text beginning with `=` | Spreadsheet software may execute a formula | Suppress or neutralize under a defined export policy |

A syntactically valid telephone number is not proof that the number is assigned or belongs to the person. Likewise, accepting an email format does not verify mailbox ownership.

## Rounding traps are identity traps

Many spreadsheet applications use numeric representations that cannot preserve arbitrary long identifiers. Once digits have been rounded, exporting the cell as text does not recover them.

Suppose two distinct identifiers differ only near the end:

```text
9007199254740992
9007199254740993
```

A binary floating-point conversion can collapse their distinction. Masking afterward produces the same token because the damage occurred before the scrubber received the file.

The remedy is to regenerate the export from the source system with text-preserving serialization. Never reconstruct lost digits from neighboring records or visual patterns.

Rounding also affects audit reporting. If three of seven records are excluded, a displayed percentage may be `42.9%`. Reconciliation must use the exact integer counts, not percentages rounded for presentation.

## Sensitive free-text tokens

Free text can contain credentials, account references, names, internal URLs, and identifiers copied from unrelated systems.

A token list should define matching semantics: case sensitivity, Unicode normalization, word boundaries, and overlapping matches. Naive replacement of `Ann` can damage `Annual`; boundary matching can miss joined or deliberately altered text.

Detection is therefore evidence of exposure, not proof of completeness. The baseline policy suppresses notes entirely. A richer policy should extract approved attributes into typed fields, then discard the original text.

## Illustrative incident postmortems

| Incident | Root cause | Corrective control |
|---|---|---|
| Masked email column, raw address in notes | Field-level replacement treated as complete sanitization | Suppress notes and scan the final artifact |
| Matching tokens across unrelated recipients | One global key and domain reused everywhere | Scope tokens to recipient and approved purpose |
| Incorrect person-to-record linkage | Identifier rounding before ingestion | Reject altered exports; regenerate from source |
| Rejected upload contained sample values in logs | Error messages copied raw records | Log rule codes and counts only |

Each postmortem should identify the exposure path, affected artifacts, recipients, containment action, and regression fixture.

Deleting the original download link does not establish that downloaded copies were removed. Incident closure requires evidence appropriate to the actual distribution path.

# Chapter 4: Offline Browser Workbench Architecture & Zero-Upload Security

## Build the workbench around a local trust boundary

The browser application should be a self-contained HTML package with bundled styles, scripts, and any necessary parser. No remote fonts, analytics, external libraries, or runtime update checks should be required.

The workflow is straightforward:

1. Select a local CSV file.
2. Inspect structural findings and aggregate exposure counts.
3. Select an approved policy and enter the release key.
4. Review eligibility and reconciliation results.
5. Download the verified output and manifest.

Use browser file APIs to read selected files. Perform transformations locally, preferably in a worker so large inputs do not freeze the interface. Generate downloads from local blobs and revoke their object URLs afterward.

Use a real CSV parser. Splitting on commas breaks quoted values, escaped quotes, and embedded newlines. Share parser fixtures with the command-line implementation.

## Make “zero upload” verifiable

Zero upload is a property of the application’s implementation and deployment, not a promise that follows automatically from opening an HTML file.

Ship an enforced Content Security Policy that prohibits network connections and unnecessary resource loading. Avoid inline event handlers, dynamic code evaluation, and remote dependencies. Package scripts so the policy can authorize them through tested hashes or an appropriate deployment mechanism.

The application must not use fetch requests, WebSockets, beacons, form submissions, or navigation to transmit dataset content. Do not register a service worker. Do not persist records in local storage, IndexedDB, or caches.

Verify this behavior through source inspection and runtime network monitoring while disconnected from the network. Offline operation should pass the same acceptance fixtures as connected operation.

Browser extensions, endpoint monitoring, backups, and operating-system behavior remain outside the page’s control. Run sensitive workloads in an approved browser profile on a managed device.

## Prevent disclosure through the interface

Default previews should display masked values. Raw previews, if operationally necessary, should require deliberate reveal and should never persist between files.

Insert dataset values using text-only DOM APIs. Never interpret notes as HTML. Avoid copying raw values into exception messages, developer-console output, or downloadable diagnostics.

A manifest should contain counts and digests, not record samples. Input filenames may themselves contain personal information; omit them unless needed.

Set maximum file size, record count, field length, and processing time. A malformed CSV can exhaust memory without containing any executable content.

## Manage keys and reproducibility

Use browser cryptographic APIs for HMAC. Do not substitute a homemade hash or a human password.

Keys should arrive through an approved local mechanism and remain in memory only. JavaScript cannot guarantee secure erasure of every memory copy, so describe clearing the interface as session cleanup rather than cryptographic destruction.

Keep a versioned fixture pack with expected tokens, Unicode cases, quoted multiline records, and rejection cases. Browser and Python outputs should agree on field values, column order, encoding, and line endings.

Reproducibility makes the workbench reviewable: identical input bytes, policy, and key should produce identical output bytes.

# Chapter 5: Automating Audits with Zero-Dependency Python 3 CLI & CI/CD Exit Codes

Python’s standard library provides CSV parsing, HMAC, IP validation, hashing, argument parsing, and JSON reporting.

Keep the command-line interface narrow:

```text
python3 scrub.py audit input.csv --policy policy.json
python3 scrub.py release input.csv --policy policy.json --out release.csv
```

Read the key from an approved secret mechanism. Never accept it directly as a command-line argument, where it may appear in process listings or shell history.

## Reference transformation core

The following core intentionally supports a restricted ASCII email format and an international telephone format without extensions. Unsupported values require review rather than speculative repair.

```python
import csv
import hashlib
import hmac
import ipaddress
import re

COLUMNS = [
    "record_id", "full_name", "email_addr", "phone_raw",
    "ip_address", "notes_text", "consent_flag",
]

ID = re.compile(r"[A-Za-z0-9_-]{1,64}")
PHONE = re.compile(r"\+[1-9][0-9]{1,14}")
LOCAL = re.compile(r"[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+")
LABEL = re.compile(r"[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?")

def email_value(raw):
    value = raw.strip()
    if not value:
        return ""
    if len(value) > 254 or value.count("@") != 1:
        raise ValueError("EMAIL_FORMAT")
    local, domain = value.split("@")
    labels = domain.split(".")
    if (
        not LOCAL.fuテキスト処理系atch(local)
        or len(local) > 64
        or local.startswith(".")
        or local.endswith(".")
        or ".." in local
        or len(domain) > 253
        or len(labels) < 2
        or any(not LABEL.fuテキスト処理系atch(label) for label in labels)
    ):
        raise ValueError("EMAIL_FORMAT")
    return local + "@" + domain.lower()

def phone_value(raw):
    value = raw.strip()
    if not value:
        return ""
    if not re.fuテキスト処理系atch(r"[+0-9 ().-]+", value):
        raise ValueError("PHONE_FORMAT")
    value = re.sub(r"[ ().-]", "", value)
    if not PHONE.fuテキスト処理系atch(value):
        raise ValueError("PHONE_FORMAT")
    return value

def ip_value(raw):
    value = raw.strip()
    if not value:
        return ""
    if "%" in value:
        raise ValueError("IP_SCOPE_UNSUPPORTED")
    try:
        return str(ipaddress.ip_address(value))
    except ValueError:
        raise ValueError("IP_FORMAT") from None

def token(key, scope, field, value):
    if not value:
        return ""
    domain = f"{scope}:policy_v1:{field}".encode("utf-8")
    message = domain + b"\x00" + value.encode("utf-8")
    digest = hmac.new(key, message, hashlib.sha256).hexdigest()
    return field + "_" + digest

def transform(row, key, scope):
    # Validate structured fields even on excluded rows.
    email = email_value(row["email_addr"])
    phone = phone_value(row["phone_raw"])
    address = ip_value(row["ip_address"])
    if row["consent_flag"] == "false":
        return None
    return {
        "record_id": token(key, scope, "record_id", row["record_id"]),
        "full_name": "",
        "email_addr": token(key, scope, "email", email),
        "phone_raw": token(key, scope, "phone", phone),
        "ip_address": token(key, scope, "ip", address),
        "notes_text": "",
        "consent_flag": "true",
    }

def checked_rows(stream):
    reader = csv.reader(stream, strict=True)
    if next(reader, None) != COLUMNS:
        raise ValueError("HEADER_CONTRACT")
    seen = set()
    for values in reader:
        if len(values) != len(COLUMNS):
            raise ValueError("ROW_WIDTH")
        row = dict(zip(COLUMNS, values))
        identifier = row["record_id"]
        if not ID.fuテキスト処理系atch(identifier):
            raise ValueError("RECORD_ID_FORMAT")
        if identifier in seen:
            raise ValueError("RECORD_ID_DUPLICATE")
        seen.add(identifier)
        if row["consent_flag"] not in {"true", "false"}:
            raise ValueError("CONSENT_VALUE")
        yield row
```

Open input with `encoding="utf-8-sig"` and `newline=""`. Write output with UTF-8, `newline=""`, and an explicit CSV line terminator. Require a randomly generated key of at least 32 bytes and a validated, versioned scope.

This is a transformation core, not a complete release program. The wrapper must implement resource limits, exposure reporting, reconciliation, output validation, and publication controls. The in-memory uniqueness set also imposes a dataset-size limit; larger workloads can use the standard-library `sqlite3` module with protected temporary storage.

## Publish only complete artifacts

Write to a private staging directory on the destination filesystem. If any later row fails, remove the staged output and return a blocking status.

After processing, reopen the staged file and verify its schema, token formats, unique primary keys, empty suppressed fields, eligible row count, and digest. Then create the manifest and publish the bundle through a controlled rename or release-pointer update.

Use a fresh release directory so a failed job cannot leave an older output looking like today’s successful run.

## Define stable exit codes

| Code | Meaning | Pipeline action |
|---|---|---|
| `0` | Audit or release completed successfully | Continue to approval gate |
| `2` | Invalid arguments or policy configuration | Fix invocation |
| `3` | Structural or record validation failed | Block release |
| `4` | Reconciliation or output verification failed | Block release and investigate |
| `5` | Input/output, secret-loading, or runtime failure | Block release; retain safe diagnostics |

Successful execution does not authorize distribution. CI should attach the manifest and artifact digest to a separate approval gate.

Test multiline CSV, duplicate keys, malformed encoding, unsupported telephone formats, equivalent IP spellings, scope separation, late-row failures, and deterministic output. Use synthetic fixtures only.

# Chapter 6: Standard Operating Checklist & Executive Sign-Off Template

## Operator checklist

Before processing:

- Confirm source ownership, intended recipient, purpose, and approved fields.
- Obtain a text-preserving export from the source system.
- Confirm policy version, sharing scope, key identifier, and tool version.
- Verify the processing environment and output location.

During processing:

- Record the input digest.
- Run structural, identity, eligibility, and exposure checks.
- Resolve every blocking finding through an accountable source correction.
- Generate output only through the approved transformation path.

Before release:

- Reconcile all row dispositions.
- Verify output primary-key uniqueness.
- Confirm names and notes are suppressed under the baseline policy.
- Confirm tokens use the intended sharing scope.
- Verify the output digest and manifest.
- Obtain approval for the exact artifact and recipient.

After release:

- Record delivery time, recipient, and access mechanism.
- Apply the agreed retention and deletion schedule.
- Remove temporary files according to the environment’s storage policy.
- Preserve minimal audit evidence with restricted access.

A corrected source file is a new input. Recompute its digest and rerun the entire pipeline. Do not manually patch the released CSV and reuse the old manifest.

## Executive sign-off template

```text
RELEASE AUTHORIZATION

Release identifier:
Business purpose:
Data owner:
Recipient and approved access group:
Approved retention period:
Approved distribution mechanism:

Input SHA-256:
Output SHA-256:
Manifest SHA-256:

Policy version:
Tool version:
Sharing scope:
Key identifier:

Parsed input records:
Eligible records:
Excluded records:
Quarantined records:
Released records:

Blocking findings: 0
Reconciliation result:
Output verification result:
Approved exceptions and supporting references:

Residual linkage risk:
Reason each retained field is necessary:
Recipient restrictions:
Incident contact:
Deletion or access-expiry date:

Data owner approval:
Privacy/security reviewer approval:
Release operator:
Approval timestamp:
```

The approver should understand what the recipient can link, what information remains, and why the retained fields are necessary.

Any exception that permits names, free text, broader linkage, or additional recipients changes the release policy. Assign a new policy version and rerun verification.

Approval belongs to a specific artifact digest. If the bytes change, the approval no longer covers the resulting file.
