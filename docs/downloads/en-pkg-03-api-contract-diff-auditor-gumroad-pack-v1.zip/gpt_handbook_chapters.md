# Chapter 1: Why Spreadsheets Fail in Production & The Pre-Flight Audit Pattern

A production API can return valid JSON, pass a connectivity check, and still break every important consumer. An identifier becomes a number. A previously present property disappears. A payment status acquires an undocumented value. An amount changes from decimal text to a floating-point number.

These failures are dangerous because transport health remains green. HTTP success does not establish contract compatibility.

Spreadsheets help teams collect examples and discuss field definitions. They fail as production control systems when cell formatting substitutes for types, blank cells substitute for missing-value semantics, and manual review substitutes for repeatable validation. A spreadsheet may remove leading zeros from identifiers, display a rounded amount, or interpret a date-like string as a date. The reviewer sees a plausible value while the original evidence has changed.

The solution is a pre-flight audit: a deterministic inspection of proposed contracts and representative payloads before deployment.

## Establish three independent inputs

A useful audit separates:

1. **Approved baseline:** the contract consumers currently rely on.
2. **Candidate contract:** the proposed replacement, including required fields, permitted values, and response variants.
3. **Observed evidence:** payloads collected from controlled tests or approved, sanitized fixtures.

Comparing observations only against the candidate contract is insufficient. A breaking change can be internally consistent: the producer changes a field from string to integer, updates its schema, and passes its own tests. Baseline-to-candidate comparison reveals the compatibility failure.

Observations serve a different purpose. They reveal whether the implementation follows its declared contract. Both comparisons must pass.

## Define the audit boundary

Identify the API version, producer revision, consumer profiles, methods, status codes, and media types under review. Include error responses. An endpoint that correctly returns a success object but changes its authorization-error structure can still break client behavior.

State the direction of each contract:

- **Request:** what the server accepts from callers.
- **Response:** what the server emits to callers.

Compatibility is directional. Permitting more request values generally preserves existing callers. Emitting more response values can break existing consumers.

Run the audit before release packaging and again against the exact candidate artifact when feasible. Pin fixtures and policy files to that artifact; otherwise, successful evidence may describe a different build.

## Produce an actionable result

Every finding should identify the endpoint, operation, response variant, field location, rule, expected constraint, observed condition, and evidence reference.

Separate three outcomes:

- **Pass:** all configured checks completed successfully.
- **Contract failure:** valid inputs exposed a violation.
- **Audit failure:** evidence or configuration could not be evaluated reliably.

An unreadable fixture must never become a clean report.

Finally, distinguish assurance from coverage. Passing twelve fixtures means twelve fixtures passed. It does not prove that every possible response is compatible. The report must disclose untested variants and unsupported schema features.

# Chapter 2: Core Validation & Reconciliation Rules for endpoint_id

The required CSV header is:

```csv
endpoint_id,method,field_path,expected_type,nullable,observed_sample,status_code
```

The declared primary key is `endpoint_id`. Enforce that declaration literally: within a CSV file, every `endpoint_id` must be nonempty and unique.

## Resolve the endpoint-to-field cardinality problem

An endpoint normally has many fields, yet this format permits only one row per endpoint. Repeating an endpoint for each field violates the primary key.

Use this format as a **single-assertion projection**. Each file contains at most one selected field assertion for each endpoint. A manifest groups multiple projection files into a complete audit bundle. An endpoint can therefore appear in several files, but never twice within one file.

The manifest must define the expected assertions and coverage. Missing files or missing assertions are audit failures, not evidence that a field was removed.

Keep a separate endpoint registry containing canonical identity and method. For this handbook, an `endpoint_id` identifies one versioned operation, such as `payments.create.v1`; it is not a URL containing a customer identifier.

For large inventories, a future relational format can use a child assertion table with a composite key. That is an explicit format migration. Do not silently reinterpret the primary key of existing files.

## Specify every column

**`endpoint_id`** is a stable, case-sensitive identifier. Reject surrounding whitespace rather than silently trimming it. Renaming an identifier requires an explicit mapping; otherwise, reconciliation reports a removal and an addition.

**`method`** is an uppercase HTTP method consistent with the endpoint registry. Do not infer it from a path or display name.

**`field_path`** uses JSON Pointer syntax. `/customer/name` identifies a nested property; `/items/0/sku` identifies one array element. The empty pointer identifies the entire document. Escape `/` as `~1` and `~` as `~0`.

A concrete array index proves nothing about other elements. Array-wide validation requires a schema assertion applied to every element.

**`expected_type`** uses an explicit vocabulary: `string`, `integer`, `number`, `boolean`, `object`, or `array`. The simple CSV format cannot express unions, precision limits, string patterns, or object closure. Store those constraints in a versioned companion policy.

**`nullable`** is exactly `true` or `false`. It describes whether a present value may be JSON `null`. It does not describe whether the field may be omitted.

**`observed_sample`** contains JSON text representing the extracted field value. A blank cell means the field was absent; the JSON text `null` means it was present with a null value; `""` represents an empty string.

For example:

```csv
endpoint_id,method,field_path,expected_type,nullable,observed_sample,status_code
payments.create.v1,POST,/payment_id,string,false,"""000742""",201
```

**`status_code`** records the actual HTTP status of the source response. The manifest identifies the expected response variant. Validate both; a recorded `200` must not automatically authorize a response expected to be `201`.

## Reconcile before validating values

First validate file structure, column names, row widths, primary-key uniqueness, and manifest membership. Then reconcile endpoint inventories against the approved baseline.

Investigate:

- Removed operations without an approved retirement.
- Changed methods under an existing identifier.
- Missing required response variants.
- Renamed or deleted field assertions.
- Unexplained changes in policy or fixture provenance.

Next compare contract semantics. For responses, removing a required property, allowing null where consumers previously received a non-null value, or expanding an enum may be incompatible. For requests, adding a required property, disallowing previously accepted nulls, or narrowing an enum may be incompatible.

Type changes require directional reasoning. Integer values belong to the JSON Schema number domain, but widening a response from integer to arbitrary number permits fractions that consumers may reject.

Additional response properties are compatible only where consumer policies permit them. Strict decoders can reject otherwise harmless additions.

## Validate absence, null, and enums separately

Requiredness belongs in companion policy. A field can be required and nullable, or optional and non-nullable.

Enum checks must preserve JSON types. The string `"1"`, the number `1`, and the boolean `true` are different values. Avoid language equality rules that treat booleans as integers.

Validate enum membership after type validation. Do not lowercase, trim, or substitute values unless the contract explicitly defines that transformation.

# Chapter 3: Real-World Edge Cases, Rounding Traps & Incident Postmortems

The most expensive failures often begin with values that look equivalent to a human.

| Condition | Superficial interpretation | Required audit treatment |
|---|---|---|
| Property omitted | “No value” | Check requiredness |
| Property present as `null` | “No value” | Check nullability and enum |
| String `"0"` | Zero | Preserve string type |
| Number `0` | Zero | Preserve numeric type |
| Empty string `""` | Blank | Validate string constraints |
| Empty array `[]` | Missing collection | Validate array length separately |
| Boolean `false` | Numeric zero | Reject numeric coercion |
| Undocumented enum value | Harmless extension | Evaluate consumer compatibility |

## Money and rounding

Binary floating-point cannot exactly represent many decimal fractions. Parsing a monetary token into a binary float and later converting it to a decimal preserves the approximation, not the original value.

Use decimal parsing directly from JSON numeric text. Where contracts use integer minor units, identify the currency and applicable scale. Do not assume every currency has two decimal places.

Rounding policy must specify the stage, scale, and tie-breaking rule. Rounding each line item and rounding the final sum can produce different totals.

| Inputs | Policy | Result |
|---|---|---|
| `0.005` and `0.005` | Round each to cents, half-up, then sum | `0.02` |
| `0.005` and `0.005` | Sum first, then round to cents | `0.01` |
| `2.345` | Round to cents, half-even | `2.34` |
| `2.345` | Round to cents, half-up | `2.35` |

The auditor should detect contract violations without repairing evidence. If a field permits at most two decimal places, report `2.345`; do not silently round it into compliance.

Also distinguish mathematical value from lexical representation. A JSON number written as `2.00` does not reliably communicate a preserved display scale across parsers. Use a string with an explicit pattern when exact textual formatting is contractual.

## Illustrative postmortem: identifier coercion

**Trigger:** A serialization change emitted an account identifier as a JSON number.

**Impact:** Leading zeros disappeared. Some consumers also lost precision for integers beyond their runtime’s exact integer range. Reconciliation joined transactions to incorrect or nonexistent account records.

**Why checks missed it:** Test fixtures used short identifiers without leading zeros. Spreadsheet review displayed the old and new samples similarly.

**Preventive control:** Require identifiers to remain strings, add leading-zero and large-value fixtures, and compare response types against the approved baseline.

**Recovery:** Restore string serialization and replay affected reconciliation jobs from preserved source records.

## Illustrative postmortem: nullable timestamp

**Trigger:** A database migration introduced a transitional state in which `settled_at` was null.

**Impact:** Clients assumed the timestamp was always parseable and failed before displaying payment status.

**Why checks missed it:** Tests covered completed settlements only. The producer changed its local schema to nullable without evaluating consumers.

**Preventive control:** Audit transitional states and flag response nullability expansion. Explicitly model which statuses permit a null settlement timestamp.

The schema rule alone is insufficient here. Cross-field policy must express that a settled payment requires a settlement timestamp.

## Illustrative postmortem: enum expansion

**Trigger:** A producer added `reversed` to a response status enum.

**Impact:** Exhaustive consumer switches rejected the response or misclassified the payment.

**Why checks missed it:** The release review treated adding values as universally backward-compatible.

**Preventive control:** Distinguish request enum expansion from response enum expansion. Require either verified unknown-value handling or a coordinated migration.

## Less visible parsing hazards

Reject duplicate object keys. Different parsers may retain the first value, retain the last, or fail. Such ambiguity makes audit conclusions unreliable.

Reject nonstandard numeric tokens such as `NaN` and `Infinity`. Preserve original payload bytes when validating signatures, lexical formats, or parser behavior. Extracted field samples cannot reveal duplicate keys elsewhere in the source document.

Test empty collections, deeply nested objects, Unicode edge cases, and large payloads. Bound resource consumption so a malformed fixture cannot stall the release pipeline.

# Chapter 4: Offline Browser Workbench Architecture & Zero-Upload Security

An offline workbench should inspect local evidence without transmitting payloads. This must be an architectural property supported by verification.

## Separate the processing stages

Use five components:

1. **Local ingestion:** reads explicitly selected files.
2. **Structural parser:** validates CSV, JSON, manifests, and policy versions.
3. **Contract engine:** compares baseline, candidate, and observations.
4. **Finding model:** stores structured results and coverage.
5. **Report renderer:** displays summaries and exports review artifacts.

Keep parsing and validation in a dedicated worker so large files do not freeze the interface. Support cancellation and deterministic resource limits.

The browser and CLI must share a rule specification and conformance fixtures. Separate implementations can diverge on numbers, Unicode, nulls, and enum equality unless those behaviors are tested explicitly.

## Preserve numeric evidence

The browser’s ordinary JSON parser converts numbers into its native numeric representation. That can lose integer precision and decimal detail before validation begins.

Use a parser that preserves numeric lexemes, or tokenize numbers before semantic interpretation. Do not recover exact values by converting already-rounded numbers back into strings.

Likewise, duplicate-key detection must occur during parsing. Once an object has overwritten a duplicate property, later validation cannot reconstruct the original ambiguity.

## Make zero-upload enforceable

Bundle scripts, styles, fonts, and dependencies locally. Exclude telemetry, remote error reporting, external fonts, and remote schema resolution. Resolve schema references only from the approved local bundle.

Apply a restrictive Content Security Policy, including `connect-src 'none'`, and prohibit forms, embedded objects, and unnecessary navigation. Render field values as text, never executable markup.

Serve the workbench from loopback where browser restrictions make local-file execution inconsistent. Bind only to loopback interfaces, validate expected host headers, and keep the server static: payload files should be read inside the browser, not posted to the server.

Verify behavior with network inspection while importing files, triggering errors, and exporting reports. Repeat under disconnected conditions. A visible “offline” label is not evidence of network isolation.

## Minimize retained data

Keep payloads in memory by default. Avoid browser databases, local storage, and service-worker caches for sensitive evidence. Clear application references when a session closes, while acknowledging that ordinary browser memory management does not guarantee secure erasure.

Exports should contain finding metadata and redacted examples unless full evidence is explicitly required. Spreadsheet-compatible exports must neutralize formula-like cells; retain an unmodified machine-readable evidence format separately.

Record tool version, rule version, input hashes, and coverage in the report. Hashes establish artifact correspondence; they do not authenticate the source or make sensitive data anonymous.

# Chapter 5: Automating Audits with Zero-Dependency Python 3 CLI & CI/CD Exit Codes

A small command-line validator provides a reproducible foundation. Keep its supported scope explicit.

The following standard-library implementation validates one projection CSV: headers, row structure, endpoint uniqueness, metadata syntax, JSON parsing, nullability, and primitive types. It deliberately treats missing fields as **audit failures**, because requiredness is unavailable in these seven columns.

It does not implement contract differencing, enum policy, endpoint-registry reconciliation, or full schema validation. Those are additional release-gate stages.

```python
#!/usr/bin/env python3
import argparse
import csv
import json
import re
import sys
from decimal import Decimal

COLUMNS = [
    "endpoint_id", "method", "field_path", "expected_type",
    "nullable", "observed_sample", "status_code",
]
METHODS = {
    "GET", "HEAD", "POST", "PUT", "PATCH",
    "DELETE", "OPTIONS", "TRACE", "CONNECT",
}
TYPES = {"string", "integer", "number", "boolean", "object", "array"}

class InputError(ValueError):
    pass

def reject_constant(token):
    raise InputError("nonstandard JSON numeric constant")

def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise InputError("duplicate JSON object key")
        result[key] = value
    return result

def parse_sample(text):
    return json.loads(
        text,
        parse_int=Decimal,
        parse_float=Decimal,
        parse_constant=reject_constant,
        object_pairs_hook=unique_object,
    )

def is_type(value, expected):
    if expected == "string":
        return isinstance(value, str)
    if expected == "boolean":
        return type(value) is bool
    if expected == "object":
        return isinstance(value, dict)
    if expected == "array":
        return isinstance(value, list)
    if expected == "number":
        return isinstance(value, Decimal) and value.is_finite()
    if expected == "integer":
        return (
            isinstance(value, Decimal)
            and value.is_finite()
            and value == value.to_integral_value()
        )
    return False

def valid_pointer(pointer):
    return (
        pointer == ""
        or (
            pointer.startswith("/")
            and re.search(r"~(?:[^01]|$)", pointer) is None
        )
    )

def inspect(path):
    findings = []
    seen = set()
    rows = 0

    with open(path, encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle, strict=True)
        if reader.fieldnames != COLUMNS:
            raise InputError("header must match required columns and order")

        for record, row in enumerate(reader, start=1):
            rows += 1
            if None in row or any(v is None for v in row.values()):
                raise InputError(f"record {record}: wrong column count")

            endpoint = row["endpoint_id"]
            if not endpoint or endpoint != endpoint.strip():
                raise InputError(f"record {record}: invalid endpoint_id")
            if endpoint in seen:
                raise InputError(f"record {record}: duplicate endpoint_id")
            seen.add(endpoint)

            if row["method"] not in METHODS:
                raise InputError(f"record {record}: invalid method")
            if not valid_pointer(row["field_path"]):
                raise InputError(f"record {record}: invalid JSON Pointer")
            if row["expected_type"] not in TYPES:
                raise InputError(f"record {record}: unsupported type")
            if row["nullable"] not in {"true", "false"}:
                raise InputError(f"record {record}: invalid nullable flag")
            if re.fuテキスト処理系atch(r"[1-5][0-9]{2}", row["status_code"]) is None:
                raise InputError(f"record {record}: invalid status code")

            sample = row["observed_sample"]
            if sample == "":
                raise InputError(
                    f"record {record}: absence requires requiredness policy"
                )

            try:
                value = parse_sample(sample)
            except ValueError as exc:
                raise InputError(
                    f"record {record}: invalid or ambiguous JSON"
                ) from exc

            rule = None
            if value is None:
                if row["nullable"] == "false":
                    rule = "NULL_NOT_ALLOWED"
            elif not is_type(value, row["expected_type"]):
                rule = "TYPE_MISMATCH"

            if rule:
                findings.append({
                    "record": record,
                    "endpoint_id": endpoint,
                    "field_path": row["field_path"],
                    "rule": rule,
                })

    if rows == 0:
        raise InputError("empty evidence file")
    return rows, findings

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("csv_file")
    args = parser.parse_args()

    try:
        rows, findings = inspect(args.csv_file)
    except (
        OSError, UnicodeError, csv.Error, ValueError,
        ArithmeticError, RecursionError,
    ):
        print(json.dumps({
            "result": "audit_error",
            "message": "Input could not be evaluated; inspect locally.",
        }))
        return 2

    print(json.dumps({
        "result": "contract_failure" if findings else "pass",
        "scope": "projection_structure_nullability_and_types",
        "rows_checked": rows,
        "findings": findings,
    }, ensure_ascii=True))
    return 1 if findings else 0

if __name__ == "__main__":
    sys.exit(main())
```

Run it as:

```sh
python3 audit_projection.py evidence.csv > audit-report.json
```

The integer check follows mathematical JSON Schema semantics: `1.0` is an integer-valued number. If lexical integer notation is required, preserve and validate the original numeric token under a separate rule.

## Extend the release gate deliberately

Add a manifest-driven orchestrator that verifies hashes, expected files, assertion membership, endpoint registry, and response variants. Then apply requiredness, enums, ranges, patterns, array rules, and cross-field constraints.

Implement baseline-to-candidate comparison separately. Matching types in observed fixtures cannot establish that a candidate schema has preserved the baseline.

Use type-aware enum equality. In Python, a plain membership test can equate `True` with `1`. Compare JSON categories before comparing values, while treating integer-valued and fractional numbers according to the chosen schema semantics.

Any unsupported schema keyword must produce an explicit coverage gap or audit failure. Never silently ignore constraints while reporting full compatibility.

## Make exit codes operational

Use `0` for completed checks with no blocking findings, `1` for contract violations, and `2` for invalid evidence or configuration. CI should block on every nonzero result, including unexpected runtime failures and terminated processes.

Preserve the validator’s exit code through logging and artifact-upload steps. A successful report upload must not overwrite a failed audit result.

Publish reports even on failure, with controlled retention. Apply file-size, row-count, nesting, and execution-time limits before admitting untrusted fixtures.

Test the validator with adversarial fixtures: duplicate keys, malformed CSV, null, absence, booleans in numeric fields, large integers, escaped pointers, enum boundaries, and missing response variants.

# Chapter 6: Standard Operating Checklist & Executive Sign-Off Template

A release decision needs traceable evidence, clear ownership, and explicit limits.

## Before the audit

- Freeze the baseline, candidate artifact, fixture bundle, and rule version.
- Confirm request versus response direction for every assertion.
- Verify endpoint identity and projection-file primary keys.
- Include success, error, empty, transitional, and boundary cases.
- Confirm requiredness and enum policies exist outside the CSV.
- Sanitize fixtures and assign evidence-retention limits.

## During the audit

- Validate structure before interpreting values.
- Reconcile the complete manifest before comparing contracts.
- Inspect removals, type changes, nullability changes, and enum changes.
- Check financial scale, rounding rules, and cross-field invariants.
- Record unsupported constraints and missing coverage.
- Block deployment when evidence cannot be evaluated.

## Before release

Each blocking finding needs a fix, a verified migration, or a documented exception. Exceptions require an owner, affected consumers, compensating controls, expiration date, and rollback trigger. They must not turn failed checks into passing checks.

For behavioral changes, use a canary with measurable thresholds: decoding failures, unknown enum counts, reconciliation differences, and error-response parsing failures. Define who can halt rollout and how quickly the previous producer behavior can be restored.

## Executive sign-off template

**Release identifier:**  
**Producer revision and artifact digest:**  
**Baseline contract version:**  
**Candidate contract version:**  
**Auditor and policy versions:**  
**Evidence bundle digest:**  
**Audit date and responsible engineer:**

**Scope:** List operations, consumer profiles, request/response directions, and status variants reviewed.

**Result:** Pass / Blocked / Approved with documented exceptions.

**Compatibility findings:** Summarize removed fields, changed types, nullability changes, enum changes, and financial representation changes.

**Coverage limits:** Identify untested states, unsupported constraints, and unavailable consumer evidence.

**Exceptions:** Reference each finding, accountable owner, compensating control, and expiration date.

**Operational readiness:** Identify canary metrics, alert thresholds, rollback procedure, and rollback authority.

**Decision:** Approve / Reject / Defer.

**Engineering owner:**  
**Consumer owner:**  
**Finance or reconciliation owner, where applicable:**  
**Release authority:**

Approval should answer one concrete question: does the available evidence justify exposing these exact payload changes to these identified consumers? If the answer depends on an untested assumption, record that assumption and resolve it before expanding the release.
