# REST & JSON Payload Schema Breaking-Change Auditor

**Offline Contract Inspector, CLI Linter & API Reliability Engineering Guide**

- **Suggested Price**: USD 17
- **Focus**: Detecting silent schema drift, nullability regressions, enum violations, and backward-incompatible payload changes before deployment.
- **Included**:
  1. `en-pkg-03-api-contract-diff-auditor_workbench.html` — 100% Offline Browser Workbench (zero external requests)
  2. `en_pkg_03_api_contract_diff_auditor_cli.py` — Zero-Dependency Python 3 CLI Auditor
  3. `en-pkg-03-api-contract-diff-auditor-kdp-en-v1.epub` — Full Practical Engineering Handbook (EPUB3)
  4. `samples/` & `test_en_package.py` — Sample datasets and automated verification suite
