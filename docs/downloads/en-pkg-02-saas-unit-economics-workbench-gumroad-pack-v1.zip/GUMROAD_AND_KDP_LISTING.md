# SaaS Cohort Retention, LTV/CAC & Cash Runway Workbench

**Offline Financial Modeling Calculator, CLI Validator & Founder's Handbook**

- **Suggested Price**: USD 19
- **Focus**: Auditing net dollar retention (NDR), payback period, logo vs revenue churn, burn multiple, and 24-month cash runway.
- **Included**:
  1. `en-pkg-02-saas-unit-economics-workbench_workbench.html` — 100% Offline Browser Workbench (zero external requests)
  2. `en_pkg_02_saas_unit_economics_workbench_cli.py` — Zero-Dependency Python 3 CLI Auditor
  3. `en-pkg-02-saas-unit-economics-workbench-kdp-en-v1.epub` — Full Practical Engineering Handbook (EPUB3)
  4. `samples/` & `test_en_package.py` — Sample datasets and automated verification suite
