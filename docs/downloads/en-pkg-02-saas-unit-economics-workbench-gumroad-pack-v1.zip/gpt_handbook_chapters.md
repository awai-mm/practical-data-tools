# Chapter 1: Why Spreadsheets Fail in Production & The Pre-Flight Audit Pattern

A financial model becomes a production system when someone uses it to approve hiring, set acquisition budgets, or decide when to raise capital. At that point, a plausible number is insufficient. Every material output needs a defined population, a measurement window, a reconciliation path, and an accountable owner.

Spreadsheets fail when those requirements remain implicit. A copied formula excludes the newest cohort. A percentage arrives as `80` in one export and `0.80` in another. New sales enter the numerator of a retention calculation. Annual subscription collections appear as recurring monthly revenue. The workbook still opens, and its charts still look credible.

The solution begins before calculation: a pre-flight audit.

**Establish the data contract.** This handbook uses one row per acquisition cohort, identified by `cohort_month`. Each export represents a common month-end snapshot. Record that snapshot month separately as `as_of_month`.

The required columns have these meanings:

- `cohort_month`: acquisition month, formatted `YYYY-MM`.
- `new_customers`: original number of customers acquired in that cohort.
- `mrr_added`: recurring monthly revenue at acquisition.
- `churned_mrr`: cumulative MRR reductions through the snapshot, including cancellations and contractions.
- `expansion_mrr`: cumulative MRR increases after acquisition, including reactivation under a documented policy.
- `cac_spend`: fully loaded acquisition spending allocated to the cohort.
- `gross_margin_pct`: the cohort’s gross margin percentage for the snapshot month.

The reduction convention matters. If a source uses `churned_mrr` exclusively for cancellations, it must supply contractions separately before this contract can be satisfied.

**Separate supported calculations from missing evidence.** These seven columns support cohort revenue bridges and certain acquisition-efficiency estimates. They do not independently establish monthly NDR, logo churn, realized payback, lifetime value, burn multiple, or cash runway.

Those measures require additional snapshots, customer counts, acquisition-cost attribution, or cash schedules. A trustworthy workbench displays “unavailable” when evidence is missing.

**Run the audit in order.**

1. Validate encoding, headers, types, uniqueness, and dates.
2. Check economic constraints and cohort identities.
3. Reconcile aggregate balances against independent controls.
4. Calculate supported metrics.
5. Project cash using explicit assumptions.
6. Record exceptions and obtain sign-off.

Retain the original input, its checksum, the calculation version, the assumptions, and the resulting report. A rerun should reproduce the same result without consulting somebody’s memory.

# Chapter 2: Core Validation & Reconciliation Rules for cohort_month

The primary key is `cohort_month`, not the spreadsheet row number. Reject duplicates rather than summing them automatically: duplicate records often indicate overlapping extracts.

Require valid calendar months and reject cohorts later than the snapshot. Missing months are not automatically errors; a business may acquire no customers during a month. Sort chronologically for presentation without changing source values.

Use one reporting currency. Monetary fields must contain nonnegative decimal amounts without currency symbols, thousands separators, or scientific notation. This handbook’s export contract permits two decimal places. Preserve higher precision upstream until cohort amounts have been aggregated.

`new_customers` must be a nonnegative integer. A cohort containing zero customers cannot carry revenue movements, although spending with zero conversions can be recorded and flagged.

Interpret `gross_margin_pct` on a 0–100 scale. A value of `0.80` means 0.80%, not 80%. Never silently rescale it. Negative gross margins can be economically real, but this contract excludes them; such businesses need a revised, versioned contract.

**Revenue reconciliation**

For each cohort:

```text
ending_mrr = mrr_added − churned_mrr + expansion_mrr
```

Require nonnegative ending MRR. Cumulative reductions can exceed original MRR after substantial expansion, so checking `churned_mrr <= mrr_added` would be incorrect.

Reconcile total ending MRR to an independent subscription-ledger control at the same cutoff. MRR is a recurring-revenue measure; it does not generally equal invoices, accounting revenue, or cash receipts.

**Retention**

For a fixed population of customers present at the start of a period:

```text
NDR = (opening MRR − reductions + expansion) / opening MRR
GRR = (opening MRR − reductions) / opening MRR
```

Exclude revenue from customers acquired during the period. With opening MRR of $100,000, reductions of $8,000, and expansion of $15,000, NDR is 107% and gross revenue retention is 92%.

Comparing a cohort’s current MRR with its original MRR measures retention since acquisition. Cohorts of different ages must not be presented as directly comparable monthly retention observations.

Logo churn requires customer identities or opening and lost-customer counts:

```text
logo churn = customers lost from the opening population / opening customers
```

Revenue reductions cannot reveal how many customers left.

**Acquisition economics**

```text
CAC = acquisition spending / acquired customers
initial monthly gross profit per customer =
    acquisition MRR / acquired customers × gross margin fraction
simple payback months = CAC / initial monthly gross profit per customer
```

This payback estimate assumes unchanged revenue and margin. Realized payback is the first month when cumulative cohort gross profit covers acquisition spending. It requires a monthly history.

A simplified LTV estimate is monthly gross profit per customer divided by monthly customer churn. It assumes a constant churn hazard and stable economics. Zero churn makes that estimate undefined, not infinite evidence of value. Do not substitute net revenue churn when expansion makes it negative.

**Burn and runway**

Define burn multiple as period net cash burn divided by net new ARR. Document the burn convention; a practical choice includes operating cash flows and capital expenditure but excludes financing. Nonpositive ARR growth makes the ratio unsuitable for ordinary interpretation.

Project 24 individual cash balances:

```text
closing cash = opening cash + customer receipts + financing
               − operating payments − taxes − capital expenditure
               − debt principal repayments
```

Specify whether interest sits within operating payments. Include acquisition spending once. Use collection dates, not MRR recognition dates.

# Chapter 3: Real-World Edge Cases, Rounding Traps & Incident Postmortems

Most financial incidents begin with reasonable-looking inputs interpreted under incompatible definitions.

| Situation | Tempting treatment | Required treatment |
|---|---|---|
| Annual subscription collected upfront | Add the full receipt to MRR | Normalize recurring revenue; schedule the receipt separately |
| Customer downgrades but remains active | Count one lost logo | Record revenue contraction without logo churn |
| Canceled customer returns | Create another acquired customer | Apply a documented reactivation policy consistently |
| Zero acquisitions with campaign spending | Set CAC to zero | Show CAC as unavailable and retain the spending |
| Currency changes between exports | Compare nominal balances | Apply the approved FX policy and separate FX movement |
| Refund issued after cancellation | Subtract it from MRR again | Separate cash refunds from recurring-revenue changes |

**Incident 1: retention improved because sales improved**

A reporting team calculated retention from total ending MRR divided by opening MRR. Its bridge was:

| Movement | MRR |
|---|---:|
| Opening customer population | $100,000 |
| Cancellations and contractions | −$8,000 |
| Expansion within opening population | +$15,000 |
| New-customer revenue | +$20,000 |
| Total ending MRR | $127,000 |

The reported 127% “NDR” included acquisition. Correct NDR was 107%.

The repair was a customer-population join: opening customer identifiers defined eligibility for the retention numerator. A total-MRR reconciliation alone could not detect this error because the ending balance was correct.

**Incident 2: premature rounding created a reconciliation gap**

One thousand annual contracts each carried $1,000 of recurring annual value. Dividing each contract by twelve and rounding immediately produced $83.33 per contract, or $83,330 in aggregate.

Aggregating annual value first and then dividing produced $83,333.33. The $3.33 difference came entirely from rounding order.

Choose the calculation grain explicitly. Preserve precision during normalization, aggregate at the agreed grain, then apply a documented rounding rule. Use decimal arithmetic for monetary calculations. Do not increase reconciliation tolerances merely to conceal unexplained differences.

**Incident 3: the runway ignored payment timing**

A company started with $1.2 million and forecast $50,000 of monthly net cash outflow. Its model reached zero at the end of month 24.

With a $100,000 minimum cash floor, the balance first fell below that floor in month 23. An omitted annual vendor payment of $120,000 moved the breach earlier.

The correction introduced dated payment schedules and distinguished three outputs: projected ending cash, first month below the operating floor, and first month at or below zero. Monthly reporting still cannot guarantee sufficient cash on every day within a month.

**Incident 4: attractive payback hid attribution gaps**

A cohort showed $800 CAC and $80 of initial monthly gross profit per customer, suggesting ten-month payback. The acquisition calculation omitted commissions and allocated campaign spending to the booking month despite a longer sales cycle.

The repair reconciled acquisition costs to the expense ledger and documented allocation rules. Both the original and corrected reports remained available, with the correction identified rather than silently overwriting history.

# Chapter 4: Offline Browser Workbench Architecture & Zero-Upload Security

An offline workbench should calculate locally from user-selected files. Its architecture must make that behavior verifiable.

Use four components: an input parser, a validation engine, a calculation engine, and a report renderer. Keep financial rules independent of the interface so the same fixtures can exercise browser and command-line implementations.

Represent currency with integer minor units or exact decimal arithmetic. JavaScript floating-point values should not determine reconciliation outcomes. Percentage calculations need an explicit scale and rounding rule.

**Input and processing**

Read selected files through browser file APIs. Apply limits to file size, row count, and field length before expensive processing. Parse CSV quoting correctly; splitting lines on commas is not a CSV parser.

Run larger audits in a worker so the interface remains responsive. Return structured findings with rule identifiers, record locations, severity, and remediation text.

Render imported content as text. Never insert file values directly into executable markup. When exporting spreadsheet-compatible reports, neutralize formula-like text fields, including labels introduced through supplemental files.

**Network boundaries**

Ship scripts, styles, fonts, and help content with the application. Remove analytics, external error reporting, remote fonts, and content-delivery dependencies.

For a local-server distribution, bind to loopback and use a restrictive content security policy, including `connect-src 'none'`, `form-action 'none'`, and tightly scoped script and worker sources. Verify the actual packaging mode; browser behavior differs between local files and loopback-served assets.

Test with outbound connectivity blocked. Inspect network activity throughout import, validation, calculation, and export. A cached application loading successfully is not proof that it makes no outbound requests.

**Storage and recovery**

Keep imported financial data in memory by default. Do not place it in browser storage, URLs, service-worker caches, or diagnostic logs. Persist data only through an explicit user action.

Closing a tab releases application-held references; it does not establish forensic erasure from operating-system memory or swap. Browser extensions and a compromised device also remain outside the workbench’s isolation boundary.

An exported audit package should contain the source checksum, contract version, snapshot month, assumptions, findings, and calculated outputs. Checksums identify changed inputs; they do not prove authenticity unless compared with a trusted record.

Keep projections visibly separate from observed results. Every runway scenario should disclose opening cash, collection delays, hiring dates, payment schedules, financing assumptions, and the minimum cash floor.

# Chapter 5: Automating Audits with Zero-Dependency Python 3 CLI & CI/CD Exit Codes

The following standard-library validator checks the base contract and reconciles ending MRR to a separately supplied control. It does not certify retention periods or cash projections.

Save it as `audit_cohorts.py`. The header order is part of this implementation’s contract.

```python
import argparse
import csv
import re
import sys
from datetime import date
from decimal import Decimal

FIELDS = [
    "cohort_month", "new_customers", "mrr_added",
    "churned_mrr", "expansion_mrr", "cac_spend",
    "gross_margin_pct",
]
ZERO = Decimal("0")


def month(value):
    if not re.fuテキスト処理系atch(r"[0-9]{4}-(0[1-9]|1[0-2])", value):
        raise ValueError("invalid month")
    date(int(value[:4]), int(value[5:]), 1)
    return value


def decimal_value(value, places):
    pattern = (
        r"(?:0|[1-9][0-9]{0,11})"
        + r"(?:\.[0-9]{1," + str(places) + r"})?"
    )
    if not re.fuテキスト処理系atch(pattern, value):
        raise ValueError("invalid nonnegative decimal")
    return Decimal(value)


def audit(path, as_of, control):
    errors = []
    seen = set()
    ending_total = ZERO
    count = 0

    with open(path, encoding="utf-8-sig", newline="") as source:
        reader = csv.reader(source, strict=True)
        if next(reader, None) != FIELDS:
            return ["header mismatch"], ZERO, 0

        for record, cells in enumerate(reader, start=2):
            count += 1
            try:
                if len(cells) != len(FIELDS):
                    raise ValueError("wrong field count")
                row = dict(zip(FIELDS, cells))
                cohort = month(row["cohort_month"])

                if cohort in seen:
                    raise ValueError("duplicate cohort_month")
                seen.add(cohort)
                if cohort > as_of:
                    raise ValueError("cohort follows snapshot")

                if not re.fuテキスト処理系atch(
                    r"(?:0|[1-9][0-9]{0,11})",
                    row["new_customers"],
                ):
                    raise ValueError("invalid customer count")
                customers = int(row["new_customers"])

                added, churned, expanded, spend = [
                    decimal_value(row[name], 2)
                    for name in FIELDS[2:6]
                ]
                margin = decimal_value(row["gross_margin_pct"], 4)
                if margin > 100:
                    raise ValueError("margin exceeds 100 percent")

                if customers == 0 and any(
                    amount != ZERO
                    for amount in (added, churned, expanded)
                ):
                    raise ValueError("revenue without cohort customers")

                ending = added - churned + expanded
                if ending < ZERO:
                    raise ValueError("negative ending MRR")
                ending_total += ending

            except ValueError as exc:
                errors.append(f"record {record}: {exc}")

    if count == 0:
        errors.append("no data records")
    if not errors and ending_total != control:
        errors.append("ending MRR differs from independent control")
    return errors, ending_total, count


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("csv_path")
    parser.add_argument("--as-of", required=True)
    parser.add_argument("--ending-mrr-control", required=True)
    args = parser.parse_args()

    try:
        as_of = month(args.as_of)
        control = decimal_value(args.ending_mrr_control, 2)
    except ValueError as exc:
        parser.error(str(exc))

    try:
        errors, total, count = audit(args.csv_path, as_of, control)
    except OSError:
        print("ERROR: input file could not be read", file=sys.stderr)
        return 2
    except (csv.Error, UnicodeError):
        print("INVALID: malformed CSV or encoding", file=sys.stderr)
        return 1

    if errors:
        for error in errors:
            print("INVALID:", error, file=sys.stderr)
        return 1

    print(
        f"PASS: base audit; cohorts={count}; "
        f"ending_mrr={total:.2f}; as_of={as_of}"
    )
    return 0


if __name__ == "__main__":
    try:
        status = main()
    except Exception:
        print("ERROR: unexpected validator failure", file=sys.stderr)
        status = 3
    sys.exit(status)
```

A reproducible invocation supplies an explicit snapshot and control:

```text
python3 audit_cohorts.py cohorts.csv \
  --as-of 2026-09 \
  --ending-mrr-control 127000.00
```

Never derive that control from the same cohort file. Obtain it independently from the subscription ledger.

| Exit code | Meaning | Pipeline action |
|---|---|---|
| `0` | Base validation and MRR reconciliation passed | Continue to subsequent gates |
| `1` | Invalid data or reconciliation failure | Block publication |
| `2` | Invocation or file-access problem | Repair job configuration |
| `3` | Unexpected validator failure | Investigate implementation |

A minimal pipeline step is:

```yaml
- name: Validate cohort export
  run: |
    python3 audit_cohorts.py cohorts.csv \
      --as-of 2026-09 \
      --ending-mrr-control 127000.00
```

Production jobs should obtain those arguments from versioned close metadata. Protect financial artifacts with appropriate access controls and retention limits.

Test meaningful failure paths: duplicate cohorts, malformed quoting, invalid months, missing columns, zero denominators, negative ending balances, and a one-cent reconciliation mismatch. Maintain shared calculation fixtures across the browser and CLI.

Resource limits, structured reports, and supplemental-ledger validation belong in the production wrapper. A successful base audit must never bypass the separate retention and cash gates.

# Chapter 6: Standard Operating Checklist & Executive Sign-Off Template

Run the workbench as part of the financial close. Assign named owners to source preparation, reconciliation, review, and approval.

**Before calculation**

- Confirm snapshot date, currency, reporting scope, and contract version.
- Freeze source exports and record checksums.
- Validate primary keys, numeric fields, and cohort membership.
- Reconcile ending MRR to the subscription ledger.
- Reconcile acquisition spending to the approved expense allocation.
- Obtain opening and closing customer populations.
- Reconcile opening cash to bank balances and restrict unavailable funds.

**Before publication**

- Calculate NDR using only the opening customer population.
- Show logo churn and revenue churn separately.
- Label payback as estimated or realized.
- Disclose the assumptions behind LTV/CAC.
- Match burn and net new ARR to the same reporting period.
- Produce 24 monthly cash balances for base and downside scenarios.
- Include annual bills, collections delays, taxes, debt, and dated hiring.
- Exclude uncommitted financing from the base case.
- Report the first cash-floor breach and the first cash-exhaustion month.
- Resolve blocking exceptions or disclose why approval remains withheld.

Compare changes in outputs with changes in business activity and assumptions. An unexplained jump is an investigation trigger even when every structural rule passes.

Use the following approval record:

```text
Reporting period:
Snapshot month:
Reporting currency:
Contract and calculation versions:
Input checksums:
Prepared by:
Independently reviewed by:

MRR control and reconciliation difference:
NDR population and measurement window:
Logo churn population and measurement window:
CAC cost scope and allocation policy:
Payback method: estimated / realized
LTV assumptions and exclusions:
Burn definition and net new ARR period:

Opening unrestricted cash:
Minimum operating cash floor:
Base-case month-24 closing cash:
Base-case first month below cash floor:
Downside first month below cash floor:
First month at or below zero:
Financing included and commitment status:

Unresolved exceptions:
Sensitivity findings:
Required actions, owners, and deadlines:

Decision: approved / approved with conditions / withheld
Approver:
Approval date:
```

Approval applies to a specific input set and calculation version. Changes to either require a new report and renewed review.

Executives should sign off on the operating response as well as the numbers: when hiring slows, when spending is reduced, and when financing discussions begin. A reliable workbench connects reconciled evidence to dated decisions.
