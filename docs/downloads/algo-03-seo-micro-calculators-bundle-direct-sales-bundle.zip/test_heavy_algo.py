#!/usr/bin/env python3
import subprocess, sys, unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ENGINE = ROOT / "algo_03_seo_micro_calculators_bundle_engine.py"
WORKBENCH = ROOT / "algo-03-seo-micro-calculators-bundle_workbench.html"

class TestHeavyAlgoSuite(unittest.TestCase):
    def test_engine_self_test_passes(self):
        r = subprocess.run([sys.executable, str(ENGINE), "--self-test"], capture_output=True, text=True, timeout=20)
        self.assertEqual(r.returncode, 0, msg=r.stderr or r.stdout)

    def test_workbench_has_json_ld_and_offline_script(self):
        txt = WORKBENCH.read_text(encoding="utf-8")
        self.assertIn("application/ld+json", txt)
        self.assertIn("SoftwareApplication", txt)

if __name__ == "__main__":
    unittest.main()
