#!/usr/bin/env python3
"""
Programmatic SEO 4-in-1 Business Financial Calculators Engine & Static Bundle Verifier.
Computes:
1. Invoice Tax Regime Comparison (General vs Simplified vs 20% Special Rule)
2. SaaS/EC Unit Economics Break-Even ROAS & Max Allowable CPA
3. Agency/Contracting Scope Creep & Utilization Margin Guard
4. Sole Proprietor + Micro-Corp Social Insurance & Tax Split Optimizer
"""
from __future__ import annotations
import argparse, json
from typing import Any


def compare_invoice_regimes(annual_sales_tax_incl: int, taxable_expense_ratio: float, simplified_deemed_rate: float = 0.70) -> dict[str, Any]:
    sales_net = annual_sales_tax_incl / 1.10
    output_tax = annual_sales_tax_incl - sales_net
    general_tax = max(0.0, output_tax - output_tax * taxable_expense_ratio)
    simplified_tax = output_tax * (1.0 - simplified_deemed_rate)
    special_20pct_tax = output_tax * 0.20
    options = {
        "general_regular": round(general_tax),
        "simplified_deemed": round(simplified_tax),
        "special_20pct": round(special_20pct_tax),
    }
    best = min(options, key=options.get)
    return {"options_yen": options, "recommended_regime": best, "max_savings_yen": max(options.values()) - min(options.values())}


def calc_unit_economics(aov: float, gross_margin_pct: float, repeat_orders_per_year: float, annual_churn_rate: float, target_operating_margin_pct: float = 0.15) -> dict[str, Any]:
    lifetime_years = 1.0 / max(0.05, annual_churn_rate)
    ltv_gross_profit = aov * (gross_margin_pct / 100.0) * repeat_orders_per_year * lifetime_years
    max_cpa_break_even = aov * (gross_margin_pct / 100.0)
    max_cpa_ltv_3x = ltv_gross_profit / 3.0
    min_roas_first_order = aov / max(1.0, aov * ((gross_margin_pct / 100.0) - target_operating_margin_pct))
    return {
        "ltv_gross_profit": round(ltv_gross_profit, 2),
        "first_order_break_even_cpa": round(max_cpa_break_even, 2),
        "healthy_ltv_3x_cpa": round(max_cpa_ltv_3x, 2),
        "target_first_order_roas": round(min_roas_first_order, 2),
    }


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--self-test", action="store_true")
    args = p.parse_args()
    r1 = compare_invoice_regimes(11000000, 0.35, 0.70)
    r2 = calc_unit_economics(8500, 68.0, 2.4, 0.40)
    out = {"ok": r1["recommended_regime"] == "special_20pct" and r2["ltv_gross_profit"] > 0, "invoice": r1, "unit_economics": r2}
    print(json.dumps(out, ensure_ascii=False, indent=2))
    return 0 if out["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
